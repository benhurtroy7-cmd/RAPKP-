"""Vimshottari periods with birth-offset correction and exact integer boundaries.

The declared year is 365.2425 days. This is a convention, not an event predictor.
"""

from datetime import datetime

from .kp import YEARS, cyclic_lords, lords
from .timeutils import from_tick, to_tick

YEAR_DAYS = 365.2425
YEAR_TICKS = 31_556_952_000_000
CYCLE_TICKS = 120 * YEAR_TICKS


def _subperiods(start: int, end: int, first: str):
    elapsed = 0
    for lord in cyclic_lords(first):
        a = start + (end - start) * elapsed // 120
        elapsed += YEARS[lord]
        b = start + (end - start) * elapsed // 120
        yield lord, a, b


def _active_period(periods, tick: int):
    for lord, a, b in periods:
        if a <= tick < b:
            return lord, a, b
    raise ValueError("Period not found; the instant must fall in the parent interval")


def _serialize(level: str, period):
    lord, a, b = period
    return {"level": level, "lord": lord, "start": from_tick(a).isoformat(), "end": from_tick(b).isoformat()}


class Vimshottari:
    def __init__(self, birth: datetime, moon_sidereal_longitude: float):
        info = lords(moon_sidereal_longitude)
        self.first = info["star_lord"]
        self.birth_tick = to_tick(birth)
        self.elapsed_birth_ticks = round(info["nakshatra_fraction_elapsed"] * YEARS[self.first] * YEAR_TICKS)
        self.anchor = self.birth_tick - self.elapsed_birth_ticks
        self.balance_years = YEARS[self.first] - self.elapsed_birth_ticks / YEAR_TICKS

    def periods_at(self, moment: datetime):
        tick = to_tick(moment)
        if tick < self.birth_tick:
            raise ValueError("Evaluation time must not precede birth")
        cycle = (tick - self.anchor) // CYCLE_TICKS
        cycle_start = self.anchor + cycle * CYCLE_TICKS
        md = _active_period(_subperiods(cycle_start, cycle_start + CYCLE_TICKS, self.first), tick)
        bhukti = _active_period(_subperiods(md[1], md[2], md[0]), tick)
        antara = _active_period(_subperiods(bhukti[1], bhukti[2], bhukti[0]), tick)
        return md, bhukti, antara

    def report(self, moment: datetime, upcoming_count: int = 9) -> dict:
        if not 1 <= upcoming_count <= 27:
            raise ValueError("upcoming_count must be 1–27")
        md, bhukti, antara = self.periods_at(moment)
        upcoming = []
        cursor = moment
        for _ in range(upcoming_count):
            a, b, c = self.periods_at(cursor)
            upcoming.append({**_serialize("antara", c), "mahadasha": a[0], "bhukti": b[0]})
            cursor = from_tick(c[2])
        cycle = (to_tick(moment) - self.anchor) // CYCLE_TICKS
        start = self.anchor + cycle * CYCLE_TICKS
        return {
            "system": "Vimshottari",
            "year_days": YEAR_DAYS,
            "boundary_convention": "start inclusive, end exclusive; integer microsecond subdivisions",
            "birth_star_lord": self.first,
            "balance_at_birth_years": self.balance_years,
            "mahadasha": _serialize("mahadasha", md),
            "bhukti": _serialize("bhukti", bhukti),
            "antara": _serialize("antara", antara),
            "upcoming_antaras": upcoming,
            "cycle": [_serialize("mahadasha", p) for p in _subperiods(start, start + CYCLE_TICKS, self.first)],
            "note": "These are calculated period boundaries, not predicted event dates. Input-time, lunar longitude and year conventions affect them.",
        }
