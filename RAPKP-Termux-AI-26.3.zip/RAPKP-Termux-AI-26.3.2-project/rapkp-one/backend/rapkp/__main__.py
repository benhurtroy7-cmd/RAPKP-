"""Offline CLI: calculate, batch or horary. No cloud/LLM calls are made."""

import argparse
import json
import sys
from pathlib import Path

from pydantic import ValidationError

from .config import ROOT
from .engine import AstroEngine
from .errors import CalculationError
from .kp import horary_segment
from .models import ReadingRequest
from .report import create_report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    calc = sub.add_parser("calculate", help="Read one structured request JSON file")
    calc.add_argument("input", type=Path)
    calc.add_argument("--output", type=Path)
    batch = sub.add_parser("batch", help="Stream request JSONL to result JSONL; each row is independent")
    batch.add_argument("input", type=Path)
    batch.add_argument("output", type=Path)
    horary = sub.add_parser("horary", help="Look up a 1–249 segment; not a horary judgment")
    horary.add_argument("number", type=int)
    args = parser.parse_args(argv)
    engine = None
    try:
        if args.command == "horary":
            print(json.dumps(horary_segment(args.number), indent=2))
            return 0
        engine = AstroEngine(ROOT / "data/de440s.bsp")
        if args.command == "calculate":
            request = ReadingRequest.model_validate_json(args.input.read_text())
            result = create_report(engine, request)
            text = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
            if args.output:
                args.output.write_text(text)
            else:
                sys.stdout.write(text)
            return 0
        if args.input.resolve() == args.output.resolve():
            raise ValueError("Batch input and output paths must differ")
        failed = total = 0
        with args.input.open() as source, args.output.open("w") as target:
            for index, line in enumerate(source, 1):
                if not line.strip():
                    continue
                total += 1
                try:
                    request = ReadingRequest.model_validate_json(line)
                    result = {"row": index, "ok": True, "report": create_report(engine, request)}
                except (ValidationError, CalculationError) as exc:
                    failed += 1
                    result = {
                        "row": index,
                        "ok": False,
                        "error": {
                            "code": getattr(exc, "code", "INPUT_VALIDATION"),
                            "message": "Row rejected; correct the structured inputs. No placeholder report was created.",
                        },
                    }
                target.write(json.dumps(result, ensure_ascii=False) + "\n")
        print(
            f"Processed {total} rows; {failed} rejected. Output contains personal calculation data; store it securely.",
            file=sys.stderr,
        )
        return 2 if failed else 0
    except (OSError, ValueError, ValidationError, CalculationError) as exc:
        print(
            f"Calculation not completed ({getattr(exc, 'code', type(exc).__name__)}). Check structured input, output path and kernel integrity.",
            file=sys.stderr,
        )
        return 1
    finally:
        if engine is not None:
            engine.close()


if __name__ == "__main__":
    raise SystemExit(main())
