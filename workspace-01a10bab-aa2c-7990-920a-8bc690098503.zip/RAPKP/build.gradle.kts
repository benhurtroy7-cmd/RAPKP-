// RAPKP v26.3.4 - root build script
// Application identity is declared once, here, and consumed by every module so that the
// version can never drift between the APK metadata, the About screen, the diagnostics
// screen and the audit records. See com.rapkp.core.version.BuildInfo.
plugins {
    id("com.android.application") version "8.4.0" apply false
    id("com.android.library") version "8.4.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
    id("org.jetbrains.kotlin.jvm") version "1.9.23" apply false
}

allprojects {
    extra["rapkpVersionName"] = "26.3.4"
    extra["rapkpVersionCode"] = 26340
}
