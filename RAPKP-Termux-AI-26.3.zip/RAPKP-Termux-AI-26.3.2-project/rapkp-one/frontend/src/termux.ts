import { Capacitor, registerPlugin } from '@capacitor/core';
import { api, isNative, type Connection } from './api';
import type { Status } from './types';
interface Bridge {
 status():Promise<{termuxInstalled:boolean;bootInstalled:boolean;permissionGranted:boolean;paired:boolean;termuxVersion?:string}>;
 requestAccess():Promise<{granted:boolean}>;
 connection():Promise<Connection>;
 installConnector():Promise<{ok:boolean;version:string;port:number;bootHook:boolean}>;
 startBackend():Promise<{requested:boolean}>;
 openTermux():Promise<void>;
 openBoot():Promise<void>;
}
export const Termux=registerPlugin<Bridge>('TermuxBridge');
export const termuxNative=()=>Capacitor.getPlatform()==='android'&&Capacitor.isPluginAvailable('TermuxBridge');
export const TERMUX_PERMISSION_COMMAND="mkdir -p ~/.termux; cp -n ~/.termux/termux.properties ~/.termux/termux.properties.before-rapkp 2>/dev/null; printf '\\nallow-external-apps=true\\n' >> ~/.termux/termux.properties; termux-reload-settings";
export async function termuxConnection():Promise<Connection>{
 if(!isNative())return {primary:'',primaryToken:'',fallback:'',fallbackToken:'',allowFallback:false};
 if(!termuxNative())throw new Error('Install the current Termux AI Android build; its native connector is unavailable.');
 const c=await Termux.connection();
 if(c.primary!=='http://127.0.0.1:8765'||!c.primaryToken)throw new Error('Invalid local pairing configuration.');
 return {...c,fallback:'',fallbackToken:'',allowFallback:false};
}
export async function waitForTermux(c:Connection):Promise<Status>{
 let last:unknown;let lastStatus:Status|undefined;
 for(let i=0;i<16;i++){
  try{const s=(await api<Status>(c,'/api/v1/status')).data;lastStatus=s;if(s.engine_error?.code!=='ENGINE_STARTING')return s;}catch(e){last=e;}
  await new Promise(r=>setTimeout(r,750));
 }
 if(lastStatus)return lastStatus;
 throw new Error(last instanceof Error?last.message:'Termux did not respond. Check setup and automation permissions.');
}
export async function startTermux(c:Connection):Promise<Status>{
 try{const s=(await api<Status>(c,'/api/v1/status')).data;return s.engine_error?.code==='ENGINE_STARTING'?await waitForTermux(c):s;}catch{}
 if(!termuxNative())throw new Error('Start the local connector before testing it.');
 await Termux.startBackend();return waitForTermux(c);
}
