# RAPKP Termux AI — QA handover

**26.3.2-termux.1 · 2026-10-02T23:05:41.402659+00:00**

## Implemented route

APK → paired loopback Termux connector → actual installed ephemeris → bounded asynchronous AI job → app. The APK embeds a source-only connector, not Python/Swiss binaries, API credentials or a permanent cloud endpoint.

## Executed evidence

| Check | Result |
|---|---:|
| Python backend/contract/provider/security cases | 983 passed; 0 failed; 0 skipped |
| Python statement coverage | 90.23% |
| New Termux UI/browser cases | 30 passed |
| Native transport/server-identity mock cases | 20 passed |
| Java crypto cases | 6 passed |
| Android build and lint | Compiled; 0 errors / 0 warnings |
| Signing continuity | Same preview certificate/package as the previous Termux build; higher build 2603012 |
| APK/source consistency | Current built UI and embedded connector hashes checked |
| Supplied professor rule steps | 10 of 21 slots have a public structural outline; evaluated per report with cited evidence, 0 calibrated |
| Provider comparison | 95 UT1 fixtures per provider/mode against the independent pinned JPL adapter |
| Pairing/port reclaim regression | Install, re-pair after home removal, re-pair with a mismatched stored token, foreign service on the port, and stale stop-request handling all verified against the real connector |

## What 26.3.2 adds

26.3.1 fixed a pairing dead-end reported from a real install: after `~/.rapkp-one` had been removed (or its stored token no longer matched the running instance), the previously installed connector kept port 8765 with the old key. Every later install/start died with `Address already in use`, and the app kept reporting that the local process was not the paired connector. Re-pairing could never recover, because the installer only stopped a running connector when it could still prove it owned that connector's token.

The installer now also stops a running RAPKP instance through a stop-request file inside the connector's own private home directory (the same trust boundary as the stored token, never reachable over the network). A stale request file is ignored, so it cannot kill a freshly started service. A service that fingerprints as something other than RAPKP is still never stopped or replaced. The server also logs an explicit message instead of a raw traceback when the port is taken, and the app now reports what actually answered the port (an older RAPKP instance, or a different service) instead of repeating "re-pair" forever.

Also in 26.3.1: the browser QA view labelled its calculation core "Swiss Ephemeris" although that backend computes with the pinned OpenEphem/Skyfield kernel. The status endpoint now reports the real engine and the interface shows it.

26.3.2 adds the rule layer the user supplied on 2026-10-03: a public 10-step structural outline of Prof. Krish Murali Eswar KP's method, attributed through public course outlines and masterclass previews. The outline's own headings claim 7 fundamental + 4 advanced + 5 timing = 16 steps, but only 10 steps are actually listed (4 + 3 + 3). The 6 claimed-but-unlisted steps are recorded as `definition_not_supplied` and are never invented.

Each supplied step is evaluated as a **structural** check with cited evidence — chart setup, cuspal focus, planetary motion, house significations, dusthana linkages, aspects, conjunctions, period mapping, ruling planets and transit alignment. Three of them (PROF-06 aspects, PROF-07 conjunction/opposition, PROF-10 transit alignment) are evaluated with a clearly disclosed product proxy, because the calculation core has no aspect module: ±10° conjunction / 170–190° opposition windows and the ruling-planet set are product conventions, not the professor's doctrine. Every step carries `is_probability: false`, `probability: null` and `binary_answer: "NOT DETERMINED"`.

The outline contains no thresholds, weights, outcome tables or calibration data, so no probability, score, YES/NO or accuracy figure can be derived from it. The app shows the steps in a dedicated "Supplied steps" tab with per-step evidence and the reason each one is not a likelihood; the AI prompt may cite `step:PROF-xx` evidence ids, and every step is rejected as a probability source by the same output contract that blocks percentages. Rule-slot accounting is reported as 10 of 21 defined, 0 calibrated, with 6 claimed-but-undefined steps and 11 undefined user rules still pending.

The Termux-specific tests cover standard-library validation, real local HTTP endpoints, authentication, bounded request bodies, HMAC server identity, private settings, provider-key isolation, asynchronous job reuse, mocked model request/response contracts, invalid evidence/probability rejection and source-bundle bootstrap. Browser tests cover chart output without an AI key, model-job completion/failure, input import, session preservation, setup controls, accessibility and no direct browser provider calls.

The retired cloud/general suites (52 browser cases and the cloud native-transport cases) are kept in the tree, clearly annotated, and are NOT counted here: they target the removed cloud transport and cannot pass against the Termux-only build. Their still-valid endpoint and browser cases were ported into the current suites. Software tests do not prove phone automation, provider account access or forecast validity.

## Numerical comparison maxima (arcseconds)

| Provider | Classical planets | Cusps | Mean node | True node |
|---|---:|---:|---:|---:|
| Swiss_files 2.10.03 | 2.004388 | 3.274921 | 1.893196 | 0.034399 |
| LibEphemeris_local 3.2.1 | 1.266145 | 0.832171 | 2.666650 | 0.830325 |
| LibEphemeris_bundled 3.2.1 | 1.266145 | 0.832171 | 2.666650 | 0.830325 |

These are sampled numerical residuals, not global error bounds or personal-event prediction accuracy. Swiss files were used only in the QA environment and are not bundled. Different input times, ayanamsa/data conventions and near-boundary uncertainty can change KP assignments.

## Explicit unverified gates

- No physical Android phone/emulator RUN_COMMAND, Termux:Boot, OEM battery, hardware Keystore or native picker test was performed here.
- No live paid model call was made: no user API key/account was provided. OpenAI/Gemini request contracts were mock-tested. Presets were checked against official provider documentation, not astrology benchmarks.
- The user's actual installed Python/library versions and data paths must be checked by the on-phone setup screen. Existing packages are not overwritten.
- The 11 user rules and the 1,500+ numbered master rules remain unsupplied, and 6 of the 16 claimed professor steps have no definition at all. The 10 supplied outline steps carry no thresholds, weights or calibration, so no probability, YES/NO, endorsement, 81.2% score or precise life-event guarantee is claimed.
- Swiss/libephemeris AGPL/commercial obligations, owner release signing, store/privacy/security review remain. This APK is a debug-signed device-validation preview.

## Important protections

Only fixed bundled setup/start commands can be sent through the native Termux interface. Queries and provider API keys are not shell commands. The user must explicitly enable the Termux property and Android permission. The server binds to loopback on the phone, authenticates local requests and answers an HMAC identity challenge before the native client sends sensitive requests. Model keys stay in a private mode-0600 Termux configuration and are omitted from status/diagnostics. Provider requests use fixed HTTPS hosts, no redirects and no automatic paid retry. Failure leaves the calculated record separate from any AI answer.

Review the code and device behavior before using real credentials or distributing the app. “Zero bugs” and “precise predictions” are not software-test conclusions.
