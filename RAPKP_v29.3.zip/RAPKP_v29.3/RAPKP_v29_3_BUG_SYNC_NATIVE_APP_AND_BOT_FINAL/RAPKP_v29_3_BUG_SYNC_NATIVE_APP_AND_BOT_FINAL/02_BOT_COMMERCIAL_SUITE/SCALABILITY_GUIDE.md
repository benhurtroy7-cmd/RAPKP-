# Scalability Guide

## MVP

Android APK + Render Free + SQLite.

## Production small business

Android APK + Render/Railway paid + PostgreSQL.

## Scale business

- Docker backend replicas
- PostgreSQL managed DB
- Object storage for PDFs
- CDN for static assets
- API gateway/rate limit
- Queue for PDF jobs
- Monitoring/logging

## Replace SQLite with PostgreSQL

Use the included `postgres_schema.sql`. Migrate these tables:

- users
- charts
- predictions
- rules
- corrections
- bugs
- pdf_readings
- audit_logs

## Multi-tenant model

Add `tenant_id` to all tables for each client/customer business.
