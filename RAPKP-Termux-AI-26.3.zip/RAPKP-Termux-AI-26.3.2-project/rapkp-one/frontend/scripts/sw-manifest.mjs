import fs from 'node:fs';
import crypto from 'node:crypto';
const files = fs.readdirSync('site/assets').map(x => `/assets/${x}`);
const hash = crypto.createHash('sha256').update(files.join('\n')).digest('hex').slice(0,12);
const sw = `const CACHE='rapkp-ui-${hash}';\nconst ASSETS=${JSON.stringify(['/', '/icon.svg', '/icon-192.png', '/icon-512.png', '/manifest.webmanifest', ...files])};
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS))); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('rapkp-ui-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  // Never cache reports, POST bodies, credentials, health endpoints or external origins.
  if (e.request.method !== 'GET' || u.origin !== self.location.origin || u.pathname.startsWith('/api') || u.pathname.startsWith('/health') || e.request.headers.has('Authorization')) return;
  if (e.request.mode === 'navigate') { e.respondWith(fetch(e.request).catch(() => caches.match('/'))); return; }
  if (ASSETS.includes(u.pathname)) e.respondWith(caches.match(e.request).then(c => c || fetch(e.request)));
});\n`;
fs.writeFileSync('site/sw.js', sw);
