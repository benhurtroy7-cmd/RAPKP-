"""Adapters to user-installed Swiss/libephemeris. No silent engine or house fallback."""

import hashlib
import importlib
import importlib.util
import math
import os
from datetime import timezone
from pathlib import Path
from threading import RLock

from ..errors import CalculationError
from ..kp import house_of, lords

PLANETS = ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn"]
LOCKS = {"swisseph": RLock(), "libephemeris": RLock()}


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def available():
    result = {}
    for name in ["swisseph", "libephemeris"]:
        try:
            m = importlib.import_module(name)
            result[name] = {
                "installed": True,
                "version": str(getattr(m, "__version__", getattr(m, "version", "unknown"))),
            }
        except Exception:
            result[name] = {"installed": False, "error": "Module not importable in this Python environment"}
    return result


def find_swiss_path(home):
    root = Path(home)
    candidates = []
    for s in os.getenv("SE_EPHE_PATH", "").split(os.pathsep):
        if s:
            candidates.append(Path(s))
    candidates += [
        root / "ephe",
        root / "swisseph/ephe",
        root / "sweph/ephe",
        root / ".local/share/swisseph",
        Path(os.getenv("PREFIX", str(root.parent / "usr"))) / "share/ephe",
    ]
    count = 0
    for base, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in {".cache", ".npm", "node_modules", ".git", "storage", ".venv"}]
        if len(Path(base).relative_to(root).parts) > 4:
            dirs[:] = []
            continue
        count += len(files)
        if "sepl_18.se1" in files and "semo_18.se1" in files:
            candidates.append(Path(base))
        if count > 15000:
            break
    for p in candidates:
        if (p / "sepl_18.se1").is_file() and (p / "semo_18.se1").is_file():
            return str(p.resolve())
    return ""


class SwissAdapter:
    def __init__(self, provider="swisseph", ephe_path="", allow_moshier=False, lib_file=""):
        if provider not in {"swisseph", "libephemeris"}:
            raise CalculationError("ENGINE_CHOICE", "Choose Swiss Ephemeris or libephemeris.", 422)
        try:
            self.s = importlib.import_module(provider)
        except Exception as e:
            raise CalculationError(
                "ENGINE_MISSING",
                f"{provider} is not importable in Termux. Check the installed Python environment.",
                503,
            ) from e
        self.provider = provider
        self.lock = LOCKS[provider]
        self.allow_moshier = allow_moshier
        self.path = ephe_path
        self.version = str(
            getattr(self.s, "version", "unknown")
            if provider == "swisseph"
            else getattr(self.s, "__version__", "unknown")
        )
        self.fn = self.s
        files = []
        if provider == "swisseph":
            if not allow_moshier:
                for name in ["sepl_18.se1", "semo_18.se1"]:
                    p = Path(ephe_path) / name
                    if not p.is_file():
                        raise CalculationError(
                            "EPHEMERIS_FILES_MISSING",
                            "Swiss files sepl_18.se1 and semo_18.se1 were not found. Choose your ephemeris folder in Termux setup. No zero/Moshier chart is silently substituted.",
                            503,
                        )
                    files.append(p)
            self.s.set_ephe_path(ephe_path or "/no-implicit-data")
        else:
            for name in ["set_auto_spk_download", "set_iers_auto_download"]:
                if hasattr(self.s, name):
                    getattr(self.s, name)(False)
            if lib_file:
                p = Path(lib_file)
                if not p.is_file():
                    raise CalculationError(
                        "EPHEMERIS_FILES_MISSING", "The selected local libephemeris data file does not exist.", 503
                    )
                files.append(p)
            # New libephemeris ships a sealed local LEB2 core; older installs may require
            # an explicit local BSP file. Context API is used when a local file is selected.
            if lib_file and hasattr(self.s, "EphemerisContext"):
                self.fn = self.s.EphemerisContext(ephe_path=str(Path(lib_file).parent), ephe_file=Path(lib_file).name)
            else:
                if not (Path(self.s.__file__).parent / "data/leb2/base_core.leb2").is_file():
                    raise CalculationError(
                        "EPHEMERIS_FILES_MISSING",
                        "This libephemeris installation needs an explicit existing local BSP file. No data download is started by this connector.",
                        503,
                    )
                files.append(Path(self.s.__file__).parent / "data/leb2/base_core.leb2")
                self.fn = self.s  # current LibEphemeris can use its bundled local LEB backend
        self.fingerprints = {p.name: file_hash(p) for p in files}
        self.report_metadata = {
            "engine": f"{provider} {self.version} on Termux",
            "provider": provider,
            "provider_version": self.version,
            "ephemeris_files_sha256": self.fingerprints,
            "fingerprint": hashlib.sha256(
                (provider + self.version + str(self.fingerprints) + str(allow_moshier)).encode()
            ).hexdigest(),
            "integrity_status": "recorded",
            "integrity_detail": "Installed provider/version and local ephemeris file hashes recorded. This is not external chart certification.",
            "true_node_note": f"True-node convention is supplied by {provider}; near-boundary results require attention.",
        }

    def c(self, name):
        for key in [name, "SE_" + name, "SE" + name if name.startswith("FLG_") else name]:
            if hasattr(self.s, key):
                return getattr(self.s, key)
        if name.startswith("FLG_") and hasattr(self.s, "SE" + name):
            return getattr(self.s, "SE" + name)
        raise CalculationError(
            "PROVIDER_INTERFACE", "Installed ephemeris library does not expose the required calculation interface.", 503
        )

    def _sid(self):
        self.s.set_sid_mode(self.c("SIDM_KRISHNAMURTI"))
        if self.provider == "swisseph":
            self.s.set_ephe_path(self.path or "/no-implicit-data")
        if self.fn is not self.s:
            self.fn.set_sid_mode(self.c("SIDM_KRISHNAMURTI"))

    def chart_at(self, moment, latitude, longitude, node_mode="mean"):
        if moment.tzinfo is None:
            raise ValueError("Aware time required")
        u = moment.astimezone(timezone.utc)
        with self.lock:
            fn = getattr(self.fn, "utc_to_jd", getattr(self.s, "utc_to_jd", None))
            if fn is None:
                raise CalculationError(
                    "PROVIDER_INTERFACE", "UTC to UT1 conversion is unavailable in this provider.", 503
                )
            try:
                jd = fn(u.year, u.month, u.day, u.hour, u.minute, u.second + u.microsecond / 1e6, self.c("GREG_CAL"))[1]
            except Exception as e:
                raise CalculationError(
                    "TIME_CONVERSION", "Ephemeris time conversion failed; check the provider and date.", 422
                ) from e
            result = self.calculate_at_ut1(float(jd), latitude, longitude, node_mode)
            result["utc"] = u.isoformat()
            return result

    def calculate_at_ut1(self, jd, latitude, longitude, node_mode="mean"):
        if not all(math.isfinite(float(v)) for v in [jd, latitude, longitude]) or not -180 <= longitude <= 180:
            raise CalculationError("INVALID_COORDINATES", "Finite, valid coordinates are required.")
        if abs(latitude) >= 66:
            raise CalculationError(
                "PLACIDUS_LATITUDE", "Placidus is supported only inside ±66°. No other house system is substituted."
            )
        if node_mode not in {"mean", "true"}:
            raise CalculationError("NODE_MODE", "Choose mean or true nodes.")
        with self.lock:
            try:
                self._sid()
                sid = self.c("FLG_SIDEREAL")
                speedflag = self.c("FLG_SPEED")
                base = self.c("FLG_MOSEPH") if self.allow_moshier else self.c("FLG_SWIEPH")
                housefn = getattr(self.fn, "houses_ex", self.s.houses_ex)
                raw, angles = housefn(jd, latitude, longitude, b"P" if self.provider == "swisseph" else ord("P"), sid)
                cusps = list(map(float, raw))
                cusps = cusps[1:] if len(cusps) == 13 else cusps
                if len(cusps) != 12 or not all(math.isfinite(x) for x in cusps):
                    raise ValueError("Invalid cusp array")
                house_of(cusps[0], cusps)
                bodies = {}
                returned = []
                names = PLANETS + [("MeanNode" if node_mode == "mean" else "TrueNode")]
                for name in names:
                    idname = "MEAN_NODE" if name == "MeanNode" else "TRUE_NODE" if name == "TrueNode" else name.upper()
                    pos, flags = self.fn.calc_ut(jd, self.c(idname), base | sid | speedflag)
                    lon = float(pos[0]) % 360
                    spd = float(pos[3])
                    returned.append(int(flags))
                    if (
                        self.provider == "swisseph"
                        and not self.allow_moshier
                        and name in PLANETS
                        and not (int(flags) & self.c("FLG_SWIEPH"))
                    ):
                        raise CalculationError(
                            "EPHEMERIS_FALLBACK_BLOCKED",
                            "Swiss data was not used for a required planet. Check the data files; no silent substitute is accepted.",
                            503,
                        )
                    if not all(math.isfinite(x) for x in [lon, spd]):
                        raise ValueError("Non-finite body")
                    label = "Rahu" if name in {"MeanNode", "TrueNode"} else name
                    bodies[label] = {
                        "name": label,
                        "longitude": lon,
                        "speed": spd,
                        "retrograde": bool(spd < 0),
                        "near_station": bool(abs(spd) < 0.0001),
                        "house": house_of(lon, cusps),
                        **lords(lon),
                    }
                rahu = bodies["Rahu"]
                lon = (rahu["longitude"] + 180) % 360
                bodies["Ketu"] = {**rahu, "name": "Ketu", "longitude": lon, "house": house_of(lon, cusps), **lords(lon)}
                ayfn = getattr(self.fn, "get_ayanamsa_ut", getattr(self.s, "get_ayanamsa_ut", None))
                ay = float(ayfn(jd))
                warnings = []
                if self.allow_moshier:
                    warnings.append(
                        "Moshier mode was explicitly selected for QA; this is not a Swiss-data-file result."
                    )
                for name, p in bodies.items():
                    margin = 60 if name in {"Rahu", "Ketu"} and node_mode == "true" else 5
                    if min(p["sub_boundary_distance_arcsec"], p["sub_sub_boundary_distance_arcsec"]) < margin:
                        warnings.append(
                            f"{name} is close to a KP boundary; input/model differences may change its assigned lord."
                        )
                self.report_metadata["returned_flags"] = returned
                return {
                    "jd_ut1": jd,
                    "latitude": latitude,
                    "longitude": longitude,
                    "zodiac": "sidereal",
                    "house_system": "Placidus",
                    "ayanamsa": {"name": "Krishnamurti", "mean_degrees": ay, "method": self.provider},
                    "angles": {"ascendant": cusps[0], "midheaven": cusps[9], "armc": float(angles[2])},
                    "node_mode": node_mode,
                    "bodies": bodies,
                    "cusps": [{"house": i + 1, "longitude": x, **lords(x)} for i, x in enumerate(cusps)],
                    "warnings": warnings,
                    "conventions": [
                        "Geocentric apparent positions",
                        "Explicit Krishnamurti sidereal mode",
                        "Provider UTC→UT1 conversion",
                        "No zero/equal-house/implicit engine fallback",
                    ],
                }
            except CalculationError:
                raise
            except Exception as e:
                raise CalculationError(
                    "CALCULATION_FAILED",
                    "The installed ephemeris provider failed. Review diagnostics/data paths; no chart was substituted.",
                    503,
                ) from e

    def close(self):
        pass
