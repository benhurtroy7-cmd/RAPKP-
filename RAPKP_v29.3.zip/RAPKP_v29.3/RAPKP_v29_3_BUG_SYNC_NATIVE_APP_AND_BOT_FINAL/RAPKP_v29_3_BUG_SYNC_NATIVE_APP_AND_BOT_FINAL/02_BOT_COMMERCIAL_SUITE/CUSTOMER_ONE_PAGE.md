# RAPKP Customer Handout

This product provides KP astrology timing analysis through an Android app and cloud API.

Features:

- Ask any astrology timing question
- Multi-person chart management
- PDF chart reports
- PDF document reading
- Rules/corrections learning
- Cloud-based commercial prediction engine

Commercial note:

Predictions are probability-based astrology analysis, not guarantees.
