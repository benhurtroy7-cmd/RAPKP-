#!/usr/bin/env python3
"""Build truthful, versioned Termux handover evidence and atomic deliverables."""
import hashlib
import json
import os
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import markdown

ROOT=Path(__file__).resolve().parents[1]
VERSION='26.3.2-termux.1'
BUILD=2603012
SHORT=VERSION.rsplit('-termux')[0]
def read(p):return json.loads((ROOT/p).read_text())
def cases(p):
 rows=list(ET.parse(ROOT/p).getroot().iter('testcase'));return {'passed':sum(x.find('failure') is None and x.find('error') is None and x.find('skipped') is None for x in rows),'failed':sum(x.find('failure') is not None or x.find('error') is not None for x in rows),'skipped':sum(x.find('skipped') is not None for x in rows)}
def prepare():
 backend=cases('qa/pytest-results.xml');browser=read('qa/playwright-results.json')['stats'];native=cases('qa/native-transport-tests.xml');java=cases('qa/android/26.3/TEST-com.rapkp.one.ConnectionCipherTest.xml');android=read('qa/android/26.3/artifact-verification.json');coverage=read('qa/coverage.json')['totals'];comparison=read('qa/termux-engine-comparison.json')
 assert not any(x['failed'] or x['skipped'] for x in [backend,native,java]);assert not browser['unexpected'] and not browser['skipped'];assert android['version']==VERSION and not android['lint_errors'] and not android['lint_warnings']
 hashes={}
 for folder in ['backend/rapkp','backend/tests','frontend/src','frontend/tests','frontend/android/app/src','termux-connector']:
  for p in (ROOT/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 result={'product':'RAPKP Termux AI','version':VERSION,'status':'passed','tested_at':datetime.now(timezone.utc).isoformat(),'release_status':'device-validation-preview','automated_tests':backend,'browser_tests':{'passed':browser['expected'],'failed':browser['unexpected'],'scope':'Desktop/mobile Chromium views; model responses mocked for UI tests'},'native_client_tests':{**native,'scope':'Mocked native transport and local-server challenge validation'},'java_crypto_tests':{**java,'scope':'JVM cryptography, not Android hardware/Termux execution'},'coverage_percent':coverage['percent_covered'],'android':android,'reference_fixtures':comparison['fixtures'],'engine_comparison':comparison,'source_rules_expected':21,'source_rules_defined':10,'source_rules_calibrated':0,'event_prediction_accuracy':None,'physical_termux_tested':False,'live_model_tested':False,'tested_source_sha256':hashes}
 (ROOT/'qa/verification.json').write_text(json.dumps(result,indent=2)+'\n')
 guide=(ROOT/'docs/TERMUX_AI_START.md').read_text();(ROOT/'README.md').write_text(guide)
 report=f'''# RAPKP Termux AI — QA handover

**{VERSION} · {result['tested_at']}**

## Implemented route

APK → paired loopback Termux connector → actual installed ephemeris → bounded asynchronous AI job → app. The APK embeds a source-only connector, not Python/Swiss binaries, API credentials or a permanent cloud endpoint.

## Executed evidence

| Check | Result |
|---|---:|
| Python backend/contract/provider/security cases | {backend['passed']} passed; {backend['failed']} failed; {backend['skipped']} skipped |
| Python statement coverage | {coverage['percent_covered']:.2f}% |
| New Termux UI/browser cases | {browser['expected']} passed |
| Native transport/server-identity mock cases | {native['passed']} passed |
| Java crypto cases | {java['passed']} passed |
| Android build and lint | Compiled; 0 errors / 0 warnings |
| Signing continuity | Same preview certificate/package as the previous Termux build; higher build {BUILD} |
| APK/source consistency | Current built UI and embedded connector hashes checked |
| Supplied professor rule steps | 10 of 21 slots have a public structural outline; evaluated per report with cited evidence, 0 calibrated |
| Provider comparison | 95 UT1 fixtures per provider/mode against the independent pinned JPL adapter |
| Pairing/port reclaim regression | Install, re-pair after home removal, re-pair with a mismatched stored token, foreign service on the port, and stale stop-request handling all verified against the real connector |

## What 26.3.2 adds

26.3.1 fixed a pairing dead-end reported from a real install: after `~/.rapkp-one` had been removed (or its stored token no longer matched the running instance), the previously installed connector kept port 8765 with the old key. Every later install/start died with `Address already in use`, and the app kept reporting that the local process was not the paired connector. Re-pairing could never recover, because the installer only stopped a running connector when it could still prove it owned that connector's token.

The installer now also stops a running RAPKP instance through a stop-request file inside the connector's own private home directory (the same trust boundary as the stored token, never reachable over the network). A stale request file is ignored, so it cannot kill a freshly started service. A service that fingerprints as something other than RAPKP is still never stopped or replaced. The server also logs an explicit message instead of a raw traceback when the port is taken, and the app now reports what actually answered the port (an older RAPKP instance, or a different service) instead of repeating "re-pair" forever.

Also in 26.3.1: the browser QA view labelled its calculation core "Swiss Ephemeris" although that backend computes with the pinned OpenEphem/Skyfield kernel. The status endpoint now reports the real engine and the interface shows it.

26.3.2 adds the rule layer the user supplied on 2026-10-03: a public 10-step structural outline of Prof. Krish Murali Eswar KP's method, attributed through public course outlines and masterclass previews. The outline's own headings claim 7 fundamental + 4 advanced + 5 timing = 16 steps, but only 10 steps are actually listed (4 + 3 + 3). The 6 claimed-but-unlisted steps are recorded as `definition_not_supplied` and are never invented.

Each supplied step is evaluated as a **structural** check with cited evidence — chart setup, cuspal focus, planetary motion, house significations, dusthana linkages, aspects, conjunctions, period mapping, ruling planets and transit alignment. Three of them (PROF-06 aspects, PROF-07 conjunction/opposition, PROF-10 transit alignment) are evaluated with a clearly disclosed product proxy, because the calculation core has no aspect module: ±10° conjunction / 170–190° opposition windows and the ruling-planet set are product conventions, not the professor's doctrine. Every step carries `is_probability: false`, `probability: null` and `binary_answer: "NOT DETERMINED"`.

The outline contains no thresholds, weights, outcome tables or calibration data, so no probability, score, YES/NO or accuracy figure can be derived from it. The app shows the steps in a dedicated "Supplied steps" tab with per-step evidence and the reason each one is not a likelihood; the AI prompt may cite `step:PROF-xx` evidence ids, and every step is rejected as a probability source by the same output contract that blocks percentages. Rule-slot accounting is reported as 10 of 21 defined, 0 calibrated, with 6 claimed-but-undefined steps and 11 undefined user rules still pending.

The Termux-specific tests cover standard-library validation, real local HTTP endpoints, authentication, bounded request bodies, HMAC server identity, private settings, provider-key isolation, asynchronous job reuse, mocked model request/response contracts, invalid evidence/probability rejection and source-bundle bootstrap. Browser tests cover chart output without an AI key, model-job completion/failure, input import, session preservation, setup controls, accessibility and no direct browser provider calls.

The retired cloud/general suites (52 browser cases and the cloud native-transport cases) are kept in the tree, clearly annotated, and are NOT counted here: they target the removed cloud transport and cannot pass against the Termux-only build. Their still-valid endpoint and browser cases were ported into the current suites. Software tests do not prove phone automation, provider account access or forecast validity.

## Numerical comparison maxima (arcseconds)

| Provider | Classical planets | Cusps | Mean node | True node |
|---|---:|---:|---:|---:|
'''
 for name,v in comparison['providers'].items():
  m=v['metrics'];report+=f"| {name} {v['version']} | {m['planets_arcsec']['max']:.6f} | {m['cusps_arcsec']['max']:.6f} | {m['mean_node_arcsec']['max']:.6f} | {m['true_node_arcsec']['max']:.6f} |\n"
 report+='''
These are sampled numerical residuals, not global error bounds or personal-event prediction accuracy. Swiss files were used only in the QA environment and are not bundled. Different input times, ayanamsa/data conventions and near-boundary uncertainty can change KP assignments.

## Explicit unverified gates

- No physical Android phone/emulator RUN_COMMAND, Termux:Boot, OEM battery, hardware Keystore or native picker test was performed here.
- No live paid model call was made: no user API key/account was provided. OpenAI/Gemini request contracts were mock-tested. Presets were checked against official provider documentation, not astrology benchmarks.
- The user's actual installed Python/library versions and data paths must be checked by the on-phone setup screen. Existing packages are not overwritten.
- The 11 user rules and the 1,500+ numbered master rules remain unsupplied, and 6 of the 16 claimed professor steps have no definition at all. The 10 supplied outline steps carry no thresholds, weights or calibration, so no probability, YES/NO, endorsement, 81.2% score or precise life-event guarantee is claimed.
- Swiss/libephemeris AGPL/commercial obligations, owner release signing, store/privacy/security review remain. This APK is a debug-signed device-validation preview.

## Important protections

Only fixed bundled setup/start commands can be sent through the native Termux interface. Queries and provider API keys are not shell commands. The user must explicitly enable the Termux property and Android permission. The server binds to loopback on the phone, authenticates local requests and answers an HMAC identity challenge before the native client sends sensitive requests. Model keys stay in a private mode-0600 Termux configuration and are omitted from status/diagnostics. Provider requests use fixed HTTPS hosts, no redirects and no automatic paid retry. Failure leaves the calculated record separate from any AI answer.

Review the code and device behavior before using real credentials or distributing the app. “Zero bugs” and “precise predictions” are not software-test conclusions.
'''
 (ROOT/'docs/QA_TERMUX_AI.md').write_text(report)
 css='body{font:15px/1.7 Arial,sans-serif;background:#f5f7f1;color:#2e4938;margin:0}main{max-width:1000px;margin:30px auto;background:white;padding:42px}h1,h2,h3{font-family:Georgia,serif;color:#305740}h1{font-size:34px}h2{margin-top:30px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{padding:9px;border:1px solid #dce4d3;text-align:left}th{background:#edf4e5}code{font-size:12px}pre{padding:18px;background:#2e503a;color:white;white-space:pre-wrap}a{color:#286146}@page{size:A4;margin:15mm}@media print{body{background:white;font-size:12px}main{padding:0;margin:0}h2{break-after:avoid}tr{break-inside:avoid}}@media(max-width:600px){main{padding:22px;margin:0}h1{font-size:27px}table{font-size:10px}}'
 def render(text,title):return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+css+'</style></head><body><main>'+markdown.markdown(text,extensions=['tables','fenced_code'])+'</main></body></html>'
 (ROOT/'START_HERE.html').write_text(render(guide,'RAPKP Termux AI — setup'))
 (ROOT/'docs/QA_TERMUX_AI.html').write_text(render(report,'RAPKP Termux AI — QA'))
 print('Prepared current evidence:',backend,native,'browser',browser['expected'])

EXCLUDED={'.git','.venv','node_modules','__pycache__','.pytest_cache','.ruff_cache','.hypothesis','.cache','.gradle','test-results','playwright-report','build','dist','coverage','out','target','xcuserdata'}
def files():
 for base,dirs,names in os.walk(ROOT):
  dirs[:]=[d for d in dirs if d not in EXCLUDED]
  for name in names:
   p=Path(base)/name;rel=p.relative_to(ROOT).as_posix()
   if name in {'.env','.coverage','local.properties','.DS_Store'} or (name.startswith('.env.') and name!='.env.example') or name.endswith(('.pyc','.tsbuildinfo','.jks','.keystore','.p12','.mobileprovision')):continue
   if rel=='data/de440s.bsp' or (rel.startswith('native-artifacts/') and f'RAPKP-Termux-AI-{SHORT}' not in name):continue
   if p.is_symlink():continue
   yield p

def package():
 q=read('qa/verification.json');assert q['version']==VERSION
 for name,digest in q['tested_source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 apk=ROOT/f'native-artifacts/android/RAPKP-Termux-AI-{SHORT}.apk';aab=apk.with_name(f'RAPKP-Termux-AI-{SHORT}-unsigned.aab')
 assert hashlib.sha256(apk.read_bytes()).hexdigest()==q['android']['apk_sha256']
 release={'product':'RAPKP Termux AI','version':VERSION,'android_build':BUILD,'package':'com.rapkp.one.preview','launcher':'RAPKP Termux AI','scope':'Termux-only source connector + existing ephemerides + optional hosted AI via Termux','apk':apk.relative_to(ROOT).as_posix(),'aab':aab.relative_to(ROOT).as_posix(),'apk_sha256':q['android']['apk_sha256'],'setup':'START_HERE.html','qa':'docs/QA_TERMUX_AI.pdf','physical_phone_tested':False,'live_model_tested':False,'prediction_accuracy_established':False,'library_binaries_bundled':False,'model_key_bundled':False}
 (ROOT/'RELEASE.json').write_text(json.dumps(release,indent=2)+'\n')
 checks=[]
 for p in sorted(files()):
  if p.name!='CHECKSUMS.sha256':checks.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix())
 (ROOT/'CHECKSUMS.sha256').write_text('\n'.join(checks)+'\n')
 dest=ROOT.parent/f'RAPKP-Termux-AI-{SHORT}-project.zip';temp=ROOT.parent/'.cache/rapkp-termux-release.partial';temp.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(files()):z.write(p,'rapkp-one/'+p.relative_to(ROOT).as_posix())
 with zipfile.ZipFile(temp) as z:
  assert z.testzip() is None
  for line in z.read('rapkp-one/CHECKSUMS.sha256').decode().splitlines():
   digest,rel=line.split('  ',1);assert hashlib.sha256(z.read('rapkp-one/'+rel)).hexdigest()==digest,rel
  assert 'rapkp-one/frontend/android/app/src/main/assets/termux/backend.zip' in z.namelist()
  print('Checked archive:',len(z.namelist()),'files')
 temp.replace(dest);standalone=ROOT.parent/f'RAPKP-Termux-AI-{SHORT}.apk';standalone.write_bytes(apk.read_bytes())
 for p in [dest,standalone]:p.with_suffix(p.suffix+'.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n');print(p.name,round(p.stat().st_size/1024/1024,2),'MiB')
if __name__=='__main__':
 import sys
 prepare() if len(sys.argv)<2 or sys.argv[1]=='prepare' else package()
