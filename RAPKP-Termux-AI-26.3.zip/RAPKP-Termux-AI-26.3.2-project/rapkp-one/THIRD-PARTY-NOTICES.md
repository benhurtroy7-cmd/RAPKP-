# Termux edition licensing notice

This release can use the user-installed **pyswisseph / Swiss Ephemeris** and **libephemeris** engines. LibEphemeris 3.2.1 is AGPL-3.0-only; Swiss Ephemeris has AGPL/commercial licensing arrangements. Earlier statements about a purely permissive runtime applied to the old OpenEphem-only baseline, not this Termux edition.

No Swiss/library binary or Swiss data file is included in the connector or APK. The installed phone packages/data are reused. The new Termux-runtime source is offered under AGPL-3.0-only; shared MIT primitives and the app source retain their notices. Complete new connector source is embedded as assets/termux/backend.zip and included in this source project. Review all obligations before commercial redistribution; no legal certification is implied.

See termux-connector/LICENSING.md and licenses/AGPL-3.0.txt. Native Android/Capacitor dependencies and model provider terms remain distinct. Models require the user's own API account/key and may incur charges.

## Earlier component notices (historical baseline)

# Third-party notices and commercial-use boundary

**Keep the entire `licenses/` directory with distributions.** It contains the installed licence/notice texts and a machine-readable dependency inventory for this build. `LICENSE` covers the newly generated application source only. Historical input documents and third-party names retain their rights.

## Main runtime components

| Component | Recorded licensing basis | Use |
|---|---|---|
| OpenEphem 0.3.0 | MIT; upstream notice retained | KP ayanamsa polynomial, Placidus geometry and astronomical primitives |
| Skyfield 1.55 | MIT | Time scales, apparent positions, IAU 2000A nutation |
| JPL DE440s | NASA/JPL ephemeris data; upstream identifies this as public-domain government data | Bundled numerical kernel, pinned by SHA-256 |
| NumPy 2.3.5 | BSD-family code plus bundled component notices | Numerical computations |
| jplephem, sgp4 | MIT metadata / retained notices | Skyfield transitive dependencies |
| FastAPI, Uvicorn, Pydantic | MIT metadata / retained notices | API and input contracts |
| Starlette, other transitive runtime libraries | See inventory and full notices | HTTP, typing, data validation |
| certifi | MPL-2.0 | CA certificate bundle dependency; preserve its notice and any applicable source obligations |
| React, Vite, Capacitor, Lucide | MIT / ISC / other permissive notices as recorded | Web build and native shells |
| IANA tzdata | Public-domain time data plus Python packaging notice | Timezone/DST conversion |
| Valkey image (not redistributed in the ZIP) | BSD-3-Clause project; operator obtains the image | Optional shared throttling |
| Caddy image (not redistributed in the ZIP) | Apache-2.0 project; operator obtains the image | Optional TLS edge |

Not every dependency is “MIT”. NumPy binary distributions may include additional compiler/runtime notices and licence exceptions; read the retained texts. The certifi certificate bundle is MPL-2.0, not MIT. It does not convert the application into AGPL, but it must not be erased from the inventory. Check the exact packages/images you redistribute.

**The earlier OpenEphem-only baseline did not depend on Swiss at runtime. This Termux edition does, when selected; the library itself is not bundled.** A separately installed offline Swiss/Moshier process was used to produce factual numeric comparison fixtures. Its executable/library is not redistributed. Those fixtures are references, not an AstroSage connection or an endorsement by Astrodienst.

## Known build-chain change

The current Capacitor CLI's `xcode` dependency requested an old `uuid` package with advisory GHSA-w5hq-g745-h8pq. The release overrides `xcode → uuid` to **11.1.1**, which retains the CommonJS `v4` interface used by xcode. Native sync and UUID generation are checked after the override. Keep this override until an upstream fix is verified. Full and runtime npm audits are recorded in `qa/`.

## Commercial release review

This is a technical inventory, **not a legal opinion or blanket “commercial ready” certification**. Before distributing: review exact code/data licences and notice obligations; verify ownership of RAPKP branding, app IDs and supplied historical code; obtain permission for any professor's name/rule collection; do not imply NASA, Google, OpenAI, AstroSage or Arena endorsement; review provider terms, privacy obligations, and store policies.

Model usage, cloud hosting, signing/developer accounts, and app-store distribution can incur charges even when the calculation code itself has no required Swiss Ephemeris commercial licence.

## Android 26.2 update

New project-authored Java Keystore/document-picker code is covered by the project MIT notice. Capacitor App 8.1.1 was added (installed notice retained). Gradle is pinned to 8.14.5 with a distribution checksum; AppCompat is 1.8.0. Android platform/build tooling is not redistributed. Before store release, review the exact compiled AndroidX/Cordova/native dependency graph and its notices in addition to this Python/npm inventory; a zero lint/advisory count is not a legal or native supply-chain certification.
