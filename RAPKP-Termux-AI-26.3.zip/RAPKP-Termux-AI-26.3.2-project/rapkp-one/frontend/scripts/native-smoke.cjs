const fs = require('node:fs');
const xcode = require('xcode');
const project=xcode.project('ios/App/App.xcodeproj/project.pbxproj');
project.parseSync();
if(!/^[A-F0-9]{24}$/.test(project.generateUuid())) throw new Error('Patched UUID API incompatible with xcode');
for(const file of ['android/app/src/main/assets/public/index.html','ios/App/App/public/index.html','android/app/src/main/AndroidManifest.xml']) if(!fs.existsSync(file)) throw new Error(`Missing generated source/asset: ${file}`);
const manifest=fs.readFileSync('android/app/src/main/AndroidManifest.xml','utf8');
if(!manifest.includes('android:allowBackup="false"') || !manifest.includes('@xml/network_security_config')) throw new Error('Native security source configuration missing');
console.log('Native project/asset source checks and patched UUID compatibility passed. No platform compilation/signing/device test.');
