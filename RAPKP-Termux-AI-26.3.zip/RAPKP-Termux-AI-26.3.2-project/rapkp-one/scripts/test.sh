#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${RAPKP_PYTHON:-.venv/bin/python}"
"$PYTHON" -m pytest --junitxml=qa/pytest-results.xml --cov=rapkp --cov-report=term-missing --cov-report=json:qa/coverage.json
# The browser suite expects a separately running local server. Do not run it
# against a production service or use real personal data in test fixtures.
