export const APP_VERSION = '26.3.2-termux.1';
export const APP_SERIES = '26.3';
export const ANDROID_BUILD = '2603012';
export const ANDROID_PREVIEW_ID = 'com.rapkp.one.preview';
