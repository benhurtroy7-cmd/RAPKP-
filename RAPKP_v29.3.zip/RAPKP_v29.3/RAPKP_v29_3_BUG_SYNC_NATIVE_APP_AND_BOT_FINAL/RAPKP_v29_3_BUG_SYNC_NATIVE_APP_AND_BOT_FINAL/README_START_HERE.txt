RAPKP v29.3 BUG SYNC FINAL: Native App + BOT Commercial Suite

Install this APK:
01_NATIVE_ANDROID_APP/RAPKP_v29_3_BUG_SYNC_NATIVE_APP.apk

APK identity:
- App display name: RAPKP BOT
- Android package: in.rapkp.v26
- versionCode: 38
- versionName: v29.3 Bug Sync BOT
- Auto cloud: https://rapkp-v26.onrender.com

Fixes:
- Bug reports are visible on Render API but do not automatically corrupt predictions.
- Empty-query note corrections are blocked/ignored.
- Correction must include query/date to update future predictions.
- PDF upload no longer reuses old query like third marriage for another person's PDF chart.
- flat 302 is still normalized to flat/property.

To update live Render/GitHub:
Use 04_DEPLOYMENT_PACKAGES/RAPKP_RENDER_UPLOAD_ONLY_3_FILES.zip
Upload server.py, engine.py, domains.py to GitHub, then Render Manual Deploy.

Live bug check endpoint:
https://rapkp-v26.onrender.com/api/bugs?token=KVYezIWxlkS6bwKDAi4i1pT3l7PLNvO2
