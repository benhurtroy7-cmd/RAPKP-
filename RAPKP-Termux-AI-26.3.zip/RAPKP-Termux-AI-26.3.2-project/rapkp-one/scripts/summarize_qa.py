#!/usr/bin/env python3
"""Produce version-specific QA evidence from actual test outputs."""
import hashlib
import json
import platform
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
VERSION='26.3.0-termux.1'
def read(name):return json.loads((ROOT/name).read_text())
def junit(name):
 cases=list(ET.parse(ROOT/name).getroot().iter('testcase'))
 return {'passed':sum(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases),'failed':sum(c.find('failure') is not None or c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
def main():
 backend=junit('qa/pytest-results.xml');browser=read('qa/playwright-results.json')['stats'];native=junit('qa/native-transport-tests.xml');upgrade=junit('qa/upgrade-client-tests.xml');java=junit('qa/android/26.2/TEST-com.rapkp.one.ConnectionCipherTest.xml')
 assert not any(x['failed'] or x['skipped'] for x in [backend,native,upgrade,java]);assert not browser['unexpected'] and not browser['skipped']
 residual=read('qa/reference-residuals.json');m=residual['metrics'];c=read('qa/coverage.json')['totals'];android=read('qa/android/26.2/artifact-verification.json')
 assert android['version']==VERSION and not android['lint']['errors'] and not android['lint']['warnings']
 hashes={}
 for folder in ['backend/rapkp','backend/tests','frontend/src','frontend/tests','frontend/android/app/src','integrations']:
  for p in (ROOT/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 result={'product':'RAPKP One','version':VERSION,'status':'passed','release_status':'android_preview_not_store_approved','tested_at':datetime.now(timezone.utc).isoformat(),'current_release_regression_complete':True,'environment':{'python':platform.python_version(),'platform':platform.platform()},'automated_tests':{**backend,'total':sum(backend.values())},'browser_tests':{'passed':browser['expected'],'failed':browser['unexpected'],'skipped':browser['skipped'],'scope':'Chromium desktop/mobile viewports, not physical phones'},'native_client_tests':{**native,'scope':'Mocked Capacitor HTTP transport'},'upgrade_client_tests':{**upgrade,'scope':'Input/report import and mocked native storage/export contracts'},'java_crypto_tests':{**java,'scope':'JVM AES-GCM tests, not Android hardware Keystore execution'},'coverage':{'statement_percent':round(c['percent_covered'],4),'covered':c['covered_lines'],'statements':c['num_statements']},'reference_fixtures':residual['fixtures'],'reference_chart_evaluations':residual['fixtures']*2,'measured':{'planets_max_arcsec':m['planets_arcsec']['max'],'cusps_max_arcsec':m['cusps_arcsec']['max'],'mean_node_max_arcsec':m['mean_node_arcsec']['max'],'true_node_max_arcsec':m['true_node_arcsec']['max']},'android':android,'dependency_scan':{'python_known_findings':sum(len(x.get('vulns',[])) for x in read('qa/python-dependency-audit.json')['dependencies']),'npm_full':read('qa/npm-full-audit.json')['metadata']['vulnerabilities'],'npm_runtime':read('qa/npm-runtime-audit.json')['metadata']['vulnerabilities'],'scope':'Python/npm known-advisory scans only; not a penetration test or full native dependency audit'},'source_rules_verified':0,'source_rules_requested':21,'event_prediction_accuracy':None,'release_gates':['Physical Android/Termux and native hardware/storage/export/navigation validation','Owner release signing, store/privacy/licensing/identity review','iOS source only; no macOS/iOS build/device test','Live AI/provider connections and production deployment not performed','Separate V17–V25 releases and complete numbered 21-rule definitions unavailable','No empirical personal-event prediction calibration'],'tested_source_sha256':hashes}
 (ROOT/'qa/verification.json').write_text(json.dumps(result,indent=2)+'\n')
 print('Evidence:',backend['passed'],'backend;',browser['expected'],'browser;',native['passed'],'transport;',upgrade['passed'],'upgrade client;',java['passed'],'JVM crypto. Native lint 0/0.')
if __name__=='__main__':main()
