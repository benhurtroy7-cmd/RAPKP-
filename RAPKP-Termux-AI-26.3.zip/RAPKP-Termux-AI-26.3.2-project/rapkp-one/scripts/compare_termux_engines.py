#!/usr/bin/env python3
"""Independent adapter comparison; never treat numeric residuals as forecast accuracy."""
import json
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'backend'))
from rapkp.engine import AstroEngine, angular_distance  # noqa: E402  (import after sys.path setup)
from rapkp.termux_runtime.providers import SwissAdapter  # noqa: E402  (import after sys.path setup)


def main():
 p=Path(sys.argv[1])
 reference=json.loads((ROOT/'backend/tests/fixtures/astronomy-reference.json').read_text())['fixtures']
 old=AstroEngine(ROOT/'data/de440s.bsp')
 providers={'Swiss_files':SwissAdapter('swisseph',str(p)),'LibEphemeris_local':SwissAdapter('libephemeris',lib_file=str(ROOT/'data/de440s.bsp')),'LibEphemeris_bundled':SwissAdapter('libephemeris')}
 result={'tested_at':datetime.now(timezone.utc).isoformat(),'fixtures':len(reference),'scope':'Current installed adapters compared against the independent pinned OpenEphem/Skyfield/JPL adapter at identical UT1. Numeric agreement only; not life-event accuracy. Swiss data used only in QA, not bundled.','providers':{}}
 for name,engine in providers.items():
  metrics={k:[] for k in ['planets_arcsec','cusps_arcsec','mean_node_arcsec','true_node_arcsec']}
  for row in reference:
   for mode in ['mean','true']:
    a=engine.calculate_at_ut1(row['jd_ut1'],row['latitude'],row['longitude'],mode);b=old.calculate_at_ut1(row['jd_ut1'],row['latitude'],row['longitude'],mode)
    if mode=='mean':
     for body in ['Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn']:metrics['planets_arcsec'].append(angular_distance(a['bodies'][body]['longitude'],b['bodies'][body]['longitude'])*3600)
     for x,y in zip(a['cusps'],b['cusps'],strict=True):metrics['cusps_arcsec'].append(angular_distance(x['longitude'],y['longitude'])*3600)
    metrics[mode+'_node_arcsec'].append(angular_distance(a['bodies']['Rahu']['longitude'],b['bodies']['Rahu']['longitude'])*3600)
  result['providers'][name]={'version':engine.version,'metrics':{k:{'n':len(v),'max':max(v),'mean':statistics.mean(v)} for k,v in metrics.items()}}
 old.close();(ROOT/'qa/termux-engine-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
