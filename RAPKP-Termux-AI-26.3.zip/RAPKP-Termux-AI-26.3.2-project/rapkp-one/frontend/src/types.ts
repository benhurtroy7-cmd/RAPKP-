export type Place = { label: string; latitude: number; longitude: number; timezone: string };
export type MomentInput = { date: string; time: string; place: Place; fold?: 0 | 1 | null };
export type ReadingInput = {
  birth: MomentInput & { uncertainty_seconds: number };
  analysis: MomentInput;
  domain: string;
  question: string;
  node_mode: 'mean' | 'true';
  include_transits: boolean;
};
export type Point = { longitude: number; sign: string; house: number; star_lord: string; sub_lord: string; sub_sub_lord: string; sign_lord: string; nakshatra: string; pada: number };
export type Body = Point & { name: string; speed: number; retrograde: boolean; near_station: boolean };
export type Chart = { bodies: Record<string, Body>; cusps: Point[]; angles: { ascendant: number; midheaven: number }; utc?: string; ayanamsa: { mean_degrees: number }; node_mode: string };
export type Period = { lord: string; start: string; end: string; level: string; mahadasha?: string; bhukti?: string };
export type Check = { id: string; label: string; lord: string; weight: number; linked_houses: number[]; matching_houses: number[]; matched: boolean; contribution: number };
export type Report = {
  report_id: string; generated_at: string; generated_at_ist: string; title: string; question: string; domain: string;
  input_summary: { birth: ReadingInput['birth']; analysis: MomentInput; birth_utc: string; analysis_utc: string };
  calculation: { status: string; engine: string; node_mode: string };
  chart: Chart; transits: Chart | null;
  dasha: { mahadasha: Period; bhukti: Period; antara: Period; upcoming_antaras: Period[]; balance_at_birth_years: number; year_days: number; note: string };
  source_rule_evaluation: {
    label: string; source: string; source_scope: string; domain: string; target_houses: number[];
    rules: { id: string; group: string; title: string; supplied_step: string; status: 'supported' | 'contradicted' | 'not_evaluable'; proxy_basis: boolean; evidence: Record<string, unknown>; note: string; is_probability: boolean; probability: null }[];
    counts: Record<string, number>; proxy_rules: string[]; is_probability: boolean; probability: null;
    binary_answer: string; aggregate_meaning: string; abstention_reasons: string[]; disclaimer: string;
  };
  assessment: { label: string; domain_label: string; target_houses: number[]; score: number; maximum: number; support_percent: number; conclusion: string; binary_answer: string; checks: Check[]; abstention_reasons: string[]; disclaimer: string; score_meaning: string; };
  sensitivity: { sampled: boolean; seconds: number; sensitive: boolean; changed_cusps: { house: number; earlier: string; recorded: string; later: string }[]; changed_planets: { name: string; earlier: string; recorded: string; later: string }[]; note: string };
  ruling_planets: { day_lord: string; day_convention: string; ascendant_sign_lord: string; ascendant_star_lord: string; ascendant_sub_lord: string; moon_sign_lord: string; moon_star_lord: string };
  cuspal_interlinks: { house: number; star_lord: string; sub_lord: string; linked_houses: number[] }[];
  verification: { item: string; status: string; detail: string }[];
  interpretation: { provider: string; external_ai_used: boolean; summary: string; sequence: string[]; practical_note: string };
  warnings: string[]; validation_footer: string;
};
export type Status = {
  product?: string; local_only?: boolean; modules?: Record<string,{installed:boolean;version?:string;error?:string}>; ephemeris?:{provider:string;active_provider?:string|null;path:string;lib_file:string;engine?:string}; boot_hook_present?:boolean; ai?:{provider:string;model:string;key_present:boolean;consent:boolean;language:string;configured:boolean;models:Record<string,string[]>};
  version: string; now_ist: string; environment: string; engine_ready: boolean;
  authentication_required: boolean; rate_limit_scope: string;
  engine_error: { message: string; code: string } | null;
  qa: { status?: string; automated_tests?: { passed: number; failed: number; skipped: number }; reference_fixtures?: number; browser_tests?: { passed: number; failed: number }; measured?: { planets_max_arcsec: number; cusps_max_arcsec: number; true_node_max_arcsec: number }; tested_at?: string };
};
export type Rules = { sequence: string[]; source_rules_expected: number; source_rules_defined: number; source_rules_calibrated: number; implemented_baseline_checks: number; limitations: string[]; pending_rules: { id: string; group: string; status: string }[] };
export type Horary = { number: number; start_degrees: number; end_degrees: number; sign: string; sign_lord: string; star_lord: string; sub_lord: string; nakshatra: string; note: string };

export type AIJob = {job_id?:string;report_id?:string;status:'queued'|'running'|'completed'|'failed'|'not_configured';error?:{code:string;message:string};result?:{provider:string;model:string;report_id:string;answer:{summary:string;themes:{title:string;interpretation:string;evidence_ids:string[]}[];timing_context:string;practical_steps:string[];limitations:string[]};evidence:Record<string,unknown>;note:string;prediction_probability:null;prose_fact_checked:boolean}};
