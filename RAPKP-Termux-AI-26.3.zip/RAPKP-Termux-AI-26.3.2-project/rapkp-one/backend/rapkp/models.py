from datetime import date as CivilDate
from datetime import datetime
from datetime import time as CivilTime
from enum import Enum
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, ConfigDict, Field, field_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False, str_strip_whitespace=True)


class Place(StrictModel):
    label: str = Field(default="Custom location", min_length=1, max_length=100)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    timezone: str = Field(
        min_length=1, max_length=80, description="IANA name, for example Asia/Kolkata. Not an ambiguous abbreviation."
    )

    @field_validator("timezone")
    @classmethod
    def valid_zone(cls, value: str) -> str:
        if value not in {"UTC", "Etc/UTC"} and "/" not in value:
            raise ValueError("Use an IANA zone such as Asia/Kolkata, not IST or EST.")
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError) as e:
            raise ValueError("Unknown IANA timezone") from e
        return value


class Moment(StrictModel):
    date: CivilDate = Field(description="Local civil date, 1900–2099 inclusive.")
    time: CivilTime = Field(description="Known local civil time, HH:MM[:SS]. No offset here; use place.timezone.")
    place: Place
    fold: Literal[0, 1] | None = Field(
        default=None, description="Required for an ambiguous DST time: 0 first occurrence, 1 second."
    )

    @field_validator("date")
    @classmethod
    def supported_date(cls, value: CivilDate) -> CivilDate:
        if not 1900 <= value.year <= 2099:
            raise ValueError("This release supports dates from 1900 through 2099 only.")
        return value

    @field_validator("time")
    @classmethod
    def naive_time(cls, value: CivilTime) -> CivilTime:
        if value.tzinfo is not None:
            raise ValueError("Time must not include an offset; provide place.timezone.")
        return value


class Birth(Moment):
    uncertainty_seconds: int = Field(
        default=60,
        ge=0,
        le=1800,
        description="Sensitivity sample at birth time ± this value. Not a complete interval proof.",
    )


class Domain(str, Enum):
    career = "career"
    marriage = "marriage"
    property = "property"
    education = "education"
    travel = "travel"
    business = "business"
    wealth = "wealth"
    meeting = "meeting"
    remarriage = "remarriage"
    handover = "handover"


class ReadingRequest(StrictModel):
    birth: Birth
    analysis: Moment = Field(
        description="Evaluation moment and actual analysis location, used for ruling planets and transits."
    )
    domain: Domain = Domain.career
    question: str = Field(
        default="",
        max_length=600,
        description="Optional context only. Never interpreted as program instructions. No automated event-date inference.",
    )
    node_mode: Literal["mean", "true"] = "mean"
    include_transits: bool = True


class SourceRule(StrictModel):
    """One supplied structural step. `probability` is typed as None so a numeric
    value can never enter this section without failing validation."""

    id: str
    group: str
    title: str
    supplied_step: str
    status: Literal["supported", "contradicted", "not_evaluable"]
    proxy_basis: bool
    evidence: dict
    note: str
    is_probability: bool
    probability: None


class SourceRuleEvaluation(StrictModel):
    label: str
    source: str
    source_scope: str
    domain: str
    target_houses: list[int]
    rules: list[SourceRule]
    counts: dict[str, int]
    proxy_rules: list[str]
    is_probability: bool
    probability: None
    binary_answer: str
    aggregate_meaning: str
    abstention_reasons: list[str]
    disclaimer: str


class ReadingResponse(StrictModel):
    schema_version: str
    report_id: str
    generated_at: datetime
    generated_at_ist: str
    title: str
    question: str
    domain: str
    input_summary: dict
    calculation: dict
    chart: dict
    transits: dict | None
    dasha: dict
    ruling_planets: dict
    significators: dict
    cuspal_interlinks: list[dict]
    assessment: dict
    source_rule_evaluation: SourceRuleEvaluation
    sensitivity: dict
    verification: list[dict]
    warnings: list[str]
    interpretation: dict
    provenance: dict
    validation_footer: str


class HoraryRequest(StrictModel):
    number: int = Field(ge=1, le=249)


class ReportBugRequest(StrictModel):
    category: Literal["calculation", "interface", "integration", "other"]
    description: str = Field(min_length=10, max_length=1500)
    consent: Literal[True]
    # This endpoint returns a downloadable report. It does not send to Arena or store personal data.
