#!/usr/bin/env python3
"""Verify a built Termux APK/AAB and write machine-checkable release evidence.

Usage: python3 scripts/verify_android_artifact.py [version] [version_code] [previous_apk]
Checks the packaged connector bundle against its manifest, the web assets against the
current build, the native plugin and permissions, the signature, and lint results.
Nothing here proves device behaviour; it only proves what is inside the artifact.
"""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "frontend/android"
OUT = ROOT / "qa/android/26.3"
SDK = Path(os.environ.get("ANDROID_HOME") or "/home/user/.cache/rapkp-termux/android/sdk")
BUILD_TOOLS = sorted((SDK / "build-tools").glob("*"))[-1] if (SDK / "build-tools").is_dir() else None
VERSION = sys.argv[1] if len(sys.argv) > 1 else "26.3.2-termux.1"
VERSION_CODE = int(sys.argv[2]) if len(sys.argv) > 2 else 2603012
PREVIOUS = Path(sys.argv[3]) if len(sys.argv) > 3 else None
APK = ROOT / f"native-artifacts/android/RAPKP-Termux-AI-{VERSION.rsplit('-termux')[0]}.apk"
AAB = ROOT / f"native-artifacts/android/RAPKP-Termux-AI-{VERSION.rsplit('-termux')[0]}-unsigned.aab"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def dex_contains(archive, name):
    return any(name.encode() in archive.read(n) for n in archive.namelist() if n.endswith(".dex"))


def lint_counts():
    xml = ANDROID / "app/build/reports/lint-results-debug.xml"
    if not xml.is_file():
        return None, None
    text = xml.read_text(errors="ignore")
    errors = len(re.findall(r'severity="Error"', text))
    warnings = len(re.findall(r'severity="Warning"', text))
    return errors, warnings


def web_assets_match(archive):
    """Every built web file must be packaged byte-identically; Capacitor's generated
    cordova bridge files are the only permitted extra entries."""
    allowed_extra = {"cordova.js", "cordova_plugins.js"}
    packaged = {
        n.split("assets/public/", 1)[1]: hashlib.sha256(archive.read(n)).hexdigest()
        for n in archive.namelist()
        if n.startswith("assets/public/") and not n.endswith("/")
    }
    built = {
        str(p.relative_to(ROOT / "frontend/site")): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (ROOT / "frontend/site").rglob("*")
        if p.is_file() and "__pycache__" not in p.parts
    }
    extras = set(packaged) - set(built)
    match = all(packaged.get(k) == v for k, v in built.items()) and extras <= allowed_extra
    return match, len(packaged), len(built)


def signature(path):
    if BUILD_TOOLS is None:
        return "unknown (build-tools not found)"
    try:
        out = subprocess.run(
            [str(BUILD_TOOLS / "apksigner"), "verify", "--print-certs", "--verbose", str(path)],
            capture_output=True, text=True, timeout=120,
        ).stdout
        digest = re.search(r"Signer #1 certificate SHA-256 digest: ([0-9a-f]+)", out)
        schemes = "v2" if "Verified using v2 scheme (APK Signature Scheme v2): true" in out else "none"
        return {"scheme": schemes, "cert_sha256": digest.group(1) if digest else None}
    except Exception as e:
        return f"unavailable ({type(e).__name__})"


def badging(path):
    if BUILD_TOOLS is None:
        return ""
    try:
        return subprocess.run(
            [str(BUILD_TOOLS / "aapt2"), "dump", "badging", str(path)], capture_output=True, text=True, timeout=120
        ).stdout
    except Exception:
        return ""


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for path in (APK, AAB):
        if not path.is_file():
            raise SystemExit(f"missing artifact: {path}")
    with zipfile.ZipFile(APK) as z:
        bundle = z.read("assets/termux/backend.zip")
        manifest = json.loads(z.read("assets/termux/manifest.json"))
        bootstrap = z.read("assets/termux/bootstrap.py").decode()
        assets_ok, packaged_count, built_count = web_assets_match(z)
        plugin_included = dex_contains(z, "TermuxBridgePlugin")
        reclaim = b"stop-request" in bootstrap.encode()
        with zipfile.ZipFile(io.BytesIO(bundle)) as inner:
            stop_watchdog = b"watch_stop_request" in inner.read("rapkp/termux_runtime/server.py")
    info = badging(APK)
    errors, warnings = lint_counts()
    previous_digest = None
    if PREVIOUS and PREVIOUS.is_file():
        with zipfile.ZipFile(PREVIOUS) as z:
            previous_digest = re.search(
                r"Signer #1 certificate SHA-256 digest: ([0-9a-f]+)",
                subprocess.run(
                    [str(BUILD_TOOLS / "apksigner"), "verify", "--print-certs", str(PREVIOUS)],
                    capture_output=True, text=True, timeout=120,
                ).stdout,
            )
        previous_digest = previous_digest.group(1) if previous_digest else None
    current = signature(APK)
    same_cert = bool(previous_digest and isinstance(current, dict) and current.get("cert_sha256") == previous_digest)
    evidence = {
        "version": VERSION,
        "version_code": VERSION_CODE,
        "package": "com.rapkp.one.preview",
        "launcher": "RAPKP Termux AI",
        "same_signing_certificate_as_previous_build": same_cert,
        "apk_sha256": sha256(APK),
        "aab_sha256": sha256(AAB),
        "apk_bytes": APK.stat().st_size,
        "aab_bytes": AAB.stat().st_size,
        "bundled_connector_bytes": len(bundle),
        "bundled_connector_sha256": hashlib.sha256(bundle).hexdigest(),
        "bundled_connector_manifest_hash_match": hashlib.sha256(bundle).hexdigest() == manifest["sha256"],
        "bundled_connector_version": manifest["version"],
        "bundled_connector_port_reclaim_fix": bool(reclaim and stop_watchdog),
        "web_assets_match": assets_ok,
        "web_assets_packaged": packaged_count,
        "web_assets_built": built_count,
        "native_termux_plugin_included": plugin_included,
        "run_command_permission_declared": "com.termux.permission.RUN_COMMAND" in info,
        "lint_errors": errors,
        "lint_warnings": warnings,
        "physical_device_tested": False,
        "live_model_call_tested": False,
        "signing": "debug-signed APK; unsigned AAB",
        "signature": current,
    }
    (OUT / "artifact-verification.json").write_text(json.dumps(evidence, indent=2) + "\n")
    (OUT / "apk-manifest.txt").write_text(info)
    (OUT / "apk-signature.txt").write_text(
        subprocess.run(
            [str(BUILD_TOOLS / "apksigner"), "verify", "--print-certs", "--verbose", str(APK)],
            capture_output=True, text=True, timeout=120,
        ).stdout
        if BUILD_TOOLS
        else "build-tools unavailable\n"
    )
    print(json.dumps({k: evidence[k] for k in list(evidence)[:14]}, indent=2))
    problems = [
        key
        for key in (
            "bundled_connector_manifest_hash_match",
            "web_assets_match",
            "native_termux_plugin_included",
            "bundled_connector_port_reclaim_fix",
            "run_command_permission_declared",
            "same_signing_certificate_as_previous_build",
        )
        if evidence.get(key) is not True
    ]
    if errors or warnings:
        problems.append("lint")
    if problems:
        raise SystemExit("artifact verification failed: " + ", ".join(problems))
    print("Android artifact verification passed for", VERSION)


if __name__ == "__main__":
    main()
