#!/usr/bin/env python3
"""Generate the current guide and QA report from version-specific executed evidence."""
import json
from pathlib import Path

import markdown

ROOT=Path(__file__).resolve().parents[1]
CSS='''body{margin:0;background:#f5f7f1;color:#2d4536;font:15px/1.65 Arial,sans-serif}main{max-width:1080px;margin:32px auto;padding:40px 50px;background:#fff;border:1px solid #dce4d5}h1,h2,h3{font-family:Georgia,serif;color:#315842}h1{font-size:37px;line-height:1.2}h2{margin-top:34px;border-bottom:1px solid #dce4d5;padding-bottom:10px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:10px;border:1px solid #dce4d5;text-align:left}th{background:#ecf2e5}pre{background:#294735;color:#f2f7e9;padding:18px;border-radius:8px;overflow:auto}code{font-size:12px}a{color:#2b6345}blockquote{background:#f0f4e9;border-left:3px solid #789555;padding:12px 20px;margin:20px 0}@page{size:A4;margin:15mm}@media print{body{background:white;font-size:12px;line-height:1.5}main{border:0;margin:0;padding:0}h1{font-size:29px}h2{font-size:21px;break-after:avoid}table{font-size:10px}td,th{padding:6px}tr{break-inside:avoid}pre{white-space:pre-wrap}}@media(max-width:640px){main{margin:0;padding:24px 18px}h1{font-size:28px}table{font-size:11px}td,th{padding:6px}}'''
def html(content,title):return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+CSS+'</style></head><body><main>'+markdown.markdown(content,extensions=['tables','fenced_code'])+'</main></body></html>'
def main():
 q=json.loads((ROOT/'qa/verification.json').read_text());m=q['measured'];v=q['version']
 guide=f'''# RAPKP One 26.2 — upgraded project + Android app

**{v} · 2 October 2026 · New features and a new Android build**

## Install this version

Android APK: **native-artifacts/android/RAPKP-One-{v}.apk**. The launcher says **RAPKP One 26.2**; version code **2603001**, package **com.rapkp.one.preview**. This is intentionally a separate preview package and installs alongside the earlier evaluation app. Open the new icon. Do not bypass device security warnings.

The unsigned release bundle is `native-artifacts/android/RAPKP-One-{v}-unsigned.aab`. An AAB is not directly installable; owner signing and store/device review remain required. No private signing credentials are bundled.

## What is upgraded

- Optional Android Keystore/AES-GCM connection storage with a Forget action. Endpoints/tokens are remembered only after you opt in; birth details are not stored in this profile.
- Native Android system file picker for JSON reports and input snapshots. Exports may contain personal data and are plaintext files you explicitly choose to save.
- Import a request JSON or restore inputs from an older RAPKP schema-1.0 report. Existing positions and interpretations are discarded, and nothing is calculated or sent automatically.
- Keep the current form/report when navigating to other pages. Reload/exit still clears personal session data unless you explicitly export it.
- Android Back handling and an About & updates page showing version, build, package and service identity.
- Improved backup/transfer exclusions, disabled platform logging/WebView debugging, modernised icons/splash, Gradle 8.14.5 and AppCompat 1.8.0.

Full before/after comparison: **docs/UPGRADE_26_2.md**. Android details and limits: **docs/ANDROID_UPGRADE.md**.

## Run the calculator

The APK is a hybrid Capacitor interface with native Android functionality. **It does not embed Python or the ephemeris engine.** Use your own HTTPS backend or run the same engine in Termux on that phone.

### Computer / local web

```bash
cd rapkp-one
bash scripts/install.sh
bash scripts/run-local.sh
```

Open **http://127.0.0.1:8000** on that device. The UI and verified JPL DE440s kernel are bundled. Python 3.11+ is required (QA used 3.13.14); no Node installation is needed to run the prebuilt UI. Initial dependency installation requires network access.

### Same-phone Termux

Extract into Termux's private home directory, not shared storage:

```bash
cd ~/rapkp-one
bash scripts/install-termux.sh
bash scripts/run-termux.sh
```

Then choose **Use Termux on this phone** in the APK. Local loopback is only that phone, not a cloud AI service's localhost. Termux installation and native device interactions have not been physically tested here.

### Cloud

Use Docker/Compose templates with a generated strong service secret and your own domain/TLS/origin settings. Public multi-user deployments require owner identity/tenant, privacy/consent and abuse controls. Do not embed a shared master token in a distributed app. Production cloud rollout and capacity certification are not claimed.

### ChatGPT / Gemini

Use `RAPKP_ONE_MASTER_INSTRUCTIONS.md` plus the platform-specific `integrations/` files. A Custom GPT needs a real HTTPS Action endpoint and builder authentication. A consumer Gem uses explicit report upload/paste, not an imaginary API connection created by a prompt. The optional Gemini API bridge requires an actual model/key and explicit consent. No live provider/AstroSage connection is claimed.

## Recorded quality

| Check | Executed result |
|---|---:|
| Backend regression | **{q['automated_tests']['passed']} passed** |
| Desktop/mobile-viewport browser cases | **{q['browser_tests']['passed']} passed** |
| Native HTTP contract mocks | **{q['native_client_tests']['passed']} passed** |
| New import/storage/export client cases | **{q['upgrade_client_tests']['passed']} passed** |
| Java AES-GCM algorithm cases | **{q['java_crypto_tests']['passed']} passed** |
| Android lint | **0 errors, 0 warnings** |

APK compilation/signature/identity checks were executed and the bundled web assets match the current rebuilt source. **JVM crypto tests and browser viewports are not physical Android hardware/Keystore/file-picker tests.** Device instrumentation checks are supplied for owner execution but not reported as run.

## Calculation and interpretation boundary

The numerical engine remains pinned and regression-tested: KP sidereal positions, Placidus, sub-lords, corrected Vimshottari and disclosed link/sensitivity rules. Dates: 1900–2099 UTC; Placidus latitude strictly inside ±66°. Horary is a 249-segment lookup, not a full judgment.

Separate v17–v25 source releases and the complete 11 user + 10 professor rule definitions were not supplied. Those slots stay disabled. A high support index is not a probability or YES. Personal-event prediction accuracy, an 81.2% claim and professor/external endorsement remain unestablished.

## Handover

Current evidence: `docs/QA_REPORT.pdf` and `qa/verification.json`. Rebuild: `scripts/build-android.sh`. Owner AAB signing helper: `scripts/sign-android-bundle.sh` (not executed with owner credentials). Keep licence notices with distributions and review rights/privacy/security/store requirements before public release. `CHECKSUMS.sha256` verifies packaged contents.

The earlier build's historical HTTP benchmark and QA files are retained as history, not represented as newly executed cloud-capacity evidence for 26.2.
'''
 report=f'''# RAPKP One 26.2 — upgrade QA report

**{v} · Recorded {q['tested_at']}**

## Upgrade identity and provenance

This is a feature upgrade, not a repackaged RC2 binary. The preview package is **com.rapkp.one.preview**, launcher **RAPKP One 26.2**, version code **2603001** (previously 2601002). New native Java code supplies encrypted connection storage and Android document-picker JSON exports; new client code supplies input restoration, session-preserving navigation and build identity.

The APK is debug-signed for evaluation, and the release AAB is unsigned. They are compiled artifacts, not owner release-signed/store-approved products. The old signing key was not available; a separate preview ID avoids claiming a working in-place migration.

## Executed checks

| Evidence | Result | Scope |
|---|---:|---|
| Backend cases | {q['automated_tests']['passed']} passed; 0 failed/skipped | Parametrised numerical, time, API/security, CLI, provider mocks and real local limiter cases |
| Backend statement coverage | {q['coverage']['statement_percent']:.2f}% | Not branch coverage or proof of correctness |
| Browser cases | {q['browser_tests']['passed']} passed | Chromium desktop/mobile viewports; includes new navigation/import/export/About checks |
| Native transport cases | {q['native_client_tests']['passed']} passed | Mocked Capacitor HTTP contract, consent and separate credentials |
| New client cases | {q['upgrade_client_tests']['passed']} passed | Request/report validation; malformed/oversize/time/coordinate rejection; mocked device bridge |
| Java crypto cases | {q['java_crypto_tests']['passed']} passed | AES-GCM round trip, random IVs, tamper/wrong-key rejection and size/IV validation in a JVM |
| Android compilation | Passed | New APK/AAB and native plugin code compiled with JDK 21/SDK 36 |
| Android lint | 0 errors / 0 warnings | Previous build had 32 warnings; rules were not disabled to obtain this result |
| APK inspection | Passed | Package/version/launcher, signature, native-plugin DEX presence, disabled bridge logging/debugging |
| Source/assets match | Passed | Current compiled web assets compared byte-for-byte to APK assets |
| Known-advisory scans | Recorded Python/npm results contain 0 findings | Not a penetration test or complete native supply-chain audit |
| OpenAPI | Specification validation passed | Live account configuration/calls not performed |

The initial native lint process hit a constrained JVM metaspace limit. It was rerun with a larger metaspace cap and completed; the detector was not disabled. One new browser test initially compared `innerText` with `textContent`; its whitespace-sensitive assertion was corrected and the full suite rerun. The backend retains one upstream TestClient/httpx deprecation warning.

## Native privacy and usability changes

- Explicit opt-in encrypted connection record; Android Keystore-backed AES-GCM implementation. Tokens are loaded into app memory when restored; this is not protection against a compromised/rooted device or malicious code already in the app.
- Only connection fields are retained in that record. Birth data is not silently persisted.
- Forget deletes the saved profile/key; current session values remain until cleared/exit, as the UI states.
- JSON file export uses Android's system document picker. The destination is user-selected, and the exported file is plaintext personal data, not a token vault.
- Backup and transfer exclusions cover legacy and Android-12+ policies. Native bridge logging and WebView debugging are disabled.
- Input restoration accepts request JSON or inputs from schema-1.0 reports, never imported chart facts as a newly computed result. It does not trigger an API request until the user calculates.
- Workbench state survives view changes but not reload/exit unless explicitly exported. Native Back handling and an installed-version screen were added.

**Physical device testing was not executed.** Hardware Keystore behavior, system picker/lifecycle/keyboard/Back interaction, OEM backup behavior and native accessibility require device validation. The supplied instrumentation test source is not an executed test result. iOS source is generated, not compiled/signed/device-tested.

## Numerical engine

The engine/conventions are intentionally unchanged for reproducibility and rechecked against **95 independent fixtures / 190 mean–true chart evaluations**. Sampled maxima:

| Quantity | Maximum residual |
|---|---:|
| Classical planets | {m['planets_max_arcsec']:.6f} arcseconds |
| Placidus cusps | {m['cusps_max_arcsec']:.6f} arcseconds |
| Mean node | {m['mean_node_max_arcsec']:.6f} arcseconds |
| True/osculating node | {m['true_node_max_arcsec']:.6f} arcseconds |

These are finite reference comparisons with aligned conventions, not global error bounds or life-event prediction accuracy. Birth-time/model uncertainty and the larger true-node difference still matter at KP boundaries.

## Release decision and remaining gates

The upgraded web/API and compiled Android preview are ready for controlled technical evaluation. No store approval, physical device certification, live ChatGPT/Gemini/AstroSage confirmation, production cluster capacity, professor endorsement or empirical forecasting probability is claimed.

Historical v17–v25 releases and the complete 21-rule definitions remain unavailable. The four-check baseline remains uncalibrated and preserves NOT DETERMINED. Owner signing, public-user identity/tenant controls, privacy/licence/branding review and independent outcome validation remain separate requirements.

Current evidence is in qa/pytest-results.xml, qa/playwright-results.json, qa/native-transport-tests.xml, qa/upgrade-client-tests.xml and qa/android/26.2/. Version-labelled prior evidence remains under qa/history/. The source hashes are in qa/verification.json and package hashes in CHECKSUMS.sha256.
'''
 (ROOT/'README.md').write_text(guide);(ROOT/'docs/START_HERE.md').write_text(guide);(ROOT/'START_HERE.html').write_text(html(guide,'RAPKP One 26.2 — upgrade guide'))
 (ROOT/'docs/QA_REPORT.md').write_text(report);(ROOT/'docs/QA_REPORT.html').write_text(html(report,'RAPKP One 26.2 — QA report'))
 (ROOT/'HANDOVER.md').write_text('# Upgrade handover\n\nCurrent release: **26.3.0-termux.1**. Install the APK labelled **RAPKP One 26.2**, package `com.rapkp.one.preview`, build 2603001.\n\nRead START_HERE.html, docs/UPGRADE_26_2.md and docs/ANDROID_UPGRADE.md. Current test evidence is docs/QA_REPORT.pdf and qa/verification.json. No physical-device/store/predictive-accuracy certification is implied.\n')
 print('26.2 guide, handover and QA report generated from executed evidence.')
if __name__=='__main__':main()
