import { Capacitor, CapacitorHttp } from '@capacitor/core';
import type { Report } from './types';

export type BaseConnection = { primary: string; primaryToken: string; fallback: string; fallbackToken: string; allowFallback: boolean };
export type ConnectionMode = 'cloud' | 'termux' | 'web';
export type Connection = BaseConnection & { mode?: ConnectionMode; profiles?: { cloud: BaseConnection; termux: BaseConnection } };
export const initialConnection: Connection = { primary: '', primaryToken: '', fallback: '', fallbackToken: '', allowFallback: false };
export type Route = 'primary' | 'fallback';
export const isNative = () => Capacitor.isNativePlatform();

export function validateEndpoint(value: string): string {
  const v = value.trim().replace(/\/+$/, '');
  if (!v) return '';
  let u: URL;
  try { u = new URL(v); } catch { throw new Error('Use a complete HTTPS API origin.'); }
  const deviceLoopback = Capacitor.getPlatform() === 'android' && ['127.0.0.1', 'localhost'].includes(u.hostname) && u.protocol === 'http:';
  if (u.protocol !== 'https:' && !deviceLoopback) throw new Error('HTTPS is required. Android-native Termux loopback is the only HTTP exception.');
  if (u.username || u.password || u.search || u.hash) throw new Error('API origins cannot contain credentials, queries, or fragments.');
  return v;
}

class ApiError extends Error {
  status: number;
  constructor(message: string, status = 0) { super(message); this.status = status; }
}

function object(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function connectionFailure(base: string, cause: unknown): string {
  const detail = typeof cause === 'object' && cause !== null && 'message' in cause ? String((cause as {message: unknown}).message) : String(cause || '');
  let local=false;try{local=['127.0.0.1','localhost'].includes(new URL(base).hostname);}catch{}
  if (/cleartext.*(not permitted|denied)/i.test(detail)) return 'Android blocked local HTTP. Use the supported Termux address in Local Termux mode; do not disable HTTPS checks for cloud servers.';
  if (/ssl|certificate|handshake|certpath/i.test(detail)) return 'Cloud HTTPS verification failed. Check the deployed domain and certificate. Do not disable certificate validation.';
  if (/json|parse|unexpected.*token/i.test(detail)) return 'This address returned something other than a RAPKP API response. Use the backend base URL, not a website/login page.';
  if(local) return 'The Termux connector did not respond. Open Termux & AI setup, check automation permissions, then Start & connect. No calculation or AI answer was substituted.';
  if(/unknownhost|resolve host|resolve hostname|no address associated|dns/i.test(detail)) return 'The cloud hostname could not be resolved. Paste the real HTTPS URL from your hosting dashboard; a placeholder is not a server.';
  if(/timeout|timed out|abort/i.test(detail)) return 'The cloud connection timed out. Check that the deployed service is running and not sleeping, then test its health endpoint.';
  return 'The cloud backend is not reachable. Installing the APK does not deploy a server. Check your real hosted URL, internet connection and service status; no offline prediction was invented.';
}

function messageFrom(data: unknown, status: number): string {
  if (object(data)) {
    if (status===403 && typeof data.message==='string' && /traffic access token/i.test(data.message)) return 'This preview is protected by its hosting platform. It is not a permanent cloud API for the APK; use your own deployed HTTPS service.';
    const error = object(data.error) ? data.error : object(data.detail) ? data.detail : {};
    if (Array.isArray(error.fields)) {
      const fields = error.fields.filter(x => object(x) && typeof x.field === 'string' && typeof x.message === 'string');
      if (fields.length) return fields.map(x => `${x.field.replace('body.', '')}: ${x.message}`).join(' · ');
    }
    if (typeof error.message === 'string') return error.message;
  }
  return `API request failed (${status}). No chart was substituted.`;
}

// A defensive contract check, NOT proof of server authenticity or astronomy accuracy.
function checked<T>(path: string, data: unknown): T {
  const invalid = () => new ApiError('The service returned an incomplete or incompatible response. No chart was substituted.', 502);
  if (!object(data)) throw invalid();
  if (path === '/api/v1/status' && (typeof data.engine_ready !== 'boolean' || typeof data.version !== 'string')) throw invalid();
  if (path === '/api/v1/readings') {
    const r = data as unknown as Partial<Report>;
    if (data.schema_version !== '1.0' || !r.report_id || !r.chart || !object(r.chart.bodies) || Object.keys(r.chart.bodies).length !== 9 || ['Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Rahu','Ketu'].some(n => !r.chart?.bodies[n]) || !Array.isArray(r.chart.cusps) || r.chart.cusps.length !== 12 || !r.input_summary || !r.dasha || !r.assessment || !r.interpretation || !r.sensitivity || !r.ruling_planets || !Array.isArray(r.verification) || !Array.isArray(r.warnings)) throw invalid();
    for (const p of Object.values(r.chart.bodies)) if (!p || !Number.isFinite(p.longitude) || p.longitude < 0 || p.longitude >= 360 || !Number.isFinite(p.speed) || !Number.isInteger(p.house) || p.house < 1 || p.house > 12) throw invalid();
    if (r.chart.cusps.some(c => !Number.isFinite(c.longitude) || c.longitude < 0 || c.longitude >= 360)) throw invalid();
  }
  return data as T;
}

async function verifyTermux(base:string,token:string):Promise<void>{
  if(!token)throw new ApiError('Pair this app with its Termux connector first.',401);
  const bytes=crypto.getRandomValues(new Uint8Array(16));const nonce=Array.from(bytes).map(b=>b.toString(16).padStart(2,'0')).join('');
  let r;try{r=await CapacitorHttp.request({url:`${base}/health/challenge?nonce=${nonce}`,method:'GET',headers:{Accept:'application/json'},connectTimeout:4000,readTimeout:4000,disableRedirects:true,responseType:'json'});}catch(e){throw new ApiError(connectionFailure(base,e));}
  const data=r.data as {nonce?:string;proof?:string};
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(token),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signed=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('rapkp-server-v1\n'+nonce));
  const expected=Array.from(new Uint8Array(signed)).map(b=>b.toString(16).padStart(2,'0')).join('');
  let difference=0;const given=typeof data?.proof==='string'?data.proof:'';
  if(given.length===expected.length)for(let i=0;i<expected.length;i++)difference|=given.charCodeAt(i)^expected.charCodeAt(i);else difference=1;
  if(r.status!==200||data.nonce!==nonce||difference){
    // Identify what actually answered, so the user is told the real fix instead of "re-pair" forever.
    const probe=await probeTermux(base);
    let message='The local process is not the paired RAPKP connector. No token or private request was sent. Re-pair in Termux setup.';
    if(probe.reachable&&probe.product)message=`An unpaired RAPKP connector (version ${probe.version||'unknown'}) is already running on local port 8765; it was started before this pairing, so its key is different. No token or private request was sent. Tap “Install / re-pair connector” once — it stops that instance and starts this one. If this repeats, stop it in Termux with: pkill -f "rapkp-one/start.py"`;
    else if(probe.reachable)message=`Local port 8765 is answered by ${probe.other||'another service'}, not the RAPKP connector. No token or private request was sent. Stop that service in Termux (ss -ltnp | grep 8765), then re-pair in Termux setup.`;
    throw new ApiError(message,401);
  }
}

export type LocalProbe={reachable:boolean;product?:string;version?:string;other?:string};
/** Unauthenticated fingerprint of whatever answers the local port. Sends no token, no birth data, no question. */
export async function probeTermux(base:string):Promise<LocalProbe>{
  try{
    const r=await CapacitorHttp.request({url:`${base}/health/live`,method:'GET',headers:{Accept:'application/json'},connectTimeout:3000,readTimeout:3000,disableRedirects:true,responseType:'json'});
    const d=r.data as {product?:string;version?:string}|undefined;
    if(r.status===200&&d&&typeof d==='object'&&d.product==='RAPKP Termux AI')return {reachable:true,product:d.product,version:typeof d.version==='string'?d.version:undefined};
    const other=d&&typeof d==='object'&&typeof d.product==='string'?d.product:'a different service';
    return {reachable:true,other};
  }catch{return {reachable:false};}
}

async function call<T>(base: string, token: string, path: string, payload?: unknown): Promise<T> {
  if (isNative() && base && base !== 'http://127.0.0.1:8765') throw new ApiError('This edition connects only to its paired Termux service. Use Termux setup, not a cloud URL.');
  if (isNative() && !base) throw new ApiError('Pair and start the Termux connector from Termux & AI setup.');
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (payload !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;
  if (isNative()) {
    await verifyTermux(base,token);
    let response;
    try { response = await CapacitorHttp.request({ url: `${base}${path}`, method: payload === undefined ? 'GET' : 'POST', headers, data: payload, connectTimeout: 12000, readTimeout: 30000, disableRedirects: true, responseType: 'json' }); }
    catch (e) { throw new ApiError(connectionFailure(base,e)); }
    if (response.status < 200 || response.status >= 300) throw new ApiError(messageFrom(response.data, response.status), response.status);
    return checked<T>(path, response.data);
  }
  let response: Response;
  try { response = await fetch(`${base}${path}`, { method: payload === undefined ? 'GET' : 'POST', headers, body: payload === undefined ? undefined : JSON.stringify(payload), signal: AbortSignal.timeout(30000), cache: 'no-store', credentials: 'omit', redirect: 'error' }); }
  catch (e) { throw new ApiError(connectionFailure(base,e)); }
  let data: unknown;
  try { data = await response.json(); } catch { throw new ApiError('The server returned an invalid response. Check that the URL points to RAPKP One.', response.status >= 400 ? response.status : 502); }
  if (!response.ok) throw new ApiError(messageFrom(data, response.status), response.status);
  return checked<T>(path, data);
}

export async function api<T>(connection: Connection, path: string, payload?: unknown): Promise<{ data: T; route: Route }> {
  try { return { data: await call<T>(connection.primary, connection.primaryToken, path, payload), route: 'primary' }; }
  catch (e) {
    const retriable = e instanceof ApiError && [0, 502, 503, 504].includes(e.status);
    if (!retriable || !connection.allowFallback || !connection.fallback) throw e;
    try { return { data: await call<T>(connection.fallback, connection.fallbackToken, path, payload), route: 'fallback' }; }
    catch (fallbackError) { throw new Error(`Primary and opted-in fallback failed. ${fallbackError instanceof Error ? fallbackError.message : 'No calculation is available.'}`); }
  }
}
