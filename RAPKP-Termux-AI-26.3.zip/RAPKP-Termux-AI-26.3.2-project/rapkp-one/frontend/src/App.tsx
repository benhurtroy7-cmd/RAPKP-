import { useEffect, useRef, useState } from 'react';
import { Activity, ArrowUpRight, BookOpen, Check, ChevronRight, CircleHelp, Cloud, Command, FlaskConical, LayoutDashboard, Menu, Network, Settings2, ShieldCheck, Sparkles, X } from 'lucide-react';
import { api, initialConnection, isNative, type Connection } from './api';
import type { Status } from './types';
import { dateIST } from './utils';
import Workbench from './Workbench';
import { DeployView, QualityView, RulebookView } from './Library';
import TermuxSetup from './TermuxSetup';
import { Termux, termuxConnection, termuxNative, startTermux } from './termux';
import AboutView from './AboutView';
import { Capacitor } from '@capacitor/core';
import { App as NativeApp } from '@capacitor/app';

import { APP_VERSION, APP_SERIES } from './version';

export type View = 'workbench' | 'rules' | 'quality' | 'deploy' | 'about';
const navigation = [
  { id: 'workbench', label: 'Workbench', icon: LayoutDashboard },
  { id: 'rules', label: 'Methods & rulebook', icon: BookOpen },
  { id: 'quality', label: 'Quality lab', icon: FlaskConical },
  { id: 'deploy', label: 'Termux & AI setup', icon: Network },
  { id: 'about', label: 'About & updates', icon: Sparkles },
] as const;

function BrandMark() { return <svg viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" rx="12" fill="#355b4b" /><circle cx="20" cy="20" r="11" stroke="#e5ecd7" fill="none" /><ellipse cx="20" cy="20" rx="5" ry="15" transform="rotate(40 20 20)" stroke="#e5ecd7" fill="none" /><circle cx="20" cy="20" r="3" fill="#e5ecd7" /><circle cx="30" cy="14" r="2" fill="#d3b787" /></svg>; }

export default function App() {
  const [view, setView] = useState<View>('workbench');
  const [connection, setConnection] = useState<Connection>(initialConnection);
  const [status, setStatus] = useState<Status | null>(null);
  const [connectionError, setConnectionError] = useState('');
  const [route, setRoute] = useState('primary');
  const [settings, setSettings] = useState(false);
  const [booted, setBooted] = useState(() => !isNative());
  const [savedConnection, setSavedConnection] = useState(false);
  const lastBack = useRef(0);
  const statusEpoch = useRef(0);
  const acceptStatus=(s:Status)=>{statusEpoch.current++;setStatus(s);setConnectionError('');};
  const [menu, setMenu] = useState(false);
  const [compact, setCompact] = useState(() => window.matchMedia('(max-width:850px)').matches);
  const [toast, setToast] = useState('');
  const [refresh, setRefresh] = useState(0);

  useEffect(() => { const mq = window.matchMedia('(max-width:850px)'); const update = () => setCompact(mq.matches); const escape = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenu(false); }; mq.addEventListener('change', update); document.addEventListener('keydown', escape); return () => { mq.removeEventListener('change', update); document.removeEventListener('keydown', escape); }; }, []);

  useEffect(() => {
    if(!isNative())return;let active=true;
    void termuxConnection().then(async c=>{if(!active)return;setConnection(c);try{const n=await Termux.status();if(!n.termuxInstalled||!n.permissionGranted||!n.paired){setSettings(true);return;}const s=await startTermux(c);if(active)setStatus(s);}catch{if(active)setSettings(true);}}).catch(()=>{if(active)setSettings(true);}).finally(()=>{if(active)setBooted(true);});
    return()=>{active=false;};
  },[]);
  useEffect(()=>{
    if(Capacitor.getPlatform()!=='android')return;
    const listener=NativeApp.addListener('backButton',()=>{
      if(settings){setSettings(false);return;}if(menu){setMenu(false);return;}
      if(view!=='workbench'){setView('workbench');return;}
      const now=Date.now();if(now-lastBack.current<2000){void NativeApp.exitApp();return;}
      lastBack.current=now;setToast('Press Back again to exit. Export inputs first if you want to keep them.');
    });
    return ()=>{void listener.then(h=>h.remove()).catch(()=>{});};
  },[settings,menu,view]);

  useEffect(() => {
    if(!booted)return;
    let valid = true;const epoch=++statusEpoch.current;
    setStatus(null); setConnectionError('');
    api<Status>(connection, '/api/v1/status').then(({ data, route: r }) => { if (valid && statusEpoch.current===epoch) { setStatus(data); setRoute(r); setConnectionError(''); } }).catch(e => { if (valid && statusEpoch.current===epoch) setConnectionError(e.message); });
    return () => { valid = false; };
  }, [connection, refresh, booted]);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 6500); return () => clearTimeout(timer); }, [toast]);
  const navigate = (next: View) => { setView(next); setMenu(false); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const active = navigation.find(n => n.id === view)!;

  return <div className="app-shell">
    {menu && <button className="sidebar-scrim" onClick={() => setMenu(false)} aria-label="Close navigation" />}
    <aside id="side-navigation" className={`sidebar ${menu ? 'open' : ''}`} inert={compact && !menu ? true : undefined}>
      <button className="brand" onClick={() => navigate('workbench')} aria-label="RAPKP One home"><BrandMark /><span>RAPKP <b>One<span className="brand-dot">.</span></b><small>THE CALCULATION WORKSPACE</small></span></button>
      <div className="workspace-switch"><span className="workspace-avatar"><Command size={16} /></span><div>Personal workspace<small>{status?.environment === 'termux' ? 'On-device Termux' : 'Local QA preview'}</small></div><ChevronRight size={14} /></div>
      <div className="nav-label">WORKSPACE</div>
      <nav aria-label="Main navigation">{navigation.map(n => <button key={n.id} className={`nav-item ${view === n.id ? 'active' : ''}`} onClick={() => navigate(n.id)} aria-current={view === n.id ? 'page' : undefined}><n.icon size={18} /><span>{n.label}</span>{n.id === 'workbench' && <span className="tiny-dot" />}</button>)}</nav>
      <div className="sidebar-note"><span className="note-star">✧</span><h4>One core.<br />Every environment.</h4><p>From your phone to the cloud, keep the same calculation trail.</p><button onClick={() => navigate('deploy')}>Explore integrations <ArrowUpRight size={14} /></button><div className="orbit-decoration" /></div>
      <div className="sidebar-bottom"><button className="nav-item" onClick={() => setSettings(true)}><Settings2 size={18} /><span>Termux & AI settings</span></button><button className="nav-item" onClick={() => navigate('quality')}><CircleHelp size={18} /><span>Read the limitations</span></button><div className="build-stamp"><span className="build-icon"><ShieldCheck size={16} /></span><div>RAPKP v{APP_SERIES} <small>Release candidate · not certified</small></div></div></div>
    </aside>
    <div className="main-shell" inert={compact && menu ? true : undefined}>
      <header className="topbar"><div className="breadcrumb"><button className="icon-button mobile-menu" onClick={() => setMenu(!menu)} aria-label="Open navigation" aria-expanded={menu} aria-controls="side-navigation"><Menu size={21} /></button><span>Workspace</span><ChevronRight size={13} /><b>{active.label}</b></div><div className="top-actions"><span className="header-date">{status ? dateIST(status.now_ist) : dateIST(new Date().toISOString())}<span> IST</span></span><button className={`connection-pill ${status?.engine_ready ? 'online' : connectionError ? 'offline' : 'pending'}`} onClick={() => setSettings(true)}><span className="status-dot" />{status?.engine_ready ? isNative() ? 'Termux connected' : 'Local QA connected' : connectionError ? 'Termux setup needed' : status ? 'Engine unavailable' : 'Connecting'}<ChevronRight size={12} /></button></div></header>
      <main>
        {connectionError && <div className="global-error" role="alert"><Cloud size={18} /><span>{connectionError}</span><button onClick={() => setSettings(true)}>Configure</button></div>}
        {status && !status.engine_ready && <div className="global-error" role="alert"><Activity size={18} /><span>{status.engine_error?.message || 'Calculation data is unavailable.'}</span><button onClick={() => setRefresh(x => x + 1)}>Retry</button></div>}
        <div hidden={view !== 'workbench'}><Workbench connection={connection} status={status} toast={setToast} navigate={navigate} openConnection={() => setSettings(true)} /></div>
        {view === 'rules' && <RulebookView connection={connection} />}
        {view === 'quality' && <QualityView status={status} refresh={() => setRefresh(x => x + 1)} />}
        {view === 'deploy' && <section className="card library-card"><div className="eyebrow">LOCAL-FIRST PIPELINE</div><h1>Termux calculates. AI interprets.</h1><p>Start the paired local connector, verify Swiss/libephemeris data, then configure your model API key inside Termux. No permanent cloud server URL is required.</p><button className="primary-button" onClick={()=>setSettings(true)}>Open Termux & AI setup</button></section>}
        {view === 'about' && <AboutView status={status} savedConnection={savedConnection} openSettings={()=>setSettings(true)} showQuality={()=>navigate('quality')}/>}
        <footer className="main-footer"><span><Sparkles size={12} /> Built for traceability, not certainty.</span><span>RAPKP One <span className="footer-separator">/</span> v{APP_VERSION}</span></footer>
      </main>
    </div>
    {settings && <TermuxSetup connection={connection} status={status} onConnection={setConnection} onStatus={acceptStatus} onClose={() => setSettings(false)} />}
    {toast && <div className="toast" role="status"><Check size={17} /><span>{toast}</span><button onClick={() => setToast('')} aria-label="Dismiss notification"><X size={15} /></button></div>}
  </div>;
}
