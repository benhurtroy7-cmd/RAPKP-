# Termux-only handover — 26.3.2

Install **RAPKP-Termux-AI-26.3.2.apk**. This is a same-certificate in-place update of 26.3.1-termux.1 (build 2603012), so it replaces the installed app without uninstalling it. Open **RAPKP Termux AI**.

The app routes through the paired Termux service on local port 8765. One-time RUN_COMMAND permission and allow-external-apps setup are mandatory. Then install the bundled connector, start/check it, select the installed ephemeris/data and configure your provider API key in the app's Termux settings. No cloud hosting URL is required.

The new connector is standard-library Python and source-only; it does not reinstall or bundle your Swiss/libephemeris libraries/data. Existing unrelated Termux files/services are not replaced. The app installs its own Boot hook.

26.3.2 adds the supplied professor rule layer: a **Supplied steps** tab evaluates the 10 publicly outlined structural steps with cited evidence. Those steps carry no thresholds, weights or calibration, so they produce structural findings only — never a probability, a YES/NO, or a score. 10 of the 21 requested rule slots are defined; 0 are calibrated. The 11 user rules and the 1,500+ numbered master rules remain unsupplied.

Executed software evidence: qa/verification.json and docs/QA_TERMUX_AI.md/.html/.pdf, all regenerated for 26.3.2.

If a previous pairing is stuck with "the local process is not the paired RAPKP connector", see the troubleshooting section in START_HERE.html: 26.3.1 made "Install / re-pair connector" able to reclaim port 8765 from an older instance. Physical phone/Termux automation and live paid AI calls have NOT been tested here. No zero-bug or precise life-event guarantee is made. Review the AGPL/commercial licensing terms before redistribution.
