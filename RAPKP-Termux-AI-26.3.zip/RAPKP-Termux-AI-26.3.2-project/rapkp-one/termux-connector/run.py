from rapkp.termux_runtime.server import main

if __name__ == '__main__':
    main()
