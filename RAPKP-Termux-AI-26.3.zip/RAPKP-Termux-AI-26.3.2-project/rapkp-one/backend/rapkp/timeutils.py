from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from .errors import CalculationError

if TYPE_CHECKING:
    from .models import Moment

UTC = timezone.utc
EPOCH = datetime(1970, 1, 1, tzinfo=UTC)


def resolve_local(moment: Moment) -> datetime:
    naive = datetime.combine(moment.date, moment.time)
    zone = ZoneInfo(moment.place.timezone)
    candidates = [naive.replace(tzinfo=zone, fold=fold) for fold in (0, 1)]
    valid = [c.astimezone(UTC).astimezone(zone).replace(tzinfo=None) == naive for c in candidates]
    if not any(valid):
        raise CalculationError(
            "NONEXISTENT_LOCAL_TIME",
            "This local time falls in a daylight-saving gap. Correct the time; it will not be approximated.",
        )
    ambiguous = all(valid) and candidates[0].utcoffset() != candidates[1].utcoffset()
    if ambiguous and moment.fold is None:
        raise CalculationError(
            "AMBIGUOUS_LOCAL_TIME",
            "This local time occurs twice. Set fold=0 for the first occurrence or fold=1 for the second.",
        )
    chosen = moment.fold if moment.fold is not None else (0 if valid[0] else 1)
    if not valid[chosen]:
        raise CalculationError("INVALID_TIME_FOLD", "The selected occurrence is not a valid local civil time.")
    utc = candidates[chosen].astimezone(UTC)
    if not 1900 <= utc.year <= 2099:
        raise CalculationError("DATE_RANGE", "The resolved UTC instant must be within 1900–2099.")
    return utc


def utc_to_jd(dt: datetime) -> float:
    if dt.tzinfo is None:
        raise ValueError("Timezone-aware datetime required")
    return 2440587.5 + (dt.astimezone(UTC) - EPOCH).total_seconds() / 86400


def jd_to_utc(jd: float) -> datetime:
    return EPOCH + timedelta(days=jd - 2440587.5)


def to_tick(dt: datetime) -> int:
    if dt.tzinfo is None:
        raise ValueError("Timezone-aware datetime required")
    delta = dt.astimezone(UTC) - EPOCH
    return (delta.days * 86400 + delta.seconds) * 1_000_000 + delta.microseconds


def from_tick(tick: int) -> datetime:
    return EPOCH + timedelta(microseconds=tick)
