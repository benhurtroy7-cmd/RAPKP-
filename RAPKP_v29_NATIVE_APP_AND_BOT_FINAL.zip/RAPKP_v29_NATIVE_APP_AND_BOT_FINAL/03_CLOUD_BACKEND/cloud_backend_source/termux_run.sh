#!/usr/bin/env bash
# RAPKP v26.1 — Run Cloud/Termux API on Android phone
# URL inside RAPKP app: http://localhost:8000
set -e
cd "$(dirname "$0")" || exit 1

echo "== RAPKP v26.1 Termux API setup =="
echo "Folder: $(pwd)"

echo "== Installing Python requirements =="
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt

echo "== Preloading ephemeris (first time downloads de421.bsp) =="
python - <<'PY'
from skyfield.api import load
load('de421.bsp')
print('DE421 ready')
PY

echo ""
echo "RAPKP v26.1 API starting at: http://localhost:8000"
echo "Keep this Termux window open. Press Ctrl-C to stop."
echo "Then in RAPKP app: Me -> Cloud API URL -> http://localhost:8000 -> Save & Re-connect"
echo ""
PORT=8000 python server.py
