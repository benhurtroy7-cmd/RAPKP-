#!/usr/bin/env bash
# Rebuilds the native build toolchain in a cache directory that is NOT part of the
# workspace snapshot. The APK/AAB artifacts under native-artifacts/android/ are the
# deliverables; this script only exists so any machine (or a later session) can
# reproduce them. Everything installed here is third-party, licence-reviewed.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CACHE="${RAPKP_TOOLCHAIN:-$HOME/.cache/rapkp-termux}"
NODE_VERSION="${NODE_VERSION:-v22.23.3}"
JDK_MAJOR="${JDK_MAJOR:-21}"
ANDROID_API="${ANDROID_API:-36}"
ANDROID_BUILD_TOOLS="${ANDROID_BUILD_TOOLS:-36.0.0}"
mkdir -p "$CACHE"

say(){ printf '\n== %s\n' "$*"; }

say "Node $NODE_VERSION"
if [ ! -x "$CACHE/node/bin/node" ]; then
  curl -fsSL -o "$CACHE/node.tar.xz" "https://nodejs.org/dist/$NODE_VERSION/node-$NODE_VERSION-linux-x64.tar.xz"
  rm -rf "$CACHE/node" && mkdir -p "$CACHE/node"
  tar -xJf "$CACHE/node.tar.xz" -C "$CACHE/node" --strip-components=1
  rm -f "$CACHE/node.tar.xz"
fi
"$CACHE/node/bin/node" --version

say "Temurin JDK $JDK_MAJOR"
if [ ! -x "$CACHE/jdk/bin/javac" ]; then
  curl -fsSL -o "$CACHE/jdk.tar.gz" \
    "https://api.adoptium.net/v3/binary/latest/$JDK_MAJOR/ga/linux/x64/jdk/hotspot/normal/eclipse"
  rm -rf "$CACHE/jdk" && mkdir -p "$CACHE/jdk"
  tar -xzf "$CACHE/jdk.tar.gz" -C "$CACHE/jdk" --strip-components=1
  rm -f "$CACHE/jdk.tar.gz"
fi
"$CACHE/jdk/bin/javac" -version

say "Android SDK (platform $ANDROID_API, build-tools $ANDROID_BUILD_TOOLS)"
export JAVA_HOME="$CACHE/jdk"
export ANDROID_HOME="$CACHE/android/sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl -fsSL -o "$CACHE/cmdline-tools.zip" \
    "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest" "$CACHE/cmdline-tools"
  mkdir -p "$CACHE/cmdline-tools"
  unzip -q "$CACHE/cmdline-tools.zip" -d "$CACHE/cmdline-tools"
  mv "$CACHE/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm -rf "$CACHE/cmdline-tools" "$CACHE/cmdline-tools.zip"
fi
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 || true
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --install \
  "platform-tools" "platforms;android-$ANDROID_API" "build-tools;$ANDROID_BUILD_TOOLS" >/dev/null

say "Gradle distribution (wrapper-managed, $CACHE/gradle)"
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$CACHE/gradle}"
mkdir -p "$GRADLE_USER_HOME"

cat <<EOF

Toolchain ready. Build with:
  export JAVA_HOME=$CACHE/jdk
  export ANDROID_HOME=$CACHE/android/sdk
  export GRADLE_USER_HOME=$CACHE/gradle
  export PATH=$CACHE/node/bin:\$JAVA_HOME/bin:\$PATH
  $ROOT/scripts/build-android.sh
EOF
