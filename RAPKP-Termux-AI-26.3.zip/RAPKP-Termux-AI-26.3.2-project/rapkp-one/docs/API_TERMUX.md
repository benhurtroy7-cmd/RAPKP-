# Local Termux API

Phone binding: 127.0.0.1:8765 only. Public liveness: GET /health/live. Pair proof: GET /health/challenge?nonce=<32 hex chars>; response is HMAC-SHA256 of "rapkp-server-v1\n" + nonce using the private pairing token. The native app verifies this before sending sensitive requests. Other routes require the private Bearer pairing token.

- GET /api/v1/status: masked module/provider/AI readiness, never model keys.
- POST /api/v1/readings: validated structured input → actual ephemeris/KP/dasha report.
- POST /api/v1/settings: authenticated local ephemeris/model/key/consent setup; keys remain in a mode-0600 Termux file.
- POST /api/v1/ai/jobs: report_id + explicit consent; only a server-computed cached report is accepted. Returns a bounded queued job.
- GET /api/v1/ai/jobs/{id}: queued/running/completed/failed; no unstructured substitute answer.
- GET /api/v1/rules, /api/v1/domains, /api/v1/horary/{number}: reference data, not forced predictions.
- POST /api/v1/control/stop: authenticated stop of this connector, never a broad process kill.

No provider endpoint is accepted from question text. Hosted model calls use fixed official HTTPS hosts and disallow redirects. No automatic paid retry is made. Questions and keys never become shell text. The separate --test-demo mode requires an explicit development flag and blocks live paid model calls.
