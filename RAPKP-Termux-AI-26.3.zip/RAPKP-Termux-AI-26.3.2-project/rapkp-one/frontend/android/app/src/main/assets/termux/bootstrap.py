# Executed through Termux's documented RUN_COMMAND stdin path after explicit permission.
# No provider API key, question or birth data is placed in shell text/arguments.
import base64
import hashlib
import hmac
import io
import json
import os
import secrets
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path


def fail(message):
    print(json.dumps({'ok':False,'message':message}));raise SystemExit(1)
def write_private(path,value):
    temp=path.with_name(path.name+'.tmp');fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2)
    os.replace(temp,path);os.chmod(path,0o600)

PORT=8765;PRODUCT='RAPKP Termux AI';STOP_FILE='stop-request'
def service_alive():
    """Fingerprint whatever answers the local port. None means nothing is listening."""
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/health/live'%PORT,timeout=1) as response:
            data=json.load(response)
        return data if isinstance(data,dict) else {'product':None}
    except (urllib.error.URLError,TimeoutError,ValueError,OSError):
        return None
def wait_gone(seconds):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if service_alive() is None:return True
        time.sleep(.15)
    return False
def stop_authenticated(token):
    """Stop a running RAPKP instance that still holds this home's token."""
    try:
        nonce=secrets.token_hex(16)
        with urllib.request.urlopen('http://127.0.0.1:%d/health/challenge?nonce=%s'%(PORT,nonce),timeout=2) as response:challenge=json.load(response)
        expected=hmac.new(token.encode(),('rapkp-server-v1\n'+nonce).encode(),hashlib.sha256).hexdigest()
        if not isinstance(challenge,dict) or not hmac.compare_digest(challenge.get('proof',''),expected):return False
        req=urllib.request.Request('http://127.0.0.1:%d/api/v1/control/stop'%PORT,data=b'{}',headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=2) as response:response.read()
    except urllib.error.HTTPError:
        fail('An existing RAPKP service rejected restart authorization. Its configuration was not replaced.')
    except (urllib.error.URLError,TimeoutError,ValueError):
        return False
    return wait_gone(8)
def request_stop(root):
    """Signal a running instance through the shared private home directory.

    The home directory is the same trust boundary as the stored pairing token, and the
    signal is never reachable over the network. It exists so re-pairing can reclaim the
    port from an instance whose token is unknown (config removed/rewritten, older build).
    """
    try:
        fd=os.open(root/STOP_FILE,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600);os.close(fd);return True
    except OSError:
        return False
def clear_stop_request(root):
    try:(root/STOP_FILE).unlink()
    except OSError:pass

try:
    if sys.version_info<(3,10):fail('Python 3.10+ is required; current libephemeris releases require Python 3.12+.')
    incoming=sys.stdin.read(350000)
    spec=json.loads(incoming)
    token=spec['token'];version=spec['version'];payload=base64.b64decode(spec['bundle'],validate=True)
    if not isinstance(token,str) or len(token)!=64 or any(c not in '0123456789abcdef' for c in token):fail('Invalid pairing request')
    if not version.replace('.','').replace('-','').isalnum():fail('Invalid version')
    if hashlib.sha256(payload).hexdigest()!=spec['sha256']:fail('Backend bundle integrity check failed')
    home=Path.home();root=home/'.rapkp-one'
    if root.is_symlink():fail('The connector directory must not be a symlink')
    root.mkdir(mode=0o700,exist_ok=True);os.chmod(root,0o700)
    clear_stop_request(root)
    config_path=root/'config.json';config={}
    if config_path.exists():
        try:stored=json.loads(config_path.read_text())
        except ValueError:stored={}
        if not isinstance(stored,dict):stored={}
        if stored.get('product') not in (None,PRODUCT):fail('A different configuration exists. Nothing was overwritten.')
        config=stored
    # Stop only a RAPKP instance, never another service that happens to use the port.
    running=service_alive()
    if running is not None:
        if running.get('product')!=PRODUCT:fail('Port 8765 belongs to another service. Nothing was stopped or replaced. Stop that service first, then retry.')
        stopped=False
        if isinstance(config.get('token'),str) and config.get('token'):
            stopped=stop_authenticated(config['token'])
        if not stopped:
            # The running instance cannot prove it owns this home's token: its config was
            # removed or rewritten, or it is an older build. Signal it through the shared
            # private home instead of leaving the port permanently unusable.
            if not request_stop(root):
                fail('Could not signal the running connector to stop. Retry, or stop it in Termux with: pkill -f "rapkp-one/start.py"')
            stopped=wait_gone(15)
            clear_stop_request(root)
            if not stopped:
                fail('A RAPKP connector is still holding port 8765 and did not stop. In Termux run: pkill -f "rapkp-one/start.py" then retry. No other process was killed.')
    folder=root/'versions'/version;folder.parent.mkdir(exist_ok=True)
    temporary=Path(tempfile.mkdtemp(prefix='install-',dir=root))
    try:
        with zipfile.ZipFile(io.BytesIO(payload)) as z:
            total=0
            for entry in z.infolist():
                name=Path(entry.filename)
                if name.is_absolute() or '..' in name.parts or ((entry.external_attr>>16)&0o170000)==0o120000:fail('Unsafe backend bundle entry')
                total+=entry.file_size
                if total>1500000:fail('Backend bundle is too large')
                dest=temporary/name
                if entry.is_dir():dest.mkdir(parents=True,exist_ok=True);continue
                dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(entry.filename))
        if not (temporary/'run.py').is_file():fail('Incomplete backend bundle')
        if folder.exists():shutil.rmtree(folder)
        temporary.replace(folder)
    finally:
        if temporary.exists():shutil.rmtree(temporary)
    config.update(product='RAPKP Termux AI',version=version,token=token)
    config.setdefault('ephemeris',{'provider':'auto','path':'','lib_file':''})
    config.setdefault('ai',{'provider':'openai','model':'gpt-6-astra','api_key':'','consent':False,'language':'English'})
    write_private(config_path,config)
    # Fixed launcher; starts only this installed connector. No arbitrary command input.
    launch=root/'start.py'
    launch.write_text('import runpy,sys\nfrom pathlib import Path\np=Path('+repr(str(folder))+')\nsys.path.insert(0,str(p))\nsys.argv=[str(p/"run.py"),"--home",'+repr(str(root))+',"--port","8765"]\nrunpy.run_path(str(p/"run.py"),run_name="__main__")\n')
    os.chmod(launch,0o600)
    boot=home/'.termux/boot';boot.mkdir(parents=True,exist_ok=True)
    hook=boot/'90-rapkp-one'
    if hook.exists() and 'RAPKP generated boot hook' not in hook.read_text():fail('An existing custom 90-rapkp-one boot script was preserved. Rename it before enabling our hook.')
    # Boot launches this task in the background; no other Termux scripts are changed.
    hook.write_text('#!/data/data/com.termux/files/usr/bin/sh\n# RAPKP generated boot hook\nexport OPENBLAS_NUM_THREADS=1\nexec "'+sys.executable+'" "'+str(launch)+'" </dev/null >>"'+str(root/'service.log')+'" 2>&1\n')
    os.chmod(hook,0o700)
    print(json.dumps({'ok':True,'version':version,'port':8765,'boot_hook':True,'message':'Connector installed. Existing ephemeris libraries were not replaced. Start the background service from the app.'}))
except SystemExit:raise
except Exception as e:fail('Connector setup did not complete ('+type(e).__name__+'). Open Termux and review permissions/Python availability. No provider credentials were printed.')
