# Prediction validation — what evidence would actually be required

This release validates **software calculations and rule execution**, not the proposition that astrology reliably predicts personal events. Those are different questions.

## Three independent layers

1. **Numerical agreement:** compare matched coordinate/time/ayanamsa/node conventions against an independent ephemeris; quantify residuals, boundaries and unsupported ranges. This bundle includes finite numeric fixtures and measured residuals.
2. **Domain-rule fidelity:** a knowledgeable reviewer supplies each numbered rule, precedence, exceptions and expected cases. Encode them with citations, verify inter-rule consistency, and test conflicting examples. The missing 21-rule pack prevents completing this layer.
3. **Empirical forecast performance:** lock predictions before outcomes occur; compare them against independently verified outcomes and appropriate baselines. No such evidence was supplied or generated here.

## A defensible study plan

- Specify event domains and objective outcome definitions before collecting results. Include non-events and ordinary base rates.
- Use consented, de-identified case IDs, with lawful data handling. Record birth-time uncertainty and revisions separately.
- Freeze code, rule pack, prompts, models, thresholds, prediction date and forecast horizon. Never let later facts, retrospectively rectified times or adjusted windows leak into the test split.
- Separate development/calibration data from a time-forward, untouched holdout. Avoid selecting only successful anecdotes.
- Predeclare abstention/coverage rules. Report abstentions and unavailable inputs, not just attempted cases.
- For binary forecasts report confusion matrices, sensitivity/specificity, base-rate baselines, accuracy with uncertainty and domain-specific sample sizes. Do not report accuracy alone on an imbalanced dataset.
- Only if a genuinely calibrated probability model exists, evaluate calibration curves, Brier score/log loss and out-of-sample discrimination. **Do not feed this product's 0–10 heuristic straight into a probability formula.**
- For dates, predeclare a scoring window and date-error metric; do not move the window after learning the answer.
- Have an independent reviewer reproduce results. Report negative results, methodology, drift and version changes.

An 81.2% target is not a validation method and is not evidence that it has been achieved. No “Astra GPT-6” benchmark specification, dataset, sampling design or independent certificate was supplied. Passing Python/browser tests cannot establish that number.

## Practical boundaries

Do not make medical diagnoses, longevity/death claims, legal conclusions or investment recommendations through this system. Use grounded real-world information for consequential decisions. Symbolic interpretation can be offered transparently without pretending it is a scientifically established probability model.
