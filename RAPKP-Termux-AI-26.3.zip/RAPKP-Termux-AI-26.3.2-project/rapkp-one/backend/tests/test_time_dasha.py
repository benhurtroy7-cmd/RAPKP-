from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError
from rapkp.dasha import CYCLE_TICKS, YEAR_TICKS, Vimshottari, _subperiods
from rapkp.errors import CalculationError
from rapkp.models import Moment, Place
from rapkp.timeutils import from_tick, jd_to_utc, resolve_local, to_tick, utc_to_jd

UTC = timezone.utc


def moment(day, time, zone="Asia/Kolkata", fold=None):
    return Moment(
        date=day, time=time, place={"label": "test", "latitude": 13, "longitude": 80, "timezone": zone}, fold=fold
    )


def test_ist_conversion():
    assert resolve_local(moment("1985-05-12", "09:53")).isoformat() == "1985-05-12T04:23:00+00:00"


def test_j2000_utc_julian_conversion():
    dt = datetime(2000, 1, 1, 12, tzinfo=UTC)
    assert utc_to_jd(dt) == 2451545
    assert jd_to_utc(2451545) == dt


def test_microsecond_regression():
    base = datetime(2000, 1, 1, 12, tzinfo=UTC)
    delta = utc_to_jd(base.replace(microsecond=360000)) - utc_to_jd(base)
    assert abs(delta * 86400 - 0.36) < 0.0001
    assert abs((jd_to_utc(utc_to_jd(base.replace(microsecond=360000))) - base).total_seconds() - 0.36) < 0.0001


def test_aware_required():
    with pytest.raises(ValueError):
        utc_to_jd(datetime(2000, 1, 1))
    with pytest.raises(ValueError):
        to_tick(datetime(2000, 1, 1))


def test_tick_roundtrip_exact():
    for dt in [datetime(1900, 1, 1, tzinfo=UTC), datetime(2099, 12, 31, 23, 59, 59, 999999, tzinfo=UTC)]:
        assert from_tick(to_tick(dt)) == dt


def test_dst_gap_is_not_approximated():
    with pytest.raises(CalculationError, match="daylight-saving gap"):
        resolve_local(moment("2026-03-08", "02:30", "America/New_York"))


def test_dst_fold_requires_explicit_choice():
    with pytest.raises(CalculationError, match="occurs twice"):
        resolve_local(moment("2026-11-01", "01:30", "America/New_York"))
    a = resolve_local(moment("2026-11-01", "01:30", "America/New_York", 0))
    b = resolve_local(moment("2026-11-01", "01:30", "America/New_York", 1))
    assert (b - a).total_seconds() == 3600


@pytest.mark.parametrize("zone", ["IST", "EST", "Not/AZone", "../../etc/passwd"])
def test_bad_or_ambiguous_zone_rejected(zone):
    with pytest.raises(ValidationError):
        moment("2000-01-01", "12:00", zone)


@pytest.mark.parametrize("day", ["1899-12-31", "2100-01-01", "2001-02-29"])
def test_invalid_dates_rejected(day):
    with pytest.raises(ValidationError):
        moment(day, "12:00")


def test_timezone_boundary_out_of_supported_utc_range():
    with pytest.raises(CalculationError):
        resolve_local(moment("1900-01-01", "00:01", "Pacific/Auckland"))


def test_offset_on_time_rejected():
    with pytest.raises(ValidationError):
        moment("2000-01-01", "12:00:00+05:30")


def test_nonfinite_coordinate_rejected():
    with pytest.raises(ValidationError):
        Place(latitude=float("nan"), longitude=0, timezone="UTC")


def test_first_mahadasha_birth_offset_regression():
    birth = datetime(2000, 1, 1, tzinfo=UTC)
    d = Vimshottari(birth, 20 / 3)  # halfway through Ketu's star; 3.5 years already consumed
    r = d.report(birth)
    assert r["mahadasha"]["lord"] == "Ketu"
    assert r["bhukti"]["lord"] == "Rahu"  # legacy incorrectly restarted at Ketu bhukti
    assert r["balance_at_birth_years"] == 3.5
    assert datetime.fromisoformat(r["mahadasha"]["start"]) < birth


def test_exact_major_boundary():
    birth = datetime(2000, 1, 1, tzinfo=UTC)
    d = Vimshottari(birth, 0)
    edge = from_tick(to_tick(birth) + 7 * YEAR_TICKS)
    assert d.report(edge)["mahadasha"]["lord"] == "Venus"
    assert d.report(edge - timedelta(microseconds=1))["mahadasha"]["lord"] == "Ketu"


def test_120_year_cycles_do_not_recurse():
    birth = datetime(1900, 1, 1, tzinfo=UTC)
    d = Vimshottari(birth, 12.9)
    for age in [119, 120, 121, 239, 240]:
        result = d.report(from_tick(to_tick(birth) + age * YEAR_TICKS))
        assert result["mahadasha"]["lord"]
    one = d.report(birth)
    two = d.report(from_tick(to_tick(birth) + CYCLE_TICKS))
    assert one["mahadasha"]["lord"] == two["mahadasha"]["lord"]
    assert one["bhukti"]["lord"] == two["bhukti"]["lord"]
    assert one["antara"]["lord"] == two["antara"]["lord"]


def test_before_birth_rejected():
    birth = datetime(2000, 1, 1, tzinfo=UTC)
    with pytest.raises(ValueError):
        Vimshottari(birth, 0).report(birth - timedelta(seconds=1))


@pytest.mark.parametrize("first", ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"])
def test_nested_subdivision_no_gaps(first):
    p = list(_subperiods(123456789, 987654321234567, first))
    assert p[0][1] == 123456789 and p[-1][2] == 987654321234567
    assert all(a[2] == b[1] for a, b in zip(p, p[1:], strict=False))
    assert all(b > a for _, a, b in p)


@pytest.mark.parametrize("longitude", [0, 13.333333333333334, 29.999, 87.8, 180, 299.8, 359.9999])
def test_all_dasha_levels_contain_target(longitude):
    birth = datetime(1971, 1, 1, tzinfo=UTC)
    d = Vimshottari(birth, longitude)
    for age in [0, 0.01, 10, 40, 119.9, 160]:
        dt = from_tick(to_tick(birth) + round(age * YEAR_TICKS))
        r = d.report(dt)
        periods = [r["mahadasha"], r["bhukti"], r["antara"]]
        for p in periods:
            assert datetime.fromisoformat(p["start"]) <= dt < datetime.fromisoformat(p["end"])
        assert periods[0]["start"] <= periods[1]["start"] <= periods[2]["start"]
        nxt = r["upcoming_antaras"]
        assert all(a["end"] == b["start"] for a, b in zip(nxt, nxt[1:], strict=False))


def test_timeline_count_bounded():
    d = Vimshottari(datetime(2000, 1, 1, tzinfo=UTC), 0)
    with pytest.raises(ValueError):
        d.report(datetime(2020, 1, 1, tzinfo=UTC), 1000)
