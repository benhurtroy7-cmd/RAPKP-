# Source audit — supplied RAPKP v26

## Scope and method

Reviewed the 14-page `RAPKP v26 Master Astrologer AI Code.pdf` and the accompanying operating prompt. Their hashes and availability are in `qa/source-manifest.json`. The PDF was inspected statically and selected algorithms were independently exercised/reimplemented; the unmodified PDF was **not** represented as a runnable, fully validated source repository. No v17–v25 source releases were provided. Alias assignments at the end of the PDF are not historical-version QA.

The new core is a clean, separately tested implementation. It retains the stated KP intent and explicitly sourced domain house sets, not unsupported accuracy/endorsement claims.

## Findings and dispositions

| ID | Severity | Supplied behavior / evidence | New disposition |
|---|---|---|---|
| V26-01 | Critical | pp. 7–8: missing bodies/engine exceptions become zero-degree positions with invented star/sub/house values | Fail-closed error; nine finite bodies required |
| V26-02 | Critical | pp. 6–7: house failure becomes equally spaced cusps, sometimes with Asc=0, despite a Placidus label | Reject unavailable/degenerate/unsupported Placidus results; no substitute |
| V26-03 | High | pp. 12–13: “validated”, “commercial ready” and numerical-accuracy text printed unconditionally | Measured build evidence and per-component statuses; no blanket confirmation |
| V26-04 | High | p. 3: microseconds divided by 3,600,000 to obtain hours, instead of 3,600,000,000 | Tested timezone-aware conversions and exact integer-microsecond period boundaries |
| V26-05 | High | pp. 9–10: first partial mahadasha uses elapsed-since-birth as if the mahadasha started at birth | Reconstruct full-period start using the Moon's consumed nakshatra fraction before selecting bhukti/antara |
| V26-06 | High | p. 10: shortened first cycle can leave a tail below 120 years where recursive modulo does not advance | Bounded cycle indexing, no recursive retry |
| V26-07 | High | p. 8: Ketu speed is negated relative to Rahu although its longitude is Rahu +180° | Same longitudinal derivative/motion sign, tested |
| V26-08 | High | pp. 10–11: numerator can add 3+2+2+1 but denominator grows by only 3 | Replace misleading “percentage” with a separately disclosed bounded match index; no probability semantics |
| V26-09 | High | p. 11: target labelled IST but parsed using the subject's fixed UTC offset; no DST ambiguity rejection | Explicit evaluation location/timezone and DST-gap/fold checks |
| V26-10 | Medium | p. 10: weekday ruler derived from UTC date rather than local analysis date | Local civil weekday, explicitly labelled as **not sunrise-based** |
| V26-11 | High | p. 5: config parse exception returns before ayanamsa initialisation; later broad catches can mask failure | Typed mandatory input, no implicit config-person fallback |
| V26-12 | High | pp. 5, 11–12: an embedded personal profile and fixed future target date can be used without confirmation | No default person/date-of-event; synthetic demo explicitly labelled |
| V26-13 | High | pp. 6–8: tropical-to-sidereal shift omits the true-vs-mean equinox/nutation distinction needed for the selected Swiss-compatible sidereal convention | IAU 2000A nutation removal plus KP mean ayanamsa; finite reference residuals recorded |
| V26-14 | Medium | default OpenEphem assemble requests extra unsupported/unneeded bodies, can degrade gracefully and fetch data on first use | Pinned direct primitives, seven classical bodies plus explicit node mode, verified preinstalled kernel |
| V26-15 | High | pp. 10–11: limited ownership/occupation scoring is not a documented complete KP hierarchy/cuspal decision system | Inspectable A/B/C/D baseline and limited node agency; not labelled the missing 21 rules |
| V26-16 | High | prompt: unspecified AstroSage endpoints, credentials, “Astra GPT-6” test protocol and compulsory ≥81.2% | Not configured/not verifiable; no fabricated integration or accuracy certificate |
| V26-17 | High | prompt: server localhost conflated with a user's phone; expired supplied cloud host | Actual connectivity recorded; explicit deployment/device boundary and opt-in fallback |
| V26-18 | Medium | prompt: clear foreign platform UI and auto-upload to undocumented Arena endpoint | Clear only this app's field; prepare/export diagnostics without automatic external upload |

## Still missing, not “fixed by imagination”

The exact numbered 11+10 rules; approved professor-specific sequence; complete node conjunction/aspect agency; a documented sunrise-based ruling-day convention; full horary-judgment convention; external AstroSage contract; empirical prediction dataset; historical release source provenance.

The 249-segment table is implemented and tested, but the product does not convert a table lookup into a horary judgment. The original database/profile-management concept is intentionally replaced by stateless reports rather than shipping an unauthenticated personal-data store. Persistent profiles, billing and public identity management are not implemented.

## Supplied endpoint check

`qa/supplied-endpoint-check.json` records the original cloud URL returning **502 / sandbox not found** on 30 September 2026. At that time this workspace's localhost had no listener. That check did **not** test the user's phone. The new workbench's local listener is a new product instance, not proof that the supplied Termux service was repaired.
