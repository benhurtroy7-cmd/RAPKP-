# Operator Runbook

## Daily

- Check /health
- Check recent bug reports
- Check failed PDF readings
- Review corrections

## Weekly

- Export database
- Review prediction rules
- Test sample predictions
- Test PDF report

## Common fixes

### Cloud sleeping
Retry after 30–60 seconds. Free Render sleeps.

### 403
Token mismatch. Check RAPKP_TOKEN.

### PDF fails
Check pypdf/reportlab installed and PDF size.

### Wrong prediction
Add correction/rule in Admin/Prediction Rules.
