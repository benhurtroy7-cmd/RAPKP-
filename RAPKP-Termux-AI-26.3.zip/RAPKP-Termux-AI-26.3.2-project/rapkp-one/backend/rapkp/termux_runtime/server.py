"""Loopback-only, token-protected Termux service with bounded asynchronous AI jobs."""

import argparse
import copy
import hashlib
import hmac
import json
import os
import platform
import re
import secrets
import threading
import time
from collections import OrderedDict
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from queue import Full, Queue
from urllib.parse import urlsplit

from .. import __version__
from ..errors import CalculationError
from ..kp import horary_segment
from ..report import create_report
from ..rules import DOMAINS, registry
from .ai import MODELS, interpret
from .contracts import parse_request
from .providers import SwissAdapter, available, find_swiss_path

PRODUCT = "RAPKP Termux AI"
MAX_BODY = 32768


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_name(path.name + ".tmp")
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(temp, path)
    os.chmod(path, 0o600)


def load_config(home):
    p = Path(home) / "config.json"
    if not p.is_file():
        raise RuntimeError("Pair/setup this Termux connector from the app first.")
    c = json.loads(p.read_text())
    if len(c.get("token", "")) < 32:
        raise RuntimeError("Valid pairing token required.")
    return c


class State:
    def __init__(self, home, testing=False, ai_callable=interpret):
        self.home = Path(home)
        self.config = load_config(home)
        self.testing = testing
        self.ai_callable = ai_callable
        self.lock = threading.RLock()
        self.calc_lock = threading.BoundedSemaphore(1)
        self.reports = OrderedDict()
        self.jobs = OrderedDict()
        self.queue = Queue(maxsize=2)
        self.engine = None
        self.engine_error = {"code": "ENGINE_STARTING", "message": "Checking installed ephemeris/data."}
        self.modules = {}
        self.closed = False
        self.rate = {}
        self.stop_file = self.home / "stop-request"
        self.started_at = time.time()
        self.stop_hook = None
        threading.Thread(target=self.initialize, daemon=True).start()
        threading.Thread(target=self.worker, daemon=True).start()
        threading.Thread(target=self.watch_stop_request, daemon=True).start()

    def watch_stop_request(self):
        """Token-free stop that only this connector's own private home can trigger.

        Re-pairing must be able to reclaim port 8765 from an instance whose token is
        unknown (its config.json was removed or rewritten, or it is an older build).
        The shared home directory is the same trust boundary as the stored token
        file, so a stop request placed there is safe; it is never reachable over the
        network. A request created before this process started is ignored, so a stale
        file can never shut down a freshly started service.
        """
        while not self.closed:
            try:
                if self.stop_file.exists() and self.stop_file.stat().st_mtime >= self.started_at - 1:
                    hook = self.stop_hook
                    if hook is None:
                        time.sleep(0.2)
                        continue
                    try:
                        self.stop_file.unlink()
                    except OSError:
                        pass
                    threading.Thread(target=hook, daemon=True).start()
                    return
            except OSError:
                pass
            time.sleep(0.4)

    def initialize(self):
        try:
            mods = available()
            settings = self.config.get("ephemeris", {})
            provider = settings.get("provider", "auto")
            path = settings.get("path") or find_swiss_path(self.home.parent)
            if path and not settings.get("path"):
                with self.lock:
                    self.config.setdefault("ephemeris", {})["path"] = path
                    atomic_json(self.home / "config.json", self.config)
            if provider == "auto":
                provider = (
                    "swisseph"
                    if mods.get("swisseph", {}).get("installed") and path
                    else "libephemeris"
                    if mods.get("libephemeris", {}).get("installed")
                    else "swisseph"
                )
            engine = SwissAdapter(
                provider, path, bool(self.testing and settings.get("qa_moshier")), settings.get("lib_file", "")
            )
            # Prove that a complete chart can be computed before advertising readiness.
            engine.calculate_at_ut1(2451545.0, 13.0827, 80.2707, "mean")
            with self.lock:
                self.modules = mods
                self.engine = engine
                self.engine_error = None
        except Exception as e:
            with self.lock:
                self.modules = locals().get("mods", {})
                self.engine = None
                self.engine_error = {
                    "code": getattr(e, "code", "ENGINE_ERROR"),
                    "message": getattr(
                        e, "message", "Provider initialization failed. Check installed modules and ephemeris paths."
                    ),
                }

    def public_status(self):
        with self.lock:
            ai = self.config.get("ai", {})
            eph = self.config.get("ephemeris", {})
            return {
                "product": PRODUCT,
                "version": __version__,
                "now_ist": datetime.now(timezone.utc)
                .astimezone(__import__("zoneinfo").ZoneInfo("Asia/Kolkata"))
                .isoformat(),
                "environment": "test" if self.testing else "termux",
                "engine_ready": self.engine is not None,
                "engine_error": self.engine_error,
                "authentication_required": True,
                "rate_limit_scope": "local_process",
                "qa": {},
                "local_only": True,
                "python_version": platform.python_version(),
                "modules": self.modules,
                "ephemeris": {
                    "provider": eph.get("provider", "auto"),
                    "active_provider": self.engine.provider if self.engine else None,
                    "path": eph.get("path", ""),
                    "lib_file": eph.get("lib_file", ""),
                },
                "ai": {
                    "provider": ai.get("provider", "openai"),
                    "model": ai.get("model", "gpt-6-astra"),
                    "key_present": bool(ai.get("api_key")),
                    "consent": bool(ai.get("consent")),
                    "language": ai.get("language", "English"),
                    "configured": bool(ai.get("api_key") and ai.get("consent")),
                    "models": MODELS,
                },
                "boot_hook_present": (Path.home() / ".termux/boot/90-rapkp-one").is_file(),
            }

    def authorized(self, header):
        return hmac.compare_digest(header, "Bearer " + self.config["token"])

    def throttle(self, identity):
        now = int(time.time() // 60)
        with self.lock:
            key = (identity, now)
            self.rate[key] = self.rate.get(key, 0) + 1
            self.rate = {k: v for k, v in self.rate.items() if k[1] >= now - 1}
            if self.rate[key] > 180:
                raise CalculationError("RATE_LIMIT", "Too many local requests. Wait a minute before retrying.", 429)

    def reading(self, payload):
        req = parse_request(payload)
        engine = self.engine
        if not engine:
            raise CalculationError(self.engine_error["code"], self.engine_error["message"], 503)
        if not self.calc_lock.acquire(blocking=False):
            raise CalculationError("BUSY", "A calculation is already running. Retry shortly.", 429)
        try:
            report = create_report(engine, req)
        finally:
            self.calc_lock.release()
        report["provenance"]["termux_local"] = True
        with self.lock:
            self.reports[report["report_id"]] = (time.monotonic(), report)
            while len(self.reports) > 12:
                self.reports.popitem(last=False)
        return report

    def settings(self, data):
        if not isinstance(data, dict) or set(data) - {"ephemeris", "ai"}:
            raise CalculationError("INPUT_VALIDATION", "Unsupported setting fields.")
        with self.lock:
            config = copy.deepcopy(self.config)
            if "ephemeris" in data:
                x = data["ephemeris"]
                if (
                    not isinstance(x, dict)
                    or set(x) - {"provider", "path", "lib_file"}
                    or x.get("provider") not in {"auto", "swisseph", "libephemeris"}
                ):
                    raise CalculationError("INPUT_VALIDATION", "Invalid ephemeris configuration.")
                if any(not isinstance(x.get(k, ""), str) or len(x.get(k, "")) > 500 for k in ["path", "lib_file"]):
                    raise CalculationError("INPUT_VALIDATION", "Invalid ephemeris path.")
                config["ephemeris"] = {k: x.get(k, "") for k in ["provider", "path", "lib_file"]}
            if "ai" in data:
                x = data["ai"]
                if not isinstance(x, dict) or set(x) - {
                    "provider",
                    "model",
                    "api_key",
                    "clear_key",
                    "consent",
                    "language",
                }:
                    raise CalculationError("INPUT_VALIDATION", "Invalid AI settings.")
                old = config.get("ai", {})
                provider = x.get("provider", old.get("provider", "openai"))
                model = x.get("model", old.get("model", "gpt-6-astra"))
                if (
                    provider not in MODELS
                    or not isinstance(model, str)
                    or not re.fullmatch(r"[A-Za-z0-9._:-]{1,100}", model)
                ):
                    raise CalculationError("INPUT_VALIDATION", "Choose a valid provider and model.")
                key = x.get("api_key", "")
                if not isinstance(key, str) or len(key) > 8192:
                    raise CalculationError("INPUT_VALIDATION", "Invalid API key field.")
                if not key and old.get("provider", provider) == provider:
                    key = old.get("api_key", "")
                if x.get("clear_key"):
                    key = ""
                consent = x.get("consent", old.get("consent", False))
                if type(consent) is not bool:
                    raise CalculationError("INPUT_VALIDATION", "Explicit consent must be a boolean.")
                language = x.get("language", old.get("language", "English"))
                if language not in {"English", "Tamil", "Hindi"}:
                    raise CalculationError("INPUT_VALIDATION", "Choose a supported output language.")
                config["ai"] = {
                    "provider": provider,
                    "model": model,
                    "api_key": key.strip(),
                    "consent": consent,
                    "language": language,
                }
            atomic_json(self.home / "config.json", config)
            self.config = config
            if "ephemeris" in data:
                self.engine = None
                self.engine_error = {"code": "ENGINE_STARTING", "message": "Rechecking the selected provider."}
                threading.Thread(target=self.initialize, daemon=True).start()
        return self.public_status()

    def submit_ai(self, data):
        if not isinstance(data, dict) or set(data) != {"report_id", "consent"} or data["consent"] is not True:
            raise CalculationError("AI_CONSENT_REQUIRED", "Explicit request consent is required.", 409)
        with self.lock:
            cached = self.reports.get(data["report_id"])
            if not cached or time.monotonic() - cached[0] > 3600:
                raise CalculationError("REPORT_EXPIRED", "Recalculate before requesting AI interpretation.", 404)
            cfg = copy.deepcopy(self.config.get("ai", {}))
            if not cfg.get("api_key"):
                raise CalculationError("AI_KEY_MISSING", "Add your provider API key in Termux AI setup.", 409)
            if not cfg.get("consent"):
                raise CalculationError(
                    "AI_CONSENT_REQUIRED", "Allow the configured provider to receive the chart/question first.", 409
                )
            identity = hashlib.sha256((data["report_id"] + str(sorted(cfg.items()))).encode()).hexdigest()
            for job in self.jobs.values():
                if job["_identity"] == identity and job["status"] in {"queued", "running", "completed"}:
                    return self.job_public(job)
            job = {
                "job_id": secrets.token_hex(12),
                "report_id": data["report_id"],
                "status": "queued",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "_identity": identity,
            }
            if self.queue.full():
                raise CalculationError("AI_BUSY", "The AI queue is full. Wait for the current reading.", 429)
            self.jobs[job["job_id"]] = job
            while len(self.jobs) > 24:
                key, nextjob = next(iter(self.jobs.items()))
                if nextjob["status"] in {"queued", "running"}:
                    break
                self.jobs.pop(key)
            self.queue.put_nowait((job["job_id"], copy.deepcopy(cached[1]), cfg))
            return self.job_public(job)

    def job_public(self, job):
        return {k: v for k, v in job.items() if not k.startswith("_")}

    def get_job(self, identifier):
        with self.lock:
            job = self.jobs.get(identifier)
            if not job:
                raise CalculationError("JOB_NOT_FOUND", "The AI job is unavailable; it may have expired.", 404)
            return self.job_public(job)

    def worker(self):
        while not self.closed:
            item = self.queue.get()
            if item is None:
                return
            identifier, report, cfg = item
            with self.lock:
                self.jobs[identifier]["status"] = "running"
            try:
                if self.testing and self.ai_callable is interpret:
                    raise CalculationError(
                        "AI_DEMO_DISABLED",
                        "Live provider calls are disabled in unauthenticated developer demo mode.",
                        403,
                    )
                result = self.ai_callable(report, cfg)
            except Exception as e:
                with self.lock:
                    self.jobs[identifier].update(
                        status="failed",
                        error={
                            "code": getattr(e, "code", "AI_FAILED"),
                            "message": getattr(
                                e, "message", "AI interpretation failed. Your calculation is unchanged."
                            ),
                        },
                    )
            else:
                with self.lock:
                    self.jobs[identifier].update(status="completed", result=result)
            finally:
                self.queue.task_done()

    def close(self):
        self.closed = True
        try:
            self.queue.put_nowait(None)
        except Full:
            pass
        if self.engine:
            self.engine.close()


class Handler(BaseHTTPRequestHandler):
    server_version = "RAPKP-Termux"

    def log_message(self, *args):
        pass

    def reply(self, status, data):
        body = json.dumps(data, allow_nan=False, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        self.connection.settimeout(15)
        if self.headers.get("Transfer-Encoding"):
            if self.headers.get("Content-Length") or self.headers["Transfer-Encoding"].lower() != "chunked":
                raise CalculationError("BAD_TRANSFER", "Unsupported request encoding.", 400)
            chunks = []
            size = 0
            while True:
                line = self.rfile.readline(128)
                try:
                    n = int(line.strip().split(b";")[0], 16)
                except Exception:
                    raise CalculationError("BAD_TRANSFER", "Malformed request.", 400) from None
                if n == 0:
                    if self.rfile.readline(8193) != b"\r\n":
                        raise CalculationError("BAD_TRANSFER", "Unexpected request trailers.", 400)
                    break
                if n < 0 or size + n > MAX_BODY:
                    raise CalculationError("BODY_TOO_LARGE", "Request is too large.", 413)
                block = self.rfile.read(n)
                if len(block) != n or self.rfile.read(2) != b"\r\n":
                    raise CalculationError("BAD_TRANSFER", "Incomplete request.", 400)
                chunks.append(block)
                size += n
            raw = b"".join(chunks)
        else:
            try:
                n = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                raise CalculationError("BAD_TRANSFER", "Invalid request size.", 400) from None
            if n < 0 or n > MAX_BODY:
                raise CalculationError("BODY_TOO_LARGE", "Request is too large.", 413)
            raw = self.rfile.read(n)
        try:
            return json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except Exception:
            raise CalculationError(
                "INPUT_VALIDATION", "Send valid JSON; non-finite values are rejected.", 422
            ) from None

    def handle_request(self):
        state = self.server.state
        path = urlsplit(self.path).path
        if self.command == "GET" and path == "/health/challenge":
            from urllib.parse import parse_qs

            nonce = parse_qs(urlsplit(self.path).query).get("nonce", [""])[0]
            if not re.fullmatch(r"[a-f0-9]{32}", nonce):
                raise CalculationError("BAD_CHALLENGE", "Invalid pairing challenge.", 400)
            proof = hmac.new(
                state.config["token"].encode(), ("rapkp-server-v1\n" + nonce).encode(), hashlib.sha256
            ).hexdigest()
            return self.reply(200, {"product": PRODUCT, "nonce": nonce, "proof": proof})
        if self.command == "GET" and path == "/health/live":
            return self.reply(200, {"product": PRODUCT, "running": True, "version": __version__})
        if self.command == "GET" and path == "/health/ready":
            return self.reply(
                200 if state.engine else 503,
                {"product": PRODUCT, "ready": bool(state.engine), "error": state.engine_error},
            )
        if not state.testing and not state.authorized(self.headers.get("Authorization", "")):
            raise CalculationError(
                "PAIRING_REQUIRED", "Pair this app with Termux first. The local token was not accepted.", 401
            )
        state.throttle(self.client_address[0])
        if self.command == "GET":
            if path == "/api/v1/status":
                return self.reply(200, state.public_status())
            if path == "/api/v1/rules":
                return self.reply(200, registry())
            if path == "/api/v1/domains":
                return self.reply(200, {"domains": DOMAINS})
            if path.startswith("/api/v1/horary/"):
                try:
                    value = horary_segment(int(path.rsplit("/", 1)[1]))
                except ValueError:
                    raise CalculationError("HORARY_NUMBER", "Choose a number from 1 to 249.") from None
                return self.reply(200, value)
            if path.startswith("/api/v1/ai/jobs/"):
                return self.reply(200, state.get_job(path.rsplit("/", 1)[1]))
            # Static-only UI for explicit developer QA mode; never expose phone files.
            if state.testing and self.server.static_root:
                rel = path.lstrip("/") or "index.html"
                root = Path(self.server.static_root).resolve()
                file = (root / rel).resolve()
                if file.is_relative_to(root) and file.is_file():
                    import mimetypes

                    body = file.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", mimetypes.guess_type(str(file))[0] or "application/octet-stream")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
            raise CalculationError("NOT_FOUND", "Unknown local endpoint.", 404)
        if self.command == "POST":
            data = self.read_body()
            if path == "/api/v1/readings":
                return self.reply(200, state.reading(data))
            if path == "/api/v1/settings":
                return self.reply(200, state.settings(data))
            if path == "/api/v1/ai/jobs":
                return self.reply(202, state.submit_ai(data))
            if path == "/api/v1/control/stop":
                self.reply(200, {"stopping": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
        raise CalculationError("NOT_FOUND", "Unknown local endpoint.", 404)

    def do_GET(self):
        self.safe()

    def do_POST(self):
        self.safe()

    def safe(self):
        try:
            self.handle_request()
        except CalculationError as e:
            try:
                self.reply(e.status, {"error": {"code": e.code, "message": e.message}})
            except (BrokenPipeError, ConnectionResetError):
                pass
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            try:
                self.reply(
                    500,
                    {
                        "error": {
                            "code": "INTERNAL_ERROR",
                            "message": "Local service error; no substitute data was generated.",
                        }
                    },
                )
            except (BrokenPipeError, ConnectionResetError):
                pass


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16

    def __init__(self, address, state, static_root=None):
        self.state = state
        self.static_root = static_root
        self.connection_slots = threading.BoundedSemaphore(12)
        super().__init__(address, Handler)

    def get_request(self):
        request, address = super().get_request()
        request.settimeout(12)
        return request, address

    def process_request(self, request, address):
        if not self.connection_slots.acquire(blocking=False):
            try:
                request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.connection_slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.connection_slots.release()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--home", default=str(Path.home() / ".rapkp-one"))
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--test-demo", action="store_true")
    p.add_argument("--static")
    a = p.parse_args()
    if a.test_demo and os.getenv("RAPKP_TESTING") != "1":
        p.error("Developer demo mode requires RAPKP_TESTING=1 and must not be used with real provider keys")
    state = State(a.home, a.test_demo)
    try:
        server = Server(("0.0.0.0" if a.test_demo else "127.0.0.1", a.port), state, a.static)
    except OSError as e:
        state.close()
        print(
            f"{PRODUCT} could not listen on port {a.port} ({e}). Another process is using this port; "
            "this connector did not start and no chart or answer was produced. Re-pair from the app to "
            "stop the previous instance, or stop it in Termux with: pkill -f 'rapkp-one/start.py'",
            flush=True,
        )
        raise SystemExit(1) from None
    state.stop_hook = server.shutdown
    print(
        f"{PRODUCT} {__version__} ready to receive local requests on port {a.port}. No request bodies or secrets are logged.",
        flush=True,
    )
    try:
        server.serve_forever()
    finally:
        server.server_close()
        state.close()


if __name__ == "__main__":
    main()
