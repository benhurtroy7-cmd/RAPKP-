> Historical/general baseline. The current release is Termux-only; use TERMUX_AI_START.md, API_TERMUX.md and QA_TERMUX_AI.md. Native automation/live-account/device limits and AGPL engine terms there take precedence.

# Android upgrade — 26.2

## Install the new application, not the earlier RC2 APK

- File: `native-artifacts/android/RAPKP-One-26.3.0-termux.1.apk`.
- Launcher label: **RAPKP One 26.2**.
- Version: **26.3.0-termux.1**, version code **2603001**.
- Preview application ID: **com.rapkp.one.preview**.
- Minimum Android API 24 (Android 7); target/compile API 36.

This preview deliberately installs **alongside** the earlier `com.rapkp.one` evaluation app. The earlier signing key is not available for an in-place update. Open the **26.2** icon after installation; the old app is not silently replaced or migrated. Do not bypass Android's security warnings. Use your normal test-install workflow or `adb install` on a developer device.

The APK is debug-signed, not owner release-signed or store-approved. The separate AAB is unsigned, not directly installable. No physical phone/emulator execution was performed in this build environment.

## What is actually new

1. **Optional encrypted connection memory.** On Android, check “Remember this connection securely” and choose “Use connection”. Endpoints/tokens are encrypted with AES-GCM using a non-exported Android Keystore key. The profile is loaded into memory on next launch. A saved endpoint is checked automatically; birth details are not stored in this profile. Use “Forget saved connection” to remove it. Storage is opt-in, device-local and not a cloud vault.
2. **Native JSON file saving.** “Save JSON” and “Save inputs” open Android's document picker. Choose the location yourself. Exported files are plaintext and may contain personal birth details/questions. No broad external-storage permission or automatic upload is used.
3. **Input import.** Import a request JSON or a schema-1.0 RAPKP report. Only inputs are restored; cached positions, predictions and instructions are not accepted as calculations. Review and press Calculate yourself. Import is limited to 512 KiB; the UI preserves up to millisecond local time precision. Use the API/CLI for finer times.
4. **Preserved session workbench.** Changing pages no longer destroys the current form/report. Reload/exit still clears personal session fields unless you explicitly exported them. There is no persistent report database.
5. **Native navigation and build identity.** Android Back closes settings/menu, returns to Workbench, then uses a double-back exit. “About & updates” shows the UI version, backend version, installed package/build and native-feature availability.
6. **Native hardening and cleanup.** Legacy and Android-12+ backup/transfer exclusions, platform log suppression, WebView debugging disabled, vector/adaptive/monochrome icons and a corrected splash theme. Gradle upgraded to 8.14.5 and AppCompat to 1.8.0. Android lint completed with no errors or warnings.

## Connect it

The APK does **not** embed Python or the JPL kernel. Choose your own HTTPS RAPKP backend, or run the same backend in Termux and use **Use Termux on this phone**. Same-device Android loopback is the only cleartext exception. Do not put a shared production master token into a publicly distributed app. No API endpoint/secret is embedded in this APK.

For older reports: export JSON in the old app, then Import inputs in 26.2 and recalculate. A user-uploaded report is not authenticated proof of its chart or forecast.

## Verification and remaining checks

- Compilation, APK signature/package/version inspection, matching built web assets, Android lint and six Java AES-GCM algorithm tests were executed.
- JavaScript bridge contracts and browser import/export/session flows were tested separately.
- JVM crypto tests are **not** tests of a real phone's Keystore implementation. Hardware/device-backed storage, the system file picker, keyboard/Back behavior, OEM backup policies and lifecycle recovery still require device testing.
- Two instrumentation checks are supplied in `DevicePolicyInstrumentedTest.java` for the owner to run with `./gradlew connectedDebugAndroidTest`. They have **not** been reported as executed.
- Keystore storage protects data at rest, not a rooted/compromised device, malicious app updates, screenshots or secrets already loaded into the app's memory. Use test credentials in evaluation builds.

## Rebuild / owner signing

Use Node 22.12+, JDK 21+, Android platform 36 and the pinned npm lockfile. `bash scripts/build-android.sh` synchronises assets, builds the APK/AAB and runs Java tests/lint. Cold builds need network access. A machine-generated debug certificate may differ from this delivered APK; stable future in-place updates require your own persistent signing setup.

`bash scripts/sign-android-bundle.sh` signs the AAB only when the owner supplies a private keystore/alias and password environment variables. No owner signing key, account credentials, release signature or store upload was created for you. Change the canonical app identifier/branding only after checking your rights and store registration.
