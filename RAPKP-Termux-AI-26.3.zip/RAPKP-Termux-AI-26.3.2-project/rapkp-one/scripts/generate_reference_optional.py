#!/usr/bin/env python3
"""OPTIONAL offline reference tool, not a runtime dependency.
Run only in a separate QA environment where you have reviewed the pyswisseph
licence. This script does not distribute Swiss source, binary or data files.
"""
import json
import random
from datetime import datetime, timezone
from pathlib import Path

import swisseph as s

s.set_sid_mode(s.SIDM_KRISHNAMURTI)
s.set_ephe_path('/nonexistent-no-external-swiss-data')
rng=random.Random(2601)
places=[('Chennai',13.0827,80.2707),('London',51.5074,-0.1278),('New York',40.7128,-74.006),('Sydney',-33.8688,151.2093),('Equator',0,0),('Near limit N',65.8,25),('Near limit S',-65.8,-75)]
rows=[]
# 63 deterministic edge/season fixtures plus 32 seeded random fixtures.
for year in [1900,1925,1950,1971,1990,2000,2026,2050,2099]:
 for i,(name,lat,lon) in enumerate(places):
  month=1+(i*2)%12;day=1+(i*3)%27;hour=(i*3.75)%24
  rows.append((year,month,day,hour,name,lat,lon))
for i in range(32):
 year=rng.randint(1900,2099);month=rng.randint(1,12);day=rng.randint(1,28);hour=rng.uniform(0,24)
 rows.append((year,month,day,hour,f'random-{i:02d}',rng.uniform(-65.5,65.5),rng.uniform(-180,180)))
fixtures=[]
for year,month,day,hour,name,lat,lon in rows:
 jd=s.julday(year,month,day,hour,s.GREG_CAL)
 cs,angles=s.houses_ex(jd,lat,lon,b'P',s.FLG_SIDEREAL)
 bodies={}
 for body,p in [('Sun',s.SUN),('Moon',s.MOON),('Mercury',s.MERCURY),('Venus',s.VENUS),('Mars',s.MARS),('Jupiter',s.JUPITER),('Saturn',s.SATURN),('MeanNode',s.MEAN_NODE),('TrueNode',s.TRUE_NODE)]:
  pos,flags=s.calc_ut(jd,p,s.FLG_MOSEPH|s.FLG_SPEED|s.FLG_SIDEREAL)
  bodies[body]={'longitude':pos[0],'speed':pos[3],'flags':flags}
 fixtures.append({'id':f'{year}-{month:02}-{day:02}-{name}','jd_ut1':jd,'latitude':lat,'longitude':lon,'ayanamsa':s.get_ayanamsa_ut(jd),'cusps':cs,'bodies':bodies})
data={'reference':'Swiss Ephemeris / pyswisseph '+s.version,'generated_by':'isolated offline reference process; no AGPL code or ephemeris files distributed','authority':'Moshier for planetary positions; Swiss analytic Placidus; Krishnamurti sidereal','timescale':'JD UT1 numerical input shared by comparison; timezone resolution tested separately','seed':2601,'generated_at':datetime.now(timezone.utc).isoformat(),'fixtures':fixtures}
(Path(__file__).resolve().parents[1]/'backend/tests/fixtures/astronomy-reference.json').write_text(json.dumps(data,indent=2)+'\n')
print('Generated',len(fixtures),'numeric fixtures')
