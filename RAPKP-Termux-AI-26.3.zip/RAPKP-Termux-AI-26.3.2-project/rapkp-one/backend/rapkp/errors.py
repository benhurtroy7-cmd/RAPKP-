class CalculationError(Exception):
    """A safe, user-actionable calculation failure. Never substitute chart data."""

    def __init__(self, code: str, message: str, status: int = 422):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
