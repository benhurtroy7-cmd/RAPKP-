package com.rapkp.one;

import java.security.GeneralSecurityException;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Provider-neutral authenticated encryption; the Android plugin supplies a Keystore key. */
final class ConnectionCipher {
    static final class Envelope {
        final byte[] iv;
        final byte[] ciphertext;
        Envelope(byte[] iv, byte[] ciphertext) { this.iv=iv.clone(); this.ciphertext=ciphertext.clone(); }
    }
    static Envelope seal(SecretKey key, byte[] cleartext) throws GeneralSecurityException {
        if (cleartext==null || cleartext.length>16384) throw new IllegalArgumentException("Connection too large");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,key);
        byte[] encrypted=cipher.doFinal(cleartext);
        return new Envelope(cipher.getIV(),encrypted);
    }
    static byte[] open(SecretKey key, byte[] iv, byte[] ciphertext) throws GeneralSecurityException {
        if (iv==null || iv.length!=12 || ciphertext==null || ciphertext.length<16 || ciphertext.length>16400) throw new IllegalArgumentException("Invalid encrypted connection");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));
        return cipher.doFinal(ciphertext);
    }
}
