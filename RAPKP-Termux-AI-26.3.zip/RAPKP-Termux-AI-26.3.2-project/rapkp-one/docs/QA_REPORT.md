# RAPKP One 26.2 — upgrade QA report

**26.3.0-termux.1 · Recorded 2026-10-02T07:06:19.436229+00:00**

## Upgrade identity and provenance

This is a feature upgrade, not a repackaged RC2 binary. The preview package is **com.rapkp.one.preview**, launcher **RAPKP One 26.2**, version code **2603001** (previously 2601002). New native Java code supplies encrypted connection storage and Android document-picker JSON exports; new client code supplies input restoration, session-preserving navigation and build identity.

The APK is debug-signed for evaluation, and the release AAB is unsigned. They are compiled artifacts, not owner release-signed/store-approved products. The old signing key was not available; a separate preview ID avoids claiming a working in-place migration.

## Executed checks

| Evidence | Result | Scope |
|---|---:|---|
| Backend cases | 931 passed; 0 failed/skipped | Parametrised numerical, time, API/security, CLI, provider mocks and real local limiter cases |
| Backend statement coverage | 96.18% | Not branch coverage or proof of correctness |
| Browser cases | 52 passed | Chromium desktop/mobile viewports; includes new navigation/import/export/About checks |
| Native transport cases | 25 passed | Mocked Capacitor HTTP contract, consent and separate credentials |
| New client cases | 35 passed | Request/report validation; malformed/oversize/time/coordinate rejection; mocked device bridge |
| Java crypto cases | 6 passed | AES-GCM round trip, random IVs, tamper/wrong-key rejection and size/IV validation in a JVM |
| Android compilation | Passed | New APK/AAB and native plugin code compiled with JDK 21/SDK 36 |
| Android lint | 0 errors / 0 warnings | Previous build had 32 warnings; rules were not disabled to obtain this result |
| APK inspection | Passed | Package/version/launcher, signature, native-plugin DEX presence, disabled bridge logging/debugging |
| Source/assets match | Passed | Current compiled web assets compared byte-for-byte to APK assets |
| Known-advisory scans | Recorded Python/npm results contain 0 findings | Not a penetration test or complete native supply-chain audit |
| OpenAPI | Specification validation passed | Live account configuration/calls not performed |

The initial native lint process hit a constrained JVM metaspace limit. It was rerun with a larger metaspace cap and completed; the detector was not disabled. One new browser test initially compared `innerText` with `textContent`; its whitespace-sensitive assertion was corrected and the full suite rerun. The backend retains one upstream TestClient/httpx deprecation warning.

## Native privacy and usability changes

- Explicit opt-in encrypted connection record; Android Keystore-backed AES-GCM implementation. Tokens are loaded into app memory when restored; this is not protection against a compromised/rooted device or malicious code already in the app.
- Only connection fields are retained in that record. Birth data is not silently persisted.
- Forget deletes the saved profile/key; current session values remain until cleared/exit, as the UI states.
- JSON file export uses Android's system document picker. The destination is user-selected, and the exported file is plaintext personal data, not a token vault.
- Backup and transfer exclusions cover legacy and Android-12+ policies. Native bridge logging and WebView debugging are disabled.
- Input restoration accepts request JSON or inputs from schema-1.0 reports, never imported chart facts as a newly computed result. It does not trigger an API request until the user calculates.
- Workbench state survives view changes but not reload/exit unless explicitly exported. Native Back handling and an installed-version screen were added.

**Physical device testing was not executed.** Hardware Keystore behavior, system picker/lifecycle/keyboard/Back interaction, OEM backup behavior and native accessibility require device validation. The supplied instrumentation test source is not an executed test result. iOS source is generated, not compiled/signed/device-tested.

## Numerical engine

The engine/conventions are intentionally unchanged for reproducibility and rechecked against **95 independent fixtures / 190 mean–true chart evaluations**. Sampled maxima:

| Quantity | Maximum residual |
|---|---:|
| Classical planets | 3.485922 arcseconds |
| Placidus cusps | 3.274921 arcseconds |
| Mean node | 1.893196 arcseconds |
| True/osculating node | 36.592589 arcseconds |

These are finite reference comparisons with aligned conventions, not global error bounds or life-event prediction accuracy. Birth-time/model uncertainty and the larger true-node difference still matter at KP boundaries.

## Release decision and remaining gates

The upgraded web/API and compiled Android preview are ready for controlled technical evaluation. No store approval, physical device certification, live ChatGPT/Gemini/AstroSage confirmation, production cluster capacity, professor endorsement or empirical forecasting probability is claimed.

Historical v17–v25 releases and the complete 21-rule definitions remain unavailable. The four-check baseline remains uncalibrated and preserves NOT DETERMINED. Owner signing, public-user identity/tenant controls, privacy/licence/branding review and independent outcome validation remain separate requirements.

Current evidence is in qa/pytest-results.xml, qa/playwright-results.json, qa/native-transport-tests.xml, qa/upgrade-client-tests.xml and qa/android/26.2/. Version-labelled prior evidence remains under qa/history/. The source hashes are in qa/verification.json and package hashes in CHECKSUMS.sha256.
