"""Transparent baseline checks — NOT the absent 11+10 proprietary rules.

Domain house sets below are traceable to the supplied v26 PDF, pp. 1–2. Rule
weights are a new, disclosed product heuristic, not an empirical probability.
"""

from .kp import SIGN_LORDS

DOMAINS = {
    "career": {"label": "Career & work", "primary": 10, "supporting": [2, 6, 11]},
    "marriage": {"label": "Marriage", "primary": 7, "supporting": [2, 11]},
    "property": {"label": "Property", "primary": 4, "supporting": [11, 12]},
    "education": {"label": "Education", "primary": 4, "supporting": [6, 11]},
    "travel": {"label": "Foreign travel", "primary": 12, "supporting": [9, 3]},
    "business": {"label": "Business", "primary": 7, "supporting": [10, 11]},
    "wealth": {"label": "Wealth", "primary": 2, "supporting": [11]},
    "meeting": {"label": "Meeting", "primary": 11, "supporting": []},
    "remarriage": {"label": "Remarriage", "primary": 7, "supporting": [2]},
    "handover": {"label": "Property handover", "primary": 4, "supporting": [11]},
}

PENDING_RULES = [
    {"id": f"USER-{i:02d}", "group": "11 user rules", "status": "definition_not_supplied", "enabled": False}
    for i in range(1, 12)
] + [
    {
        "id": f"PROF-{i:02d}",
        "group": "10 attributed professor rules",
        "status": "definition_not_supplied",
        "enabled": False,
    }
    for i in range(1, 11)
]


def significators(chart: dict) -> dict:
    bodies = chart["bodies"]
    owners = {c["house"]: SIGN_LORDS[int(c["longitude"] // 30)] for c in chart["cusps"]}
    owns = lambda name: sorted(h for h, owner in owners.items() if owner == name)
    result = {}
    for name, p in bodies.items():
        star = bodies[p["star_lord"]]
        links = [
            {"tier": "A", "source": "star-lord occupation", "agent": p["star_lord"], "houses": [star["house"]]},
            {"tier": "B", "source": "planet occupation", "agent": name, "houses": [p["house"]]},
            {"tier": "C", "source": "star-lord ownership", "agent": p["star_lord"], "houses": owns(p["star_lord"])},
            {"tier": "D", "source": "planet ownership", "agent": name, "houses": owns(name)},
        ]
        if name in {"Rahu", "Ketu"}:
            sign_agent = bodies[p["sign_lord"]]
            links.append(
                {
                    "tier": "N",
                    "source": "node sign-lord agency (limited baseline)",
                    "agent": p["sign_lord"],
                    "houses": sorted(set([sign_agent["house"]] + owns(p["sign_lord"]))),
                }
            )
        result[name] = {"houses": sorted({h for link in links for h in link["houses"]}), "hierarchy": links}
    return result


def interlinks(chart: dict, sig: dict) -> list[dict]:
    return [
        {
            "house": c["house"],
            "star_lord": c["star_lord"],
            "sub_lord": c["sub_lord"],
            "linked_houses": sig[c["sub_lord"]]["houses"],
        }
        for c in chart["cusps"]
    ]


def assess(chart: dict, sig: dict, dasha: dict, domain: str, sensitive: bool) -> dict:
    definition = DOMAINS[domain]
    targets = [definition["primary"], *definition["supporting"]]
    cusp = chart["cusps"][definition["primary"] - 1]
    sources = [
        ("BASE-CUSP", "Primary cusp sub-lord", cusp["sub_lord"], 4),
        ("BASE-MD", "Mahadasha lord", dasha["mahadasha"]["lord"], 3),
        ("BASE-BHUKTI", "Bhukti lord", dasha["bhukti"]["lord"], 2),
        ("BASE-ANTARA", "Antara lord", dasha["antara"]["lord"], 1),
    ]
    checks = []
    for ident, label, lord, weight in sources:
        links = sig[lord]["houses"]
        matches = sorted(set(links) & set(targets))
        checks.append(
            {
                "id": ident,
                "label": label,
                "lord": lord,
                "weight": weight,
                "linked_houses": links,
                "matching_houses": matches,
                "matched": bool(matches),
                "contribution": weight if matches else 0,
            }
        )
    earned = sum(c["contribution"] for c in checks)
    return {
        "label": "Baseline rule support",
        "domain_label": definition["label"],
        "target_houses": targets,
        "score": earned,
        "maximum": 10,
        "support_percent": earned * 10,
        "score_meaning": "Weighted match count: cusp sub-lord 4, mahadasha 3, bhukti 2, antara 1. Any connection to a listed target house matches. No opposition rules are supplied; this metric can be strongly upward-biased.",
        "is_probability": False,
        "probability": None,
        "binary_answer": "NOT DETERMINED",
        "conclusion": "Input-sensitive" if sensitive else "Interpretation incomplete",
        "decision_status": "abstained",
        "checks": checks,
        "abstention_reasons": [
            "The full numbered 21-rule source pack was not supplied.",
            "No independently calibrated event-outcome model or probability calibration is available.",
        ]
        + (
            ["At least one sampled cusp or planetary sub-lord changes within the stated birth-time uncertainty."]
            if sensitive
            else []
        ),
        "disclaimer": "A high rule-support score is not a likelihood, a YES answer, or evidence that an event will occur.",
    }


def registry() -> dict:
    return {
        "source": "Supplied v26 PDF and operating prompt only",
        "ruleset_version": "baseline-1.0",
        "domain_source": "v26 PDF, pp. 1–2; job→career and foreign_travel→travel aliases",
        "implemented_baseline_checks": 4,
        "source_rules_expected": 21,
        "source_rules_defined": 10,
        "source_rules_calibrated": 0,
        "source_rule_slots_defined": 10,
        "source_rule_slots_expected": 21,
        "source_rule_slots_calibrated": 0,
        "supplied_outline_steps": 10,
        "supplied_outline_scope": (
            "A 10-step public structural outline (7+4+5 headings claiming 16 steps) was supplied on 2026-10-03 and is "
            "evaluated per report as source_rule_evaluation. It is outline methodology, not the 1,500+ numbered master "
            "rules, and it carries no numeric thresholds."
        ),
        "proxy_checks": ["PROF-06", "PROF-07", "PROF-10"],
        "pending_rules": PENDING_RULES,
        "sequence": [
            "Validate civil time and coordinates",
            "Calculate planets and Placidus cusps",
            "Derive star/sub/sub-sub lords",
            "Build A/B/C/D significator links",
            "Inspect cusp sub-lord links",
            "Compute corrected Vimshottari periods",
            "Show ruling planets and transit data",
            "Report uncertainty and abstain where evidence is insufficient",
        ],
        "limitations": [
            "Not an implementation of the missing 21 numbered rules",
            "No validated event-probability model",
            "No full node conjunction/aspect agency",
            "No forecast from horary-table numbers alone",
            "Civil-midnight convention for weekday lord, explicitly not sunrise-based",
        ],
    }
