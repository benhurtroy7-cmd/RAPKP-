#!/usr/bin/env python3
"""Recompute numerical residuals from the bundled independent numeric fixtures."""
import json
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
from rapkp.engine import AstroEngine, angular_distance  # noqa: E402  (import after sys.path setup)


def main():
    reference=json.loads((ROOT/'backend/tests/fixtures/astronomy-reference.json').read_text())
    samples={k:[] for k in ['planets_arcsec','mean_node_arcsec','true_node_arcsec','cusps_arcsec','ayanamsa_arcsec','speeds_deg_per_day']}
    engine=AstroEngine(ROOT/'data/de440s.bsp')
    try:
        for row in reference['fixtures']:
            mean=engine.calculate_at_ut1(row['jd_ut1'],row['latitude'],row['longitude'],'mean')
            true=engine.calculate_at_ut1(row['jd_ut1'],row['latitude'],row['longitude'],'true')
            for name in ['Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn']:
                samples['planets_arcsec'].append(angular_distance(mean['bodies'][name]['longitude'],row['bodies'][name]['longitude'])*3600)
                samples['speeds_deg_per_day'].append(abs(mean['bodies'][name]['speed']-row['bodies'][name]['speed']))
            for cusp,ref in zip(mean['cusps'],row['cusps'],strict=True):samples['cusps_arcsec'].append(angular_distance(cusp['longitude'],ref)*3600)
            samples['mean_node_arcsec'].append(angular_distance(mean['bodies']['Rahu']['longitude'],row['bodies']['MeanNode']['longitude'])*3600)
            samples['true_node_arcsec'].append(angular_distance(true['bodies']['Rahu']['longitude'],row['bodies']['TrueNode']['longitude'])*3600)
            samples['ayanamsa_arcsec'].append(abs(mean['ayanamsa']['mean_degrees']-row['ayanamsa'])*3600)
    finally:engine.close()
    metrics={}
    for name,values in samples.items():
        values=sorted(values);position=.95*(len(values)-1);lo=int(position);hi=min(lo+1,len(values)-1)
        metrics[name]={'n':len(values),'max':max(values),'mean':statistics.mean(values),'p95':values[lo]+(values[hi]-values[lo])*(position-lo)}
    result={'tested_at':datetime.now(timezone.utc).isoformat(),'fixtures':len(reference['fixtures']),'reference':reference['reference'],'comparison':'Shared numerical UT1 Julian day, sidereal Krishnamurti, Placidus; seven classical planets and explicit node models. Sampled residuals, NOT prediction accuracy or global error bounds. UTC/timezone handling is tested separately.','metrics':metrics}
    (ROOT/'qa/reference-residuals.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
