#!/usr/bin/env python3
"""Synthetic local benchmark. Not a production SLA or a multi-replica test."""
import copy
import json
import platform
import statistics
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
from fastapi.testclient import TestClient  # noqa: E402  (import after sys.path setup)
from rapkp.api import create_app  # noqa: E402  (import after sys.path setup)
from rapkp.config import Settings  # noqa: E402  (import after sys.path setup)


def metrics(samples):
    values=sorted(samples)
    return {'samples':len(values),'median_ms':round(statistics.median(values)*1000,3),'p95_ms':round(values[int(.95*(len(values)-1))]*1000,3),'max_ms':round(max(values)*1000,3)}


def main():
    request=json.loads((ROOT/'qa/sample-request.json').read_text())
    settings=Settings(environment='test',requests_per_minute=10000,max_concurrent=4)
    with TestClient(create_app(settings)) as client:
        cold=[]
        for i in range(40):
            payload=copy.deepcopy(request)
            payload['birth']['date']=f'{1960+i:04d}-{i%12+1:02d}-{i%27+1:02d}'
            start=perf_counter();response=client.post('/api/v1/readings',json=payload);cold.append(perf_counter()-start)
            if response.status_code!=200: raise RuntimeError(f'Cold request failed: {response.status_code}')
        response=client.post('/api/v1/readings',json=request)
        if response.status_code!=200: raise RuntimeError('Warm-up failed')
        warm=[]
        for _ in range(60):
            start=perf_counter();response=client.post('/api/v1/readings',json=request);warm.append(perf_counter()-start)
            if response.status_code!=200: raise RuntimeError('Warm request failed')
        def burst(_):
            start=perf_counter();r=client.post('/api/v1/readings',json=request)
            return r.status_code,perf_counter()-start
        start=perf_counter()
        with ThreadPoolExecutor(max_workers=12) as pool: results=list(pool.map(burst,range(120)))
        elapsed=perf_counter()-start
        statuses={str(code):sum(1 for c,_ in results if c==code) for code,_ in results}
        if any(c not in {200,429} for c,_ in results):raise RuntimeError(f'Unexpected burst response: {statuses}')
    report={'scope':'One local FastAPI TestClient process; synthetic charts; no real network/TLS, replicas, device, Gemini or ChatGPT latency. Burst uses repeated cached inputs.',
            'tested_at':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'platform':platform.platform(),
            'cold_distinct_births':metrics(cold),'warm_repeated_request':metrics(warm),
            'burst':{'requests':120,'client_threads':12,'server_compute_slots':4,'elapsed_seconds':round(elapsed,3),'statuses':statuses,'latency':metrics([s for _,s in results])},
            'note':'Caching changes performance substantially. Do not advertise these figures as production capacity.'}
    (ROOT/'qa/benchmark.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
