"""Evaluation of the 10 supplied structural KP steps (Prof. Krish Murali Eswar KP outline).

These are the publicly outlined steps supplied by the user on 2026-10-03. They are a
methodological OUTLINE, not the 1,500+ specific numbered rules in the professor's
master rule books, which were not supplied. No numeric thresholds, weights, or
calibration accompany them, so every rule below is evaluated as a structural check
with cited evidence. Nothing here produces a probability, a YES/NO, or a score that
could be read as a likelihood.

Where a supplied step names a technique the calculation core does not implement
(aspects), the rule is evaluated with a clearly disclosed proxy and labelled as such.
"""

from .kp import SIGN_LORDS

DUSTHANAS = (6, 8, 12)
# Disclosed proxies. These are product conventions, NOT the professor's doctrine.
CONJUNCTION_ORB = 10.0
OPPOSITION_WINDOW = (170.0, 190.0)
RULING_KEYS = (
    "ascendant_sign_lord",
    "ascendant_star_lord",
    "ascendant_sub_lord",
    "moon_sign_lord",
    "moon_star_lord",
    "day_lord",
)
BENEFICS = ("Jupiter", "Venus")
MALEFICS = ("Saturn", "Mars", "Rahu", "Ketu", "Sun")


def _angular_distance(a, b):
    return abs((a - b + 180) % 360 - 180)


def _motion(bodies, name):
    p = bodies.get(name)
    if not p:
        return None
    if p["retrograde"]:
        return "retrograde"
    if p.get("near_station"):
        return "near station (slow)"
    return "direct"


def _houses_of(sig, name):
    return sig.get(name, {}).get("houses", [])


def _rule(ident, group, title, supplied, status, evidence, note, proxy=False):
    return {
        "id": ident,
        "group": group,
        "title": title,
        "supplied_step": supplied,
        "status": status,
        "proxy_basis": proxy,
        "evidence": evidence,
        "note": note,
        "is_probability": False,
        "probability": None,
    }


def evaluate(chart, sig, interlinks, dasha, ruling, domain, transits=None, horary=None):
    """Return a per-rule structural evaluation plus an explicit gap accounting."""
    bodies = chart["bodies"]
    cusps = chart["cusps"]
    primary = domain["primary"]
    supporting = domain["supporting"]
    targets = [primary, *supporting]
    cusp = cusps[primary - 1]
    star_lord = cusp["star_lord"]
    sub_lord = cusp["sub_lord"]
    sub_sub_lord = cusp["sub_sub_lord"]
    star_houses = _houses_of(sig, star_lord)
    sub_houses = _houses_of(sig, sub_lord)
    md, bd, ad = dasha["mahadasha"]["lord"], dasha["bhukti"]["lord"], dasha["antara"]["lord"]
    rules = []

    # ---- Fundamental predictive steps (4 of the 7 claimed steps were supplied) ----
    if horary:
        setup = {
            "mode": "horary",
            "horary_number": horary.get("number"),
            "ascendant_longitude": round(cusps[0]["longitude"], 6),
            "note": "Chart raised from the horary number within the contracted 1–249 range.",
        }
    else:
        setup = {
            "mode": "natal",
            "birth_date": domain.get("_birth_date"),
            "ascendant_longitude": round(cusps[0]["longitude"], 6),
            "note": "Chart raised from the supplied birth details and analysis moment.",
        }
    rules.append(
        _rule(
            "PROF-01",
            "7 fundamental predictive steps",
            "Chart setup",
            "Generate a Krishnamurti Paddhati (KP) chart using a horary number (1 to 249) or accurate birth details.",
            "supported",
            setup,
            "Chart construction is a procedure, not a predictive condition: completing it neither supports nor contradicts an outcome.",
        )
    )

    rules.append(
        _rule(
            "PROF-02",
            "7 fundamental predictive steps",
            "Cuspal focus",
            "Identify the primary star lord and cuspal sublord for the house governing the query.",
            "supported",
            {
                "domain": domain["label"],
                "governing_house": primary,
                "cusp_longitude": round(cusp["longitude"], 6),
                "cusp_sign": cusp["sign"],
                "star_lord": star_lord,
                "sub_lord": sub_lord,
                "sub_sub_lord": sub_sub_lord,
                "supporting_houses": supporting,
            },
            "Identifies the significators the remaining steps inspect. It is an identification step, so it carries no outcome weight.",
        )
    )

    designated = [star_lord, sub_lord, sub_sub_lord, md, bd, ad]
    motions = {name: _motion(bodies, name) for name in designated}
    retro = [n for n, m in motions.items() if m == "retrograde"]
    rules.append(
        _rule(
            "PROF-03",
            "7 fundamental predictive steps",
            "Motion analysis",
            "Check whether the designated star lords and sublords are direct or retrograde.",
            "supported",
            {
                "designated_lords": designated,
                "motion": motions,
                "retrograde_lords": retro,
                "near_station_lords": [n for n, m in motions.items() if m and m.startswith("near station")],
                "speed_source": "Computed apparent speed sign from the selected ephemeris provider.",
            },
            "Reports the motion state of the designated lords. The supplied outline gives no rule for how retrograde motion changes an outcome, so none is applied.",
        )
    )

    favourable = sorted(set(star_houses) & set(targets))
    adverse = sorted(set(star_houses) & set(DUSTHANAS))
    sub_favourable = sorted(set(sub_houses) & set(targets))
    sub_adverse = sorted(set(sub_houses) & set(DUSTHANAS))
    rules.append(
        _rule(
            "PROF-04",
            "7 fundamental predictive steps",
            "House significations",
            "Map out all the individual houses signified by the star lord and sublord to weigh favorable versus unfavorable outcomes.",
            "supported",
            {
                "star_lord": star_lord,
                "star_lord_houses": star_houses,
                "star_lord_favourable_houses": favourable,
                "star_lord_dusthana_houses": adverse,
                "sub_lord": sub_lord,
                "sub_lord_houses": sub_houses,
                "sub_lord_favourable_houses": sub_favourable,
                "sub_lord_dusthana_houses": sub_adverse,
                "target_houses": targets,
            },
            "Lists the significations on both sides. 'Weighing' is left to the reader: no favourable/adverse weights were supplied, so no score is computed.",
        )
    )

    # ---- Advanced verification steps (3 of the 4 claimed steps were supplied) ----
    links = sorted(set(sub_houses) & set(DUSTHANAS))
    star_links = sorted(set(star_houses) & set(DUSTHANAS))
    rules.append(
        _rule(
            "PROF-05",
            "4 advanced verification steps",
            "Dusthana linkages",
            "Check if the cuspal sublord or its star lord establishes a connection to difficult houses (6, 8, or 12).",
            "supported" if (links or star_links) else "contradicted",
            {
                "sub_lord": sub_lord,
                "sub_lord_dusthana_houses": links,
                "star_lord": star_lord,
                "star_lord_dusthana_houses": star_links,
                "dusthana_houses": list(DUSTHANAS),
                "link_found": bool(links or star_links),
            },
            "Reports whether a 6/8/12 link exists through the significator hierarchy. The outline states no strength, cancellation or outcome rule, so no verdict follows from the link.",
        )
    )

    key = [star_lord, sub_lord, sub_sub_lord, md, bd, ad]
    conjunctions, oppositions = [], []
    for name, p in bodies.items():
        if name in key or p["house"] == cusp["house"]:
            for target in {star_lord, sub_lord}:
                t = bodies.get(target)
                if not t or target == name:
                    continue
                separation = _angular_distance(p["longitude"], t["longitude"])
                if separation <= CONJUNCTION_ORB:
                    conjunctions.append(
                        {"planet": name, "with": target, "separation_arcsec": round(separation * 3600, 1),
                         "classification": "benefic" if name in BENEFICS else "malefic" if name in MALEFICS else "other"}
                    )
                if OPPOSITION_WINDOW[0] <= separation <= OPPOSITION_WINDOW[1]:
                    oppositions.append(
                        {"planet": name, "opposing": target, "separation_arcsec": round(separation * 3600, 1),
                         "classification": "benefic" if name in BENEFICS else "malefic" if name in MALEFICS else "other"}
                    )
    rules.append(
        _rule(
            "PROF-06",
            "4 advanced verification steps",
            "Planetary aspects",
            "Evaluate whether any malefic or benefic planet is aspecting or opposing the key significators.",
            "supported" if (conjunctions or oppositions) else "contradicted",
            {
                "key_significators": key,
                "conjunctions_within_10_degrees": conjunctions,
                "oppositions_within_170_190_degrees": oppositions,
                "benefics": list(BENEFICS),
                "malefics": list(MALEFICS),
            },
            "PROXY BASIS: Krishnamurti Paddhati works through significators, not aspect doctrine, and no aspect definition was supplied. Conjunction/opposition here is a disclosed longitude proxy (±10° conjunction, 170–190° opposition), not the professor's aspect rule.",
            proxy=True,
        )
    )

    occupying = [n for n, p in bodies.items() if p["house"] == primary]
    with_sub = [n for n in occupying if _angular_distance(bodies[n]["longitude"], bodies[sub_lord]["longitude"]) <= CONJUNCTION_ORB]
    rules.append(
        _rule(
            "PROF-07",
            "4 advanced verification steps",
            "Conjunction influences",
            "Assess planet conjunctions to see if they alter the baseline outcome of the house in question.",
            "supported" if with_sub else "contradicted",
            {
                "governing_house": primary,
                "planets_in_house": occupying,
                "conjunct_with_sub_lord": with_sub,
                "sub_lord": sub_lord,
                "baseline_reference": "assessment.checks in this report (disclosed product heuristic, not a supplied rule)",
            },
            "PROXY BASIS: no rule was supplied for how a conjunction changes a house outcome, and the product's own baseline is a disclosed heuristic rather than a supplied scoring system. This lists the conjunctions present and leaves any 'alteration' to the reader.",
            proxy=True,
        )
    )

    # ---- Event-timing steps (3 of the 5 claimed steps were supplied) ----
    period_lords = {"mahadasha": md, "bhukti": bd, "antara": ad}
    period_links = {
        level: {
            "lord": lord,
            "houses": _houses_of(sig, lord),
            "favourable_houses": sorted(set(_houses_of(sig, lord)) & set(targets)),
            "dusthana_houses": sorted(set(_houses_of(sig, lord)) & set(DUSTHANAS)),
        }
        for level, lord in period_lords.items()
    }
    rules.append(
        _rule(
            "PROF-08",
            "5 event-timing steps",
            "Period mapping",
            "Align the question with the currently running Dasa, Bukthi, and Antara periods.",
            "supported",
            {
                "running_periods": {k: dasha[k] for k in ("mahadasha", "bhukti", "antara")},
                "period_lord_links": period_links,
                "system": dasha["system"],
                "year_days": dasha["year_days"],
            },
            "Aligns the running periods with the target houses. Period dates are calendar intervals, not guaranteed event dates.",
        )
    )

    rules.append(
        _rule(
            "PROF-09",
            "5 event-timing steps",
            "Ruling planets",
            "Extract the active Ruling Planets—including the Lagna sign lord, Lagna star lord, and Moon star lord—at the moment of analysis.",
            "supported",
            {
                "ruling_planets": {k: ruling[k] for k in RULING_KEYS if isinstance(ruling.get(k), str)},
                "at_utc": ruling.get("at_utc"),
                "day_convention": ruling.get("day_convention"),
            },
            "Reports the ruling planets at the analysis moment. The weekday lord uses a civil-midnight convention, explicitly not a sunrise-based one.",
        )
    )

    sun = transits["bodies"]["Sun"] if transits else None
    moon = transits["bodies"]["Moon"] if transits else None
    if sun and moon:
        transit_evidence = {
            "sun": {"house": sun["house"], "star_lord": sun["star_lord"], "sign": sun["sign"]},
            "moon": {"house": moon["house"], "star_lord": moon["star_lord"], "sign": moon["sign"]},
            "moon_star_lord_is_ruling_planet": moon["star_lord"] in {ruling.get(k) for k in RULING_KEYS},
            "ruling_planet_set": sorted({ruling[k] for k in RULING_KEYS if isinstance(ruling.get(k), str)}),
        }
        status = "supported" if transit_evidence["moon_star_lord_is_ruling_planet"] else "contradicted"
        note = (
            "PROXY BASIS: 'support the predicted window' needs a defined window and a support criterion, neither of which was supplied. "
            "This reports the transiting Sun/Moon houses and star lords, and whether the transiting Moon's star lord is among the ruling planets."
        )
    else:
        transit_evidence = {"available": False, "reason": "Transits were not requested for this reading."}
        status = "not_evaluable"
        note = "Transit positions were not calculated for this reading, so the step cannot be evaluated."
    rules.append(
        _rule(
            "PROF-10",
            "5 event-timing steps",
            "Transit alignment",
            "Verify that the current transit positions of the Sun and Moon support the predicted window.",
            status,
            transit_evidence,
            note,
            proxy=True,
        )
    )

    counts = {s: sum(1 for r in rules if r["status"] == s) for s in ("supported", "contradicted", "not_evaluable")}
    proxies = [r["id"] for r in rules if r["proxy_basis"]]
    return {
        "label": "Supplied structural steps (10 of 21 rule slots)",
        "source": "Public structural outline attributed to Prof. Krish Murali Eswar KP, supplied by the user on 2026-10-03",
        "source_scope": "Outline methodology only. The 1,500+ specific numbered rules in the master rule books were not supplied.",
        "domain": domain["label"],
        "target_houses": targets,
        "rules": rules,
        "counts": counts,
        "proxy_rules": proxies,
        "is_probability": False,
        "probability": None,
        "binary_answer": "NOT DETERMINED",
        "aggregate_meaning": (
            f"{counts['supported']} steps reported supporting evidence, {counts['contradicted']} reported none, "
            f"{counts['not_evaluable']} could not be evaluated. This is a count of structural checks, not a score: "
            "no weights, thresholds or calibration were supplied with these steps."
        ),
        "abstention_reasons": [
            "The supplied text is an outline; the numbered professor rules and all 11 user rules were not provided.",
            "No numeric thresholds or favourable/adverse weights accompany the supplied steps.",
            f"{len(proxies)} step(s) use a disclosed product proxy ({', '.join(proxies)}) because the named technique was not defined in the supplied text.",
        ],
        "disclaimer": "Structural agreement with an outline is not evidence that an event will occur, and a contradiction is not evidence that it will not.",
    }


def registry():
    """Gap accounting for the 21 rule slots, now that 10 structural steps exist."""
    supplied = [
        ("PROF-01", "7 fundamental predictive steps", "Chart setup", True),
        ("PROF-02", "7 fundamental predictive steps", "Cuspal focus", True),
        ("PROF-03", "7 fundamental predictive steps", "Motion analysis", True),
        ("PROF-04", "7 fundamental predictive steps", "House significations", True),
        ("PROF-05", "4 advanced verification steps", "Dusthana linkages", True),
        ("PROF-06", "4 advanced verification steps", "Planetary aspects", True),
        ("PROF-07", "4 advanced verification steps", "Conjunction influences", True),
        ("PROF-08", "5 event-timing steps", "Period mapping", True),
        ("PROF-09", "5 event-timing steps", "Ruling planets", True),
        ("PROF-10", "5 event-timing steps", "Transit alignment", True),
    ]
    pending = []
    for ident, group, title, defined in supplied:
        pending.append(
            {
                "id": ident,
                "group": group,
                "title": title,
                "status": "outline_implemented" if defined else "definition_not_supplied",
                "enabled": True,
                "scope": "structural check with cited evidence; no numeric outcome rule",
            }
        )
    # The claimed 7+4+5 = 16 professor steps versus the 10 supplied bullets.
    pending += [
        {
            "id": f"PROF-{11 + i:02d}",
            "group": group,
            "title": f"Unnumbered step {i} of the {total} claimed in this group",
            "status": "definition_not_supplied",
            "enabled": False,
            "scope": "The supplied text names this group but lists fewer steps than it claims; no definition was provided.",
        }
        for group, total, extra in (
            ("7 fundamental predictive steps", 7, 3),
            ("4 advanced verification steps", 4, 1),
            ("5 event-timing steps", 5, 2),
        )
        for i in range(1, extra + 1)
    ]
    pending += [
        {"id": f"USER-{i:02d}", "group": "11 user rules", "title": "User rule", "status": "definition_not_supplied", "enabled": False,
         "scope": "No user rule text was supplied."}
        for i in range(1, 12)
    ]
    return {
        "supplied_source": "Public structural outline attributed to Prof. Krish Murali Eswar KP (user-supplied 2026-10-03)",
        "claimed_professor_steps": 16,
        "supplied_professor_steps": 10,
        "missing_professor_steps": 6,
        "user_rules_supplied": 0,
        "user_rules_expected": 11,
        "rule_slots_defined": 10,
        "rule_slots_expected": 21,
        "rule_slots_calibrated": 0,
        "additional_claimed_steps_without_definition": 6,
        "pending_entries": 27,
        "implemented_source_checks": 10,
        "proxy_checks": ["PROF-06", "PROF-07", "PROF-10"],
        "pending_rules": pending,
        "count_discrepancy_note": (
            "The supplied headings claim 7 fundamental, 4 advanced and 5 event-timing steps (16 total) but list "
            "4, 3 and 3 respectively (10 total). The 10 listed steps are implemented; the 6 unlisted steps are "
            "recorded as undefined rather than invented."
        ),
        "limitations": [
            "Outline methodology only; the 1,500+ specific numbered master rules were not supplied",
            "No numeric thresholds, weights or calibration accompany the supplied steps",
            "Aspect and 'altered baseline' steps use disclosed longitude proxies, not the professor's doctrine",
            "No outcome probability, YES/NO or accuracy figure is derived from these checks",
        ],
    }


__all__ = ["evaluate", "registry", "DUSTHANAS", "SIGN_LORDS"]
