package com.rapkp.one;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.junit.Test;
public class ConnectionCipherTest {
    private SecretKey key() throws Exception {KeyGenerator g=KeyGenerator.getInstance("AES");g.init(256);return g.generateKey();}
    @Test public void roundTrip() throws Exception {SecretKey k=key();byte[] text="{\"primaryToken\":\"test-only-தமிழ்\"}".getBytes(StandardCharsets.UTF_8);ConnectionCipher.Envelope e=ConnectionCipher.seal(k,text);assertArrayEquals(text,ConnectionCipher.open(k,e.iv,e.ciphertext));}
    @Test public void randomIvEachTime() throws Exception {SecretKey k=key();byte[] b="same input".getBytes(StandardCharsets.UTF_8);assertFalse(java.util.Arrays.equals(ConnectionCipher.seal(k,b).iv,ConnectionCipher.seal(k,b).iv));}
    @Test public void tamperingRejected() throws Exception {SecretKey k=key();ConnectionCipher.Envelope e=ConnectionCipher.seal(k,new byte[]{1,2,3});e.ciphertext[0]^=1;assertThrows(java.security.GeneralSecurityException.class,()->ConnectionCipher.open(k,e.iv,e.ciphertext));}
    @Test public void wrongKeyRejected() throws Exception {SecretKey k=key();ConnectionCipher.Envelope e=ConnectionCipher.seal(k,new byte[]{1,2,3});SecretKey other=key();assertThrows(java.security.GeneralSecurityException.class,()->ConnectionCipher.open(other,e.iv,e.ciphertext));}
    @Test public void badIvRejected() throws Exception {SecretKey k=key();assertThrows(IllegalArgumentException.class,()->ConnectionCipher.open(k,new byte[3],new byte[16]));}
    @Test public void largeDataRejected() throws Exception {SecretKey k=key();assertThrows(IllegalArgumentException.class,()->ConnectionCipher.seal(k,new byte[16385]));}
}
