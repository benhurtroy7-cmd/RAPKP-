# RAPKP v29 BOT Commercial Suite

BOT = Build, Operate, Transfer.

This package is designed for commercial handover to clients who want an AI/KP astrology prediction product that can start on free infrastructure and scale as per their business needs.

## Included

- Android customer APK
- Cloud backend package
- Render free deployment path
- Docker deployment path
- Scalability guide
- BOT handover checklist
- Environment variable template
- PostgreSQL schema for scalable clients
- Commercial disclaimer and privacy template
- Admin/operator runbook

## Commercial positioning

Product category:

AI KP Astrology Prediction Engine + Android App + Cloud API

Use cases:

- Astrology consultants
- Matrimony timing services
- Kundli/chat prediction apps
- White-label astrology SaaS
- PDF chart/report generation
- Rule/correction learning engine

## Recommended deployment modes

### Demo / MVP

- Render Free
- SQLite
- APK direct install
- Cloud-first with demo fallback

### Starter Customer

- Render/Railway paid basic
- SQLite or free Postgres
- White-label app branding

### Scalable Customer

- Docker backend
- PostgreSQL
- Object storage for PDFs
- Multiple backend replicas
- Admin dashboard / logs

## Transfer model

At transfer, give the client:

- APK
- backend source
- GitHub repository
- Render/Railway/VPS deployment instructions
- environment variables
- database schema
- admin token
- support/runbook
