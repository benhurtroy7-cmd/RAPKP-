#!/usr/bin/env python3
"""Bounded synthetic real-HTTP verification on local staging, not a capacity certificate."""
import argparse
import asyncio
import copy
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from urllib.parse import urlparse

import httpx

ROOT = Path(__file__).resolve().parents[1]

async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', default='http://127.0.0.1:8001')
    parser.add_argument('--outage', action='store_true')
    args = parser.parse_args()
    if urlparse(args.base).hostname not in {'127.0.0.1', 'localhost'}:
        parser.error('This bounded QA tool accepts local staging only, not arbitrary production hosts')
    key = os.environ.get('RAPKP_API_KEY', '')
    if not key: parser.error('Set the private staging RAPKP_API_KEY in your environment')
    request = json.loads((ROOT/'qa/sample-request.json').read_text())
    headers = {'Authorization': f'Bearer {key}'}
    path = ROOT/'qa/http-two-worker-check.json'
    async with httpx.AsyncClient(base_url=args.base, timeout=60, limits=httpx.Limits(max_connections=16, max_keepalive_connections=0)) as c:
        if args.outage:
            ready = await c.get('/health/ready')
            reading = await c.post('/api/v1/readings', headers=headers, json=request)
            assert ready.status_code == reading.status_code == 503
            assert 'chart' not in reading.json()
            result = json.loads(path.read_text())
            result['limiter_outage'] = {'readiness_status': ready.status_code, 'reading_status': reading.status_code, 'placeholder_chart_returned': False}
            path.write_text(json.dumps(result, indent=2)+'\n')
            print('Shared-limiter outage: HTTP 503; no substitute chart.'); return
        assert (await c.get('/health/ready')).status_code == 200
        assert (await c.get('/api/v1/status')).json()['rate_limit_scope'] == 'shared'
        assert (await c.post('/api/v1/readings', json=request)).status_code == 401
        reference = await c.post('/api/v1/readings', headers=headers, json=request)
        assert reference.status_code == 200
        rid = reference.json()['report_id']
        async def batch(payloads, concurrency, strict):
            gate = asyncio.Semaphore(concurrency)
            async def send(p):
                async with gate:
                    r = await c.post('/api/v1/readings', headers=headers, json=p)
                    assert r.status_code in ({200} if strict else {200,429})
                    if r.status_code == 200:
                        j = r.json()
                        assert len(j['chart']['bodies']) == 9 and len(j['chart']['cusps']) == 12
                        assert j['assessment']['probability'] is None
                        assert j['assessment']['binary_answer'] == 'NOT DETERMINED'
                        if p == request: assert j['report_id'] == rid
                        assert key not in r.text
                    return r.status_code
            start = perf_counter()
            responses = await asyncio.gather(*(send(p) for p in payloads))
            return {'requests':len(responses), 'concurrency':concurrency, 'statuses':dict(Counter(map(str,responses))), 'elapsed_seconds':round(perf_counter()-start,3)}
        distinct=[]
        for i in range(64):
            p=copy.deepcopy(request);p['birth']['date']=f'{1950+i//12:04d}-{i%12+1:02d}-15';distinct.append(p)
        cold=await batch(distinct,4,True)
        warm=await batch([request]*120,4,True)
        burst=await batch([request]*80,16,False)
        result={'checked_at':datetime.now(timezone.utc).isoformat(),'transport':'real HTTP over loopback','workers':2,'shared_limiter':'Valkey 8.1.1','unauthenticated_status':401,'distinct_inputs':cold,'repeated_inputs':warm,'burst':burst,'status':'passed','scope':'One local host, two started Uvicorn workers, synthetic inputs. No TLS, remote load balancer, Docker/Kubernetes rollout, physical phone or provider call. Not a production SLA or empirical forecast test.'}
        path.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({k:result[k] for k in ['status','distinct_inputs','repeated_inputs','burst']},indent=2))

if __name__=='__main__': asyncio.run(main())
