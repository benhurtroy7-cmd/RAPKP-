# RAPKP One — one consolidated product

**Version 26.1.0-rc.2 · 30 September 2026 · Software regression rerun completed**

One calculation/API backend and one shared interface, packaged with web assets, Android binaries, iOS sources, deployment scripts, AI instructions and quality evidence. This is a tested technical release for controlled evaluation—not a certified predictor or an approved public-commercial launch.

## Start with the environment you want

| Environment | What to use | Actual readiness |
|---|---|---|
| Android | `native-artifacts/android/RAPKP-One-26.1.0-rc.2-evaluation.apk` | Compiled, debug-signed, signature checked. No physical-device test. |
| Android store preparation | `native-artifacts/android/RAPKP-One-26.1.0-rc.2-unsigned.aab` | Release bundle compiled; **unsigned**. Owner signing and store/device review required. |
| iOS | `frontend/ios/` | Generated/synchronised source. Needs macOS/Xcode, signing and device tests. |
| Computer / local web | `scripts/install.sh`, `scripts/run-local.sh` | Fresh Linux install and CLI reproduction checked; prebuilt UI supplied. |
| Termux | `scripts/install-termux.sh`, `scripts/run-termux.sh` | Same Python core; installer not physically tested on Android. |
| Cloud | `Dockerfile`, `compose.yaml`, `deployment/` | Protected API and two-worker local HTTP check; deployment templates are not a deployed production cluster. |
| ChatGPT | `integrations/chatgpt/` | Action schema and instructions; needs your HTTPS server and builder authentication. |
| Gemini Gem | `integrations/gemini/GEM_INSTRUCTIONS.md` | Upload/paste a calculated report. A static prompt does not create arbitrary API access. |
| Gemini API | `integrations/gemini/bridge.py` | Explicit-consent bridge, mock-tested. Needs your model/key and live-provider validation. |

### Run on a computer

```bash
cd rapkp-one
bash scripts/install.sh
bash scripts/run-local.sh
```

Open **http://127.0.0.1:8000** on that device and choose **Try a sample**. Python 3.11+ is required; tests used 3.13.14/Linux. Node is not needed to run the supplied prebuilt UI. Initial package installation needs network access. The bundled, checksum-verified DE440s kernel allows core calculation without an external AI/cloud service after setup.

### Android and Termux

Use your normal developer/test installation workflow for the evaluation APK. Do not bypass device security warnings. Android 7/API 24 or newer is the declared minimum; target API is 36. In the app, configure your own HTTPS API, or choose **Use Termux on this phone** after starting:

```bash
cd ~/rapkp-one
bash scripts/install-termux.sh
bash scripts/run-termux.sh
```

The native app does not embed Python. The Termux option uses same-phone loopback; a cloud service's localhost is not your phone. Credentials remain in memory and must be entered again after reload. The unsigned AAB is not directly installable and is not an already-approved store release.

### Cloud

Copy `.env.example` to `.env`, generate a random token (`python3 -c 'import secrets; print(secrets.token_urlsafe(32))'`), configure actual origins/domain, then build with `docker compose up --build -d`. Review the TLS profile before public exposure. The template binds the host API to loopback by default and uses a private shared Valkey limiter.

A private service token is not public tenant/user identity management. Public SaaS needs OAuth/OIDC, isolation, key lifecycle, abuse controls, privacy/consent and operational validation. Never embed a master token in an app or prompt.

### AI use

Read **RAPKP_ONE_MASTER_INSTRUCTIONS.md** for a unified starting prompt. Then apply the platform-specific files: configure a real Custom GPT Action, or explicitly upload/paste a RAPKP report into a consumer Gem. No live GPT/Gem/Gemini/AstroSage account connection is claimed.

## What the product actually calculates

KP sidereal positions, real Placidus cusps, star/sub/sub-sub lords, disclosed significator/cuspal links, corrected Dasha–Bhukti–Antara, ruling-planet context, a three-point birth-time sensitivity check and a 249-segment horary lookup. Dates are restricted to 1900–2099 UTC and Placidus latitude to strictly inside ±66°. The horary table is not a complete horary judgment.

## What remains unresolved

Only the v26 PDF and operating note were supplied. Separate v17–v25 releases and the full numbered 11 user + 10 professor rules were unavailable. All 21 missing-rule slots stay disabled; they are not invented.

The four-check support index is not a probability. A high index is not a guaranteed YES. Binary judgment remains **NOT DETERMINED**. Personal-event prediction accuracy, an 81.2% score, named-professor endorsement and external confirmation have not been established.

Android compilation is verified, but lint has 32 warnings and device/store testing remains open. iOS, physical Termux operation, live AI accounts, AstroSage, production cloud capacity and commercial/privacy/licence clearance require the corresponding environments, credentials and owner decisions.

## Privacy and licensing

No persistent report database. The backend has a bounded in-memory computed-chart cache; browser fields/tokens stay in memory. Inputs go to the API you configure. Export/clipboard/share/AI handoff may include personal data. Static-only service-worker caching does not make remote calculations available offline. No automatic external model call or Arena bug upload occurs.

Keep `licenses/`, `LICENSE` and `THIRD-PARTY-NOTICES.md` with distributions. New source is MIT; third-party code/data/brands retain their own terms. Native compiled dependencies and store/provider conditions still need release review.

**Evidence:** `docs/QA_REPORT.pdf`, `qa/verification.json` and the raw test outputs. `qa/history/rc1/` is historical evidence, not the current run. `CHECKSUMS.sha256` verifies packaged contents. This refreshed package supersedes the earlier RC2 archive that had an incomplete regression rerun.
