#!/usr/bin/env python3
"""Regenerate independent full/API-Action schemas without mutating the cached app spec."""
import copy
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
from rapkp.api import create_app  # noqa: E402  (import after sys.path setup)
from rapkp.config import Settings  # noqa: E402  (import after sys.path setup)


def main():
    full=copy.deepcopy(create_app(Settings(environment='test')).openapi())
    action=copy.deepcopy(full)
    allowed={'/api/v1/readings','/api/v1/status','/api/v1/horary/{number}','/api/v1/rules'}
    action['paths']={k:v for k,v in action['paths'].items() if k in allowed}
    action['info']['description']='Grounded RAPKP calculation API. Requires confirmed structured inputs and explicit consent before personal data is sent. Not a calibrated event predictor. Missing 21-rule definitions remain disabled.'
    action['servers']=[{'url':'https://api.your-domain.example','description':'Replace with your actual protected HTTPS deployment'}]
    action['components']['securitySchemes']={'BearerAuth':{'type':'http','scheme':'bearer'}}
    for url in ['/api/v1/readings','/api/v1/horary/{number}']:
        for op in action['paths'][url].values():
            op['security']=[{'BearerAuth':[]}]
            op['parameters']=[p for p in op.get('parameters',[]) if p.get('name','').lower()!='authorization']
            if not op['parameters']:op.pop('parameters')
            op['x-openai-isConsequential']=False
    for item in action['paths'].values():
        for op in item.values():
            response=op.get('responses',{}).get('200',{}).get('content',{}).get('application/json',{})
            if response and not response.get('schema'): response['schema']={'type':'object','additionalProperties':True}
    (ROOT/'integrations/chatgpt/openapi.json').write_text(json.dumps(action,indent=2)+'\n')
    (ROOT/'integrations/openapi-full.json').write_text(json.dumps(full,indent=2)+'\n')
    print(f'Exported {len(full["paths"])} full schema paths and {len(action["paths"])} Action paths independently.')


if __name__=='__main__':main()
