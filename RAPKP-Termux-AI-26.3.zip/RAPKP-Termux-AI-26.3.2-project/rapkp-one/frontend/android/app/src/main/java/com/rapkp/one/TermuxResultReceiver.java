package com.rapkp.one;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import org.json.JSONObject;
/** Explicit non-exported receiver; never logs command output, stdin, tokens or model keys. */
public class TermuxResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if(intent==null)return;int id=intent.getIntExtra("requestId",-1);PluginCall call=TermuxBridgePlugin.PENDING.remove(id);if(call==null)return;
        Bundle r=intent.getBundleExtra("result");
        if(r==null){call.reject("Termux returned no setup result. Check automation permissions.");return;}
        if(r.getInt("exitCode",-1)!=0 || r.getInt("err",-1)!=-1){call.reject("Termux setup failed. Verify Python, RUN_COMMAND permission and allow-external-apps=true. Open Termux for local diagnostics.");return;}
        try{
            String out=r.getString("stdout","").trim();if(out.length()>4000)throw new IllegalStateException();JSONObject j=new JSONObject(out);
            if(!j.optBoolean("ok")){call.reject("Connector installation was not completed. Check the existing setup and retry.");return;}
            context.getSharedPreferences("rapkp.termux.pair",0).edit().putBoolean("connectorInstalled",true).apply();
            JSObject result=new JSObject();result.put("ok",true);result.put("version",j.optString("version"));result.put("port",j.optInt("port",8765));result.put("bootHook",j.optBoolean("boot_hook"));call.resolve(result);
        }catch(Exception ignored){call.reject("The Termux setup reply was not valid. No connection was assumed.");}
    }
}
