package com.rapkp.one;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(RapkpDevicePlugin.class);
        registerPlugin(TermuxBridgePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
