import copy
import json

import pytest
from fastapi.testclient import TestClient
from rapkp.api import create_app
from rapkp.config import ROOT, Settings
from rapkp.engine import AstroEngine


@pytest.fixture(scope="session")
def engine():
    return AstroEngine(ROOT / "data/de440s.bsp")


@pytest.fixture
def payload():
    return copy.deepcopy(json.loads((ROOT / "qa/sample-request.json").read_text()))


@pytest.fixture
def client():
    with TestClient(create_app(Settings(environment="test", requests_per_minute=10000))) as c:
        yield c
