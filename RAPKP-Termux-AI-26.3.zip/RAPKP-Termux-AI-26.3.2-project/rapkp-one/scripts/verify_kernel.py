#!/usr/bin/env python3
"""Verify bundled data, or explicitly recover it with --download. No import-time fetch."""
import argparse
import hashlib
import json
import tempfile
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--download',action='store_true',help='Explicitly fetch missing/corrupt data from the recorded NASA/JPL URL')
    args=parser.parse_args()
    manifest=json.loads((ROOT/'data/manifest.json').read_text())
    path=ROOT/'data'/manifest['file']
    def valid(p):
        if not p.is_file(): return False
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
        return h.hexdigest()==manifest['sha256']
    if valid(path):
        print('DE440s kernel checksum verified. No network access used.');return
    if not args.download: parser.exit(1,'Kernel missing or corrupt. Re-run with --download to explicitly recover the pinned file.\n')
    path.parent.mkdir(exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent,suffix='.partial',delete=False) as f:
        temporary=Path(f.name)
        try:
            with urllib.request.urlopen(manifest['source'],timeout=90) as response:
                total=0
                while block:=response.read(1024*1024):
                    total+=len(block)
                    if total>manifest['bytes']: raise ValueError('Downloaded file exceeds recorded size')
                    f.write(block)
            f.flush()
            if not valid(temporary): raise ValueError('Downloaded checksum did not match; original file preserved')
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)
    print('Downloaded and verified the pinned NASA/JPL kernel.')


if __name__=='__main__': main()
