// RETIRED SUITE: targets the removed cloud/HTTPS native transport (primary + fallback
// credentials, https:// endpoints). The Termux-first build allows only its paired loopback
// connector on Android, so these cases can no longer pass. The still-valid endpoint and
// browser-transport cases were ported to tests/termux-native.cjs. Do not re-enable as-is.
// Node-only bridge mocks: tests the JS/native transport contract, NOT a device.
const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const source = fs.readFileSync(path.resolve(__dirname, '../src/api.ts'), 'utf8');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const report = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../qa/sample-report.json'), 'utf8'));
const payload = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../qa/sample-request.json'), 'utf8'));
const connection = { primary: 'https://primary.example', primaryToken: 'primary-only-test-token', fallback: 'https://fallback.example', fallbackToken: 'fallback-only-test-token', allowFallback: false };
function client(platform, nativeRequest, browserFetch) {
  const exports = {};
  const core = { Capacitor: { isNativePlatform: () => platform !== 'web', getPlatform: () => platform }, CapacitorHttp: { request: nativeRequest || (() => { throw new Error('No native request expected'); }) } };
  vm.runInNewContext(compiled, { exports, require: name => { if (name !== '@capacitor/core') throw new Error('Unexpected import'); return core; }, URL, AbortSignal, Error, fetch: browserFetch || (() => { throw new Error('No browser fetch expected'); }) }, { filename: 'compiled-api-under-test.cjs' });
  return exports;
}
test('Android permits only explicit same-device HTTP loopback', () => {
  const c = client('android');
  assert.equal(c.validateEndpoint('http://127.0.0.1:8000/'), 'http://127.0.0.1:8000');
  assert.equal(c.validateEndpoint('http://localhost:8000'), 'http://localhost:8000');
  assert.throws(() => c.validateEndpoint('http://remote.example'), /HTTPS/);
});
for (const platform of ['ios', 'web']) test(`${platform} rejects cleartext loopback`, () => {
  assert.throws(() => client(platform).validateEndpoint('http://127.0.0.1:8000'), /HTTPS/);
});
test('endpoint rejects credential/query/fragment injection', () => {
  const c = client('android');
  for (const url of ['https://u:p@api.example','https://api.example?q=secret','https://api.example#token','javascript:alert(1)']) assert.throws(() => c.validateEndpoint(url));
});
test('native cannot silently use a same-origin sandbox URL', async () => {
  let calls=0;const c=client('android',()=>{ calls++; });
  await assert.rejects(c.api({...connection,primary:''},'/api/v1/status'),/Set an HTTPS backend/);
  assert.equal(calls,0);
});
test('native POST preserves frozen inputs, uses native JSON and disables redirects', async () => {
  let sent;
  const c=client('android',async options=>{sent=options;return {status:200,data:report};});
  const r=await c.api(connection,'/api/v1/readings',payload);
  assert.equal(r.route,'primary');assert.equal(r.data.report_id,report.report_id);
  assert.equal(sent.url,'https://primary.example/api/v1/readings');assert.equal(sent.method,'POST');
  assert.equal(sent.headers.Authorization,'Bearer primary-only-test-token');assert.equal(sent.headers['Content-Type'],'application/json');
  assert.equal(sent.data,payload);assert.equal(sent.responseType,'json');assert.equal(sent.disableRedirects,true);
});
test('native GET never injects a request body', async () => {
  let sent;const c=client('android',async x=>{sent=x;return {status:200,data:{engine_ready:true,version:'test'}};});
  await c.api(connection,'/api/v1/status');assert.equal(sent.method,'GET');assert.equal(sent.data,undefined);assert.equal(sent.headers['Content-Type'],undefined);
});
test('native transport fallback uses only its separate credential', async () => {
  const calls=[];const c=client('android',async x=>{calls.push(x);if(x.url.startsWith(connection.primary))throw new Error('transport unavailable');return {status:200,data:report};});
  const r=await c.api({...connection,allowFallback:true},'/api/v1/readings',payload);
  assert.equal(r.route,'fallback');assert.equal(calls.length,2);assert.equal(calls[1].headers.Authorization,'Bearer fallback-only-test-token');
});
test('native fallback is not automatic without consent', async () => {
  let calls=0;const c=client('android',async()=>{calls++;throw new Error('offline');});
  await assert.rejects(c.api(connection,'/api/v1/readings',payload));assert.equal(calls,1);
});
for (const status of [301,302,401,403,422,429]) test(`native ${status} response does not follow redirects or trigger fallback`, async () => {
  let calls=0;const c=client('android',async()=>{calls++;return {status,data:{error:{message:'Expected rejection'}}};});
  await assert.rejects(c.api({...connection,allowFallback:true},'/api/v1/readings',payload),/Expected rejection/);assert.equal(calls,1);
});
for (const status of [502,503,504]) test(`native ${status} can use an explicitly approved fallback`, async () => {
  let calls=0;const c=client('android',async()=>{calls++;return calls===1?{status,data:{}}:{status:200,data:report};});
  const r=await c.api({...connection,allowFallback:true},'/api/v1/readings',payload);assert.equal(r.route,'fallback');assert.equal(calls,2);
});
for (const bad of [null,'<html>Not an API</html>',{},[]]) test(`native rejects malformed success payload ${JSON.stringify(bad)}`, async () => {
  const c=client('android',async()=>({status:200,data:bad}));
  await assert.rejects(c.api(connection,'/api/v1/readings',payload),/incomplete or incompatible/);
});
test('incomplete or non-finite chart bodies are not treated as a valid reading', async () => {
  for(const mutate of [r=>delete r.chart.bodies.Moon,r=>r.chart.bodies.Moon.longitude=NaN,r=>r.chart.cusps.pop()]){
    const copy=structuredClone(report);mutate(copy);const c=client('android',async()=>({status:200,data:copy}));
    await assert.rejects(c.api(connection,'/api/v1/readings',payload),/incomplete or incompatible/);
  }
});
test('malformed error details do not crash the error parser', async () => {
  const c=client('android',async()=>({status:401,data:{error:{fields:'not-an-array'}}}));
  await assert.rejects(c.api(connection,'/api/v1/readings',payload),/API request failed \(401\)/);
});
test('web transport uses no-store, no cookies, no redirects and explicit JSON', async () => {
  let sent;const c=client('web',undefined,async(url,options)=>{sent={url,options};return {ok:true,status:200,json:async()=>report};});
  await c.api({...connection,primary:''},'/api/v1/readings',payload);
  assert.equal(sent.url,'/api/v1/readings');assert.equal(sent.options.cache,'no-store');assert.equal(sent.options.credentials,'omit');assert.equal(sent.options.redirect,'error');assert.deepEqual(JSON.parse(sent.options.body),payload);
});
