> Historical/general baseline. The current release is Termux-only; use TERMUX_AI_START.md, API_TERMUX.md and QA_TERMUX_AI.md. Native automation/live-account/device limits and AGPL engine terms there take precedence.

> Current 26.2: new Android APK/AAB compiled, native encryption/file-picker code included, 52 browser checks and six JVM crypto tests passed, Android lint 0/0. Physical device/store checks remain open. See ANDROID_UPGRADE.md and QA_REPORT.md.

> Historical RC2 update: Android evaluation APK and unsigned release AAB were compiled; 25 mocked native-client tests passed. Physical-device/store validation remain open; the complete RC2 software regression rerun has passed. See RC2_RELEASE_NOTES.md for authoritative current scope.

# Commercial release gates

**Release decision: suitable for technical evaluation and controlled private deployment; NOT an unqualified public-commercial or app-store release.**

| Gate | Current state | Owner action / acceptance evidence |
|---|---|---|
| Core calculations | Automated/reference checks supplied | Re-run on deployment runtime; review conventions with a qualified domain reviewer |
| Historical consolidation | v26 available; v17–v25 absent | Supply missing source releases/change history and provenance |
| Requested 21 rules | 0/21 definitions verified; all disabled | Numbered source text, rights/approval, executable cases, independent review |
| Prediction accuracy | Not established | Preregistered independent outcome study; no post-hoc 81.2% floor |
| Professor/brand references | Not represented as endorsed | Written permissions/rights review before attributed marketing |
| Licensing | Notices and dependency inventory supplied | Counsel/operator review of exact redistributed artefacts, datasets and provider terms |
| Android native binary | Evaluation APK compiled and debug-signed; release AAB compiled but unsigned | Owner signing, physical-device/background/Termux/share tests, lint-warning review and store review |
| iOS native binary | Project generated/synchronised only | macOS/Xcode build/signing, ATS/network/share/privacy review, device/store testing |
| Termux runtime | Scripts supplied, not device-tested | Validate exact Android/Python/NumPy/Rust packages and process lifecycle offline/online |
| Cloud deployment | Templates and local core/limiter checks | Build images, pin digests, deploy TLS/staging, run real mixed-load/failure tests |
| Public user identity | Private service-token baseline | OAuth/OIDC, tenant isolation, revocation, per-user consent and abuse handling |
| Data governance | No persistent report store by default | Market-specific privacy policy, provider disclosures, consent, retention/support processes |
| ChatGPT | Action schema/contract supplied | Configure actual HTTPS service/auth; live account tests; public-use privacy review |
| Consumer Gems | Upload/paste handoff supplied | Configure Gem and test its actual account behavior; do not claim auto-API from a prompt |
| Gemini API | Opt-in bridge, mock-tested | Provider model/key, live tool-call and factual-output evaluation |
| AstroSage | No contract/credentials supplied | Document supported endpoint/auth/licence; implement adapter and tolerances; test live |
| Billing/subscriptions | Not implemented | Define business model, entitlement enforcement and payment/provider requirements if needed |
| Support and incident response | Diagnostic export only | Add your authenticated support/bug system; do not post to undocumented Arena routes |

No missing gate can be marked completed merely by changing the title, displaying “confirmed” or increasing a score. A disclaimer cannot make fabricated verification true.
