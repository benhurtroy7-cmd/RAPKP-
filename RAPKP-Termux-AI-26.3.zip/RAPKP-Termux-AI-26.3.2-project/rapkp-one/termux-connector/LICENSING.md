# Termux runtime licensing

The user-selected Swiss Ephemeris/pyswisseph and libephemeris runtimes have their own licence terms. LibEphemeris 3.2.1 declares AGPL-3.0-only; Swiss Ephemeris offers AGPL/commercial licensing arrangements. No such library binary or Swiss data file is distributed inside this connector bundle.

New code in backend/rapkp/termux_runtime and the connector integration is offered under AGPL-3.0-only for this build; the shared calculation primitives retain their MIT notices. Full editable source is included. This is not a blanket closed-source-commercial clearance: review obligations/appropriate licences before distributing a combined product or providing a service. Installing a library on a phone does not itself prove redistribution rights.

Sources checked: https://github.com/g-battaglia/libephemeris/blob/master/LICENSE and https://www.astro.com/swisseph/swephinfo_e.htm .
