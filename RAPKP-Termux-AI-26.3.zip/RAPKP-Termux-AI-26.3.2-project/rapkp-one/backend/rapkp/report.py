from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from . import __version__
from .constants import KERNEL_SHA256
from .dasha import Vimshottari

if TYPE_CHECKING:
    from .engine import AstroEngine
from .errors import CalculationError
from .kp import SIGN_LORDS

if TYPE_CHECKING:
    from .models import ReadingRequest
from . import source_rules
from .rules import DOMAINS, assess, interlinks, significators
from .timeutils import resolve_local

DAY_LORDS = ["Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Sun"]


def sensitivity(engine: AstroEngine, req: ReadingRequest, birth_utc: datetime, base: dict) -> dict:
    uncertainty = req.birth.uncertainty_seconds
    if uncertainty == 0:
        return {
            "sampled": False,
            "seconds": 0,
            "sensitive": False,
            "changed_cusps": [],
            "changed_planets": [],
            "note": "No timing variation was requested. This does not establish that the birth time is exact.",
        }
    place = req.birth.place
    variants = [
        engine.chart_at(birth_utc + timedelta(seconds=delta), place.latitude, place.longitude, req.node_mode)
        for delta in (-uncertainty, uncertainty)
    ]
    changes = []
    for i, cusp in enumerate(base["cusps"]):
        values = [variants[0]["cusps"][i]["sub_lord"], cusp["sub_lord"], variants[1]["cusps"][i]["sub_lord"]]
        if len(set(values)) > 1:
            changes.append({"house": i + 1, "earlier": values[0], "recorded": values[1], "later": values[2]})
    planets = []
    for name, p in base["bodies"].items():
        values = [variants[0]["bodies"][name]["sub_lord"], p["sub_lord"], variants[1]["bodies"][name]["sub_lord"]]
        if len(set(values)) > 1:
            planets.append({"name": name, "earlier": values[0], "recorded": values[1], "later": values[2]})
    return {
        "sampled": True,
        "seconds": uncertainty,
        "sensitive": bool(changes or planets),
        "changed_cusps": changes,
        "changed_planets": planets,
        "note": "Three-point sample (earlier / recorded / later), not exhaustive interval verification, birth-time rectification or a confidence interval.",
    }


def create_report(engine: AstroEngine, req: ReadingRequest) -> dict:
    meta = getattr(engine, "report_metadata", {})
    birth_utc = resolve_local(req.birth)
    analysis_utc = resolve_local(req.analysis)
    if analysis_utc < birth_utc:
        raise CalculationError("BEFORE_BIRTH", "The evaluation moment must not precede birth.")
    p, q = req.birth.place, req.analysis.place
    natal = engine.chart_at(birth_utc, p.latitude, p.longitude, req.node_mode)
    current = engine.chart_at(analysis_utc, q.latitude, q.longitude, req.node_mode)
    periods = Vimshottari(birth_utc, natal["bodies"]["Moon"]["longitude"]).report(analysis_utc)
    timing = sensitivity(engine, req, birth_utc, natal)
    sig = significators(natal)
    domain = req.domain.value
    assessment = assess(natal, sig, periods, domain, timing["sensitive"])
    current_moon = current["bodies"]["Moon"]
    asc = current["cusps"][0]
    local = analysis_utc.astimezone(ZoneInfo(q.timezone))
    ruling = {
        "at_utc": analysis_utc.isoformat(),
        "place": q.model_dump(),
        "ascendant_sign_lord": SIGN_LORDS[int(asc["longitude"] // 30)],
        "ascendant_star_lord": asc["star_lord"],
        "ascendant_sub_lord": asc["sub_lord"],
        "moon_sign_lord": current_moon["sign_lord"],
        "moon_star_lord": current_moon["star_lord"],
        "day_lord": DAY_LORDS[local.weekday()],
        "day_convention": "Local civil weekday (midnight boundary), not sunrise-based KP weekday",
    }
    rule_domain = dict(DOMAINS[domain])
    rule_domain["_birth_date"] = req.birth.date.isoformat()
    horary = {"number": req.horary_number} if getattr(req, "horary_number", None) else None
    source_rule_evaluation = source_rules.evaluate(
        natal, sig, interlinks(natal, sig), periods, ruling, rule_domain,
        current if req.include_transits else None, horary,
    )
    warnings = list(natal["warnings"])
    if timing["sensitive"]:
        warnings.append(
            "Sampled cusp or planetary sub-lords change within the requested birth-time uncertainty. Do not present a decisive judgment."
        )
    if req.node_mode == "true":
        warnings.append(
            meta.get(
                "true_node_note",
                "True nodes use OpenEphem's osculating-orbit definition. Reference residuals are larger than for classical planets; do not infer sub-arcsecond node accuracy.",
            )
        )
    warnings.extend(
        [
            "V17–V25 documents and the complete 11+10 numbered rules were not supplied. A 10-step public structural outline was supplied and is evaluated separately; it is not the 1,500+ specific master rules.",
            "AstroSage validation and the claimed Astra accuracy standard are not configured or verified.",
            "Astrology has no scientifically established ability to provide precise personal-event probabilities.",
        ]
    )
    generated = datetime.now(timezone.utc)
    normalized = json.dumps(req.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))
    # ID is a reproducibility fingerprint, not an authentication token or anonymisation.
    fingerprint = hashlib.sha256(
        (__version__ + meta.get("fingerprint", KERNEL_SHA256) + normalized).encode()
    ).hexdigest()[:16]
    target_text = ", ".join(str(h) for h in assessment["target_houses"])
    summary = f"For {DOMAINS[domain]['label'].lower()}, the baseline checks inspect houses {target_text}. {sum(c['matched'] for c in assessment['checks'])} of four link checks match the disclosed baseline. This is a description of chart links, not evidence that the event will happen."
    return {
        "schema_version": "1.0",
        "report_id": fingerprint,
        "generated_at": generated.isoformat(),
        "generated_at_ist": generated.astimezone(ZoneInfo("Asia/Kolkata")).isoformat(),
        "title": f"{DOMAINS[domain]['label']} · RAPKP One · Traceable analysis",
        "question": req.question,
        "domain": domain,
        "input_summary": {
            "birth": req.birth.model_dump(mode="json"),
            "analysis": req.analysis.model_dump(mode="json"),
            "birth_utc": birth_utc.isoformat(),
            "analysis_utc": analysis_utc.isoformat(),
        },
        "calculation": {
            "status": "computed",
            "engine": meta.get("engine", "OpenEphem 0.3.0 + Skyfield 1.55 + JPL DE440s"),
            "house_system": "Placidus",
            "ayanamsa": "Krishnamurti / mean-ecliptic convention",
            "node_mode": req.node_mode,
            "date_range": "1900–2099",
            "kernel_sha256": meta.get("kernel_sha256") if meta else KERNEL_SHA256,
            "provider_metadata": meta,
        },
        "chart": natal,
        "transits": current if req.include_transits else None,
        "dasha": periods,
        "ruling_planets": ruling,
        "significators": sig,
        "cuspal_interlinks": interlinks(natal, sig),
        "assessment": assessment,
        "source_rule_evaluation": source_rule_evaluation,
        "sensitivity": timing,
        "verification": [
            {
                "item": "Input timezones and coordinates",
                "status": "validated",
                "detail": "Explicit IANA zones; ambiguous or nonexistent times rejected unless resolved.",
            },
            {
                "item": "Ephemeris integrity",
                "status": meta.get("integrity_status", "verified"),
                "detail": meta.get("integrity_detail", "Bundled DE440s SHA-256 checked before use."),
            },
            {
                "item": "Placidus and sidereal calculation",
                "status": "computed",
                "detail": "Fail-closed calculation; release reference tests are separate evidence, not per-report external validation.",
            },
            {
                "item": "Vimshottari periods",
                "status": "computed",
                "detail": "Full first-mahadasha birth offset; three levels; declared 365.2425-day year.",
            },
            {
                "item": "21 source rules",
                "status": "pending",
                "detail": "Definitions not supplied; not implemented or attributed.",
            },
            {
                "item": "AstroSage / external comparison",
                "status": "not_connected",
                "detail": "No endpoint credentials or approved validation contract supplied.",
            },
            {
                "item": "Event prediction probability",
                "status": "not_established",
                "detail": "Rule support is not a calibrated probability; binary judgment abstained.",
            },
        ],
        "warnings": warnings,
        "interpretation": {
            "provider": "deterministic_template",
            "external_ai_used": False,
            "summary": summary,
            "sequence": [
                "Inputs",
                "Chart",
                "Cuspal links",
                "Dasha–Bhukti–Antara",
                "Ruling planets and transit context",
                "Sensitivity",
                "Abstention and limitations",
            ],
            "practical_note": "Use real-world evidence for decisions. Do not use this report to diagnose illness, predict death, or make legal or investment decisions.",
        },
        "provenance": {
            "application_version": __version__,
            "ruleset": "baseline-1.0",
            "sources_reviewed": ["v26 PDF", "operating prompt"],
            "source_versions_not_available": ["17–25"],
            "forecast_accuracy_verified": False,
            "report_stored_on_server": False,
        },
        "validation_footer": "Calculation provenance recorded. External interpretation is not independent chart/outcome validation. See the separate AI job status. No event-probability or accuracy guarantee. Query text may be cleared in RAPKP's own interface only; no control over Arena, ChatGPT or Gems input boxes.",
    }
