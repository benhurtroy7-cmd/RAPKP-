# RAPKP Termux AI 26.3 — start here

**New route: App → Termux calculations → configured AI provider → app.**

No permanent cloud backend URL is required. The APK uses only its paired on-phone connector at `127.0.0.1:8765`. Your existing Swiss Ephemeris/libephemeris packages are reused, not replaced. Calculations can work offline with installed data; hosted AI interpretation still needs internet and your own provider API key.

## One-time setup on your phone

1. **Install the new APK as an update.** Open **RAPKP Termux AI**, version `26.3.0-termux.1`, build `2603001`. The package and signing certificate match the supplied 26.2 preview.
2. Open **Termux & AI setup → Allow Termux integration**. Grant **Run commands in Termux**. If Android places it under “Additional permissions”, grant it there.
3. In that setup screen, tap **Copy one-time command**, open your installed Termux, and paste/run the command. It enables `allow-external-apps=true`. This is a powerful permission: grant RUN_COMMAND only to trusted apps. RAPKP exposes only fixed bundled setup/start commands; questions and model keys are never shell command text.
4. Return to RAPKP and tap **Install / re-pair connector**. The APK transfers a small source-only Python connector through Termux's documented API, creates a private pairing configuration and installs its own `90-rapkp-one` Boot hook. It does not reinstall Python libraries or overwrite unrelated scripts.
5. Tap **Start & connect / Check local service**. The UI reports the actual installed providers and calculation readiness. Merely sending a start intent is not treated as a successful connection.
6. Since Termux:Boot is already installed, open it once if you have not previously done so. Its hook starts this service at boot. Android/OEM battery restrictions can still stop background processes; review Termux/Boot battery settings if required. No draw-over-apps permission or arbitrary shell-command API is needed by this connector.

After setup, the app attempts to reconnect/start the paired local service when opened. It never asks for an Arena/e2b cloud URL.

## Ephemeris settings

- **Auto** prefers user-installed Swiss Ephemeris when both `sepl_18.se1` and `semo_18.se1` are found. Otherwise it can use an installed libephemeris with local data. The actual provider is displayed and recorded.
- **Swiss Ephemeris** requires the real data folder. Installing only the Python module does not prove those files exist. Missing Swiss files produce a specific error; Moshier/zero/equal-house charts are not silently substituted.
- **libephemeris** can use the local bundled LEB data of tested 3.2.1, or an explicitly selected existing local BSP file. Older/other installed versions may need a data path. Your phone's exact library versions have not been inspected remotely.
- Python 3.10+ is needed for the connector; current libephemeris 3.2.1 requires Python 3.12+. The connector itself uses the standard library rather than requiring a new FastAPI/Pydantic/Rust install.

The supported input range remains 1900–2099 UTC and Placidus latitude strictly inside ±66°. DST ambiguity, nonexistent times and incomplete provider results are rejected, not approximated silently.

## Enable the AI reading

In **Termux & AI setup**:

1. Choose OpenAI or Gemini API.
2. Select a model available to your account. Presets checked against the 2 October 2026 provider documentation include **gpt-6-astra**, **gpt-6.1-sol** and **gemini-3.8-flash**. “Best” depends on workload; none is certified as a precise astrology predictor.
3. Enter your provider API key **inside the app**, not in this conversation. It is sent only to the authenticated local Termux connector and stored in Termux's private `~/.rapkp-one/config.json` with mode 0600. The key is not returned by status/diagnostics or embedded in the APK. Changing providers without entering a new key does not forward the old provider's key.
4. Explicitly allow sending the question and chart context to that provider. API billing may apply. A ChatGPT/Gemini consumer subscription is not an API key.
5. Save settings, return to Workbench and choose **Calculate & ask AI**.

The chart is computed first. AI runs as a separate background job, so a slow model is not presented as a broken calculation connection. Identical queued/running/completed jobs are reused to avoid automatic duplicate paid requests. No automatic paid retry occurs. If the provider rejects the key, model or quota, the calculated chart remains available and a specific AI error is shown.

The AI receives computed evidence with reference IDs. The response's report ID/schema/evidence IDs are checked, but its prose is not independently fact-checked or empirically calibrated. The app displays **AI prose · unverified** and does not convert support points into a probability.

## What is—and is not—verified

Compilation, signatures, source/bundle matching, Python tests, browser tests, mocked provider calls, native-transport mocks and Java crypto tests were executed in the build environment. **No physical phone, Android Termux RUN_COMMAND/Boot execution, hardware Keystore flow or paid live model call was tested here.** Device and account validation remain required.

“No errors ever” and precise personal-event prediction cannot honestly be guaranteed. The missing complete 21-rule definitions and historical v17–v25 source releases were not invented. Medical, legal and financial decisions require real-world professional evidence.

## Troubleshooting that identifies the failing stage

- **Permission denied / no setup reply:** grant RUN_COMMAND to this APK and enable `allow-external-apps=true` in Termux; open Termux once if force-stopped.
- **Termux connector did not respond:** use Start & connect; keep Termux permitted to run. Check its Python availability and installed connector.
- **Local process is not paired:** use Install / re-pair. Do not paste another app's token or kill unrelated services using the port.
- **Engine/data error:** select the actual provider/data folder in the app; do not keep repeating a generic network test.
- **AI key/model/quota/network error:** correct the AI configuration; the chart is not discarded or replaced with a fabricated answer.

Only the connector's own private directory and Boot hook are managed. The pairing token is protected in Android Keystore storage; a server HMAC challenge is verified before sensitive native requests are sent. These measures do not protect a rooted/compromised phone or malicious code already running with Termux command permission.

## Licensing and commercial use

Swiss Ephemeris and libephemeris have their own AGPL/commercial terms. No ephemeris library binary or Swiss data file is shipped in the connector. New Termux-runtime code is provided with AGPL-3.0-only terms; shared primitives retain MIT notices. Review the full included source/licences before redistribution. This is not blanket closed-source-commercial or app-store clearance.

## Documentation used

- Termux RUN_COMMAND: https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent
- Termux:Boot: https://github.com/termux/termux-boot
- OpenAI model catalog: https://developers.openai.com/api/docs/models
- Gemini 3.8 Flash: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash
- LibEphemeris API/license: https://github.com/g-battaglia/libephemeris
