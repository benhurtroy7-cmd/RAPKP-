"""Termux-only runtime. Uses installed ephemeris libraries; no web framework required."""
