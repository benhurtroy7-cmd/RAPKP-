#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -z "${PREFIX:-}" ] || [[ "$PREFIX" != *com.termux* ]]; then
  echo 'This installer is for the supported Termux app on Android. On Linux/macOS use scripts/install.sh.' >&2; exit 1
fi
# System NumPy avoids an unsupported Android wheel/source-build path.
# Rust/Clang may be needed to compile pydantic-core on this Android/Python version.
pkg update
pkg install -y python python-numpy rust clang make pkg-config
python -m venv --system-site-packages .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/verify_kernel.py
printf '\nInstalled. Start with: bash scripts/run-termux.sh\nThis script has not been tested on a physical device in the supplied QA run.\n'
