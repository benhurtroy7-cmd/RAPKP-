#!/usr/bin/env bash
# Owner-run operation only. No keystore, credentials, or store upload is supplied.
set +x
set -euo pipefail
cd "$(dirname "$0")/.."
: "${RAPKP_KEYSTORE:?Set path to YOUR private upload keystore}"
: "${RAPKP_KEY_ALIAS:?Set YOUR upload-key alias}"
: "${RAPKP_STORE_PASSWORD:?Set keystore password in your environment}"
export RAPKP_KEY_PASSWORD="${RAPKP_KEY_PASSWORD:-$RAPKP_STORE_PASSWORD}"
INPUT="native-artifacts/android/RAPKP-One-26.2.0-preview.1-unsigned.aab"
OUTPUT="native-artifacts/android/RAPKP-One-26.2.0-preview.1-owner-signed.aab"
jarsigner -keystore "$RAPKP_KEYSTORE" -storepass:env RAPKP_STORE_PASSWORD -keypass:env RAPKP_KEY_PASSWORD -signedjar "$OUTPUT" "$INPUT" "$RAPKP_KEY_ALIAS"
jarsigner -verify "$OUTPUT"
printf '\nOwner-signed AAB written locally. Nothing was uploaded to any store.\n'
