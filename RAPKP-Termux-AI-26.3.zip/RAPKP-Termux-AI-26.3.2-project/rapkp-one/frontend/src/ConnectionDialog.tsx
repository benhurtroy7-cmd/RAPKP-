import { Capacitor } from '@capacitor/core';
import { useEffect, useRef, useState } from 'react';
import { ArrowRight, KeyRound, Link2, Loader2, ShieldCheck, X } from 'lucide-react';
import { api, isNative, validateEndpoint, type Connection } from './api';
import { hasDeviceFeatures } from './device';
import type { Status } from './types';

export default function ConnectionDialog({ value, remembered, onForget, onSave, onClose }: { value: Connection; remembered: boolean; onForget: () => Promise<void>; onSave: (v: Connection, remember: boolean) => Promise<void>; onClose: () => void }) {
  const [draft, setDraft] = useState(value);
  const [remember, setRemember] = useState(remembered);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const dialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    dialog.current?.querySelector<HTMLInputElement>('input')?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') {
        const items = dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),a[href]');
        if (!items?.length) return;
        const first = items[0], last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('keydown', onKey); previous?.focus(); };
  }, [onClose]);
  const validated = () => {
    const primary = validateEndpoint(draft.primary), fallback = validateEndpoint(draft.fallback);
    if (isNative() && !primary) throw new Error('Native builds need an explicit backend URL.');
    if (draft.allowFallback && !fallback) throw new Error('Enter a fallback URL before enabling fallback.');
    if (fallback && fallback === primary) throw new Error('Primary and fallback endpoints must be different.');
    return { ...draft, primary, fallback };
  };
  const test = async () => {
    setBusy(true); setError(''); setInfo('');
    try { const { data, route } = await api<Status>(validated(), '/api/v1/status'); setInfo(`${route === 'fallback' ? 'Fallback' : 'Primary'} endpoint reached · ${data.engine_ready ? 'kernel loaded' : 'engine unavailable'}. ${data.authentication_required ? 'Calculation authentication is required; this public status check does not validate the token.' : 'Unauthenticated demo/local mode.'}`); }
    catch (e) { setError(e instanceof Error ? e.message : 'Connection test failed'); }
    finally { setBusy(false); }
  };
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="connection-dialog" role="dialog" aria-modal="true" aria-labelledby="connection-heading" ref={dialog}>
    <div className="modal-heading"><span className="soft-icon"><Link2 size={21} /></span><button className="icon-button" onClick={onClose} aria-label="Close settings"><X size={20} /></button></div>
    <h2 id="connection-heading">Choose your connection.</h2><p>One API contract, wherever you run it. Web uses this app’s own server unless you configure another.</p>
    {Capacitor.getPlatform() === 'android' && <div className="native-quick-connect"><button type="button" className="secondary-button" onClick={() => { setDraft({ primary: 'http://127.0.0.1:8000', primaryToken: '', fallback: '', fallbackToken: '', allowFallback: false }); setInfo('Local address filled. Start RAPKP One in Termux first, then test or use this connection. No calculation has been sent.'); setError(''); }}>Use Termux on this phone</button><p className="fine-print">This fills a same-device URL and clears any previous endpoint tokens. For cloud use, enter your own HTTPS API below.</p></div>}
    <label className="field"><span>Primary API URL</span><input type="url" placeholder={isNative() ? 'https://your-api.example' : 'Same origin (recommended for web)'} value={draft.primary} onChange={e => setDraft({ ...draft, primary: e.target.value })} autoComplete="off" /></label>
    <label className="field"><span><KeyRound size={12} /> Primary API token</span><input type="password" placeholder="Required for protected deployments" value={draft.primaryToken} onChange={e => setDraft({ ...draft, primaryToken: e.target.value })} autoComplete="off" /></label>
    <details className="connection-advanced"><summary>Optional, explicitly authorised fallback</summary><label className="field"><span>Fallback API URL</span><input type="url" placeholder={isNative() ? 'Android Termux or another HTTPS server' : 'https://secondary.your-domain.example'} value={draft.fallback} onChange={e => setDraft({ ...draft, fallback: e.target.value })} /></label><label className="field"><span>Separate fallback token</span><input type="password" value={draft.fallbackToken} onChange={e => setDraft({ ...draft, fallbackToken: e.target.value })} autoComplete="off" /></label><label className="checkbox-line"><input type="checkbox" checked={draft.allowFallback} onChange={e => setDraft({ ...draft, allowFallback: e.target.checked })} /><span>I authorise sending my calculation inputs to this fallback if the primary has a network/502/503/504 failure. Primary credentials are never forwarded to it.</span></label></details>
    <div className="privacy-note"><ShieldCheck size={16} /><span>Tokens are session-only unless you explicitly enable encrypted Android storage below. Use only endpoints you trust with birth details. Android-native Termux loopback is an explicit option, not a connection to this sandbox.</span></div>
    {hasDeviceFeatures() && <div className="secure-connection"><label className="checkbox-line"><input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)}/><span>Remember this connection securely on this Android device</span></label><p className="fine-print">Opt-in AES-GCM encryption with an Android Keystore key. Restoring the app loads the token into memory and checks the saved endpoint. Birth details are not saved.</p><button type="button" className="text-button" disabled={busy} onClick={async()=>{setBusy(true);try{await onForget();setRemember(false);setInfo('Saved connection erased. Current session values remain until you clear them or close the app.');}catch{setError('Could not erase the saved connection. Try again.');}finally{setBusy(false);}}}>Forget saved connection</button></div>}
    {error && <div className="inline-error" role="alert">{error}</div>}{info && <div className="inline-info" role="status">{info}</div>}
    <div className="dialog-actions"><button className="secondary-button" onClick={test} disabled={busy}>{busy ? <Loader2 size={15} className="spin" /> : <Link2 size={15} />} Test endpoint</button><button className="primary-button" disabled={busy} onClick={async () => { setBusy(true); setError(''); try { await onSave(validated(), remember); } catch (e) { setError(e instanceof Error ? e.message : 'Invalid configuration'); } finally { setBusy(false); } }}>Use connection <ArrowRight size={16} /></button></div>
  </div></div>;
}
