> Historical/general baseline. The current release is Termux-only; use TERMUX_AI_START.md, API_TERMUX.md and QA_TERMUX_AI.md. Native automation/live-account/device limits and AGPL engine terms there take precedence.

> Historical RC2 update: Android evaluation APK and unsigned release AAB were compiled; 25 mocked native-client tests passed. Physical-device/store validation remain open; the complete RC2 software regression rerun has passed. See RC2_RELEASE_NOTES.md for authoritative current scope.

# Security and privacy review

## Implemented and tested controls

- Production starts only with a non-placeholder API token of at least 32 characters. Constant-time bearer-token comparison; token absent from status/schema/settings repr.
- Strict typed input, extra-field rejection, finite-number checks, explicit dates/timezones and bounded text/body size including chunked requests.
- Finite compute slots, 429 overload, digest-keyed quotas and optional shared Valkey quota. Shared limiter outage fails closed.
- Explicit production CORS; no wildcard credentials. Same-origin browser requests by default. HTTPS endpoint validation, separate fallback token, and no fallback after validation/auth/rate errors.
- No eval, shell execution or SQL composed from user question text. React renders submitted text as data. Prompt-like strings cannot change calculated fields or server abstention.
- Per-request no-store API response headers; CSP, no-sniff and no-referrer headers. No automatic chart/credential logging in launch configurations.
- No persistent chart store. Up to 96 computed chart entries per worker remain in RAM until eviction/restart; calculations/request handling also use transient memory.
- Browser fields/tokens live in memory. Android 26.2 optionally persists only connection fields with AES-GCM/Android Keystore after explicit opt-in; restored tokens are used in app memory. Service worker caches only static UI assets. Explicit exports may contain personal information.
- Native Android backup disabled, general cleartext disallowed, only explicit same-device loopback exception for Termux. Native device behavior requires testing.
- Missing/corrupt calculation data never becomes invented chart data. Provider calls are outside the core, opt-in and separately configured.
- Diagnostics preparation does not silently upload to Arena or any vendor.

## What this is not

Not a penetration test, formal proof, compliance certification or independent security audit. Dependency scans are dated checks of known advisory databases, not proof of absence of vulnerabilities. Browser checks do not establish platform-native security. Numeric agreement does not imply valid event prediction.

## Public deployment blockers

A single shared service token is **not public multi-tenant identity management**. Before public user accounts: implement OAuth/OIDC/JWKS validation, token expiry/rotation/revocation, tenant boundaries, role policies, consent and account-deletion flows. Do not embed a master key in a downloadable app or public GPT.

Set TLS, trusted reverse-proxy rules, WAF/request timeouts, secret management and operational monitoring. Restrict private Valkey access; enable encryption/auth where it crosses trusted-host boundaries. Do not expose its port publicly. Apply least privilege, non-root read-only app containers, image digest pins, vulnerability remediation and disaster/restart procedures.

Configure infrastructure log retention and redact IPs/URLs as appropriate. The app cannot control proxy/cloud/provider logs, chat retention, exported files, clipboard history or Android/iOS share recipients. Do not claim “nothing leaves the device” while using a cloud API.

For India or other markets, obtain appropriate privacy/legal review and publish your own accurate privacy notice, terms, consent and support/contact process. Do not copy a generic disclaimer and claim compliance.

## Reporting

`Export diagnostics` downloads non-chart status information. `/api/report_bug` returns `prepared_only`, `stored=false`, `sent_to_arena=false`. Configure your own authenticated, consent-aware support channel before enabling any telemetry. Never attach birth details or credentials automatically.

## 26.2 native controls

The new Android plugin implements explicit encrypted connection remembering/forgetting and user-selected JSON file output through the system picker. App fields/reports are not silently persisted. Exported files are plaintext and can contain personal data. Bridge logging and WebView debugging are disabled; legacy and Android-12 backup/device-transfer exclusions are configured. These measures do not protect a compromised/rooted device. Six JVM encryption tests passed; physical Android Keystore/picker/lifecycle behavior is not reported as tested. See ANDROID_UPGRADE.md.
