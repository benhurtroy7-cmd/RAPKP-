"""Strict standard-library request validation for an existing Termux Python runtime."""

import math
from dataclasses import asdict, dataclass
from datetime import date, time
from enum import Enum
from zoneinfo import ZoneInfo

from ..errors import CalculationError
from ..rules import DOMAINS

Domain = Enum("Domain", {x: x for x in DOMAINS}, type=str)


def reject(field):
    raise CalculationError("INPUT_VALIDATION", f"Review {field}; required or valid structured input is missing.")


def mapping(value, allowed, field):
    if not isinstance(value, dict) or set(value) - set(allowed):
        reject(field)
    return value


def string(value, field, maximum=600):
    if not isinstance(value, str) or len(value) > maximum:
        reject(field)
    return value.strip()


def number(value, field, lo, hi):
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or not lo <= value <= hi
    ):
        reject(field)
    return float(value)


@dataclass
class Place:
    label: str
    latitude: float
    longitude: float
    timezone: str

    def model_dump(self, **kwargs):
        return asdict(self)


@dataclass
class Moment:
    date: date
    time: time
    place: Place
    fold: int | None = None

    def model_dump(self, **kwargs):
        result = asdict(self)
        result["date"] = self.date.isoformat()
        result["time"] = self.time.isoformat()
        return result


@dataclass
class Birth(Moment):
    uncertainty_seconds: int = 60


@dataclass
class Request:
    birth: Birth
    analysis: Moment
    domain: Domain
    question: str = ""
    node_mode: str = "mean"
    include_transits: bool = True

    def model_dump(self, **kwargs):
        return {
            "birth": self.birth.model_dump(),
            "analysis": self.analysis.model_dump(),
            "domain": self.domain.value,
            "question": self.question,
            "node_mode": self.node_mode,
            "include_transits": self.include_transits,
        }


def parse_place(value, field):
    p = mapping(value, ["label", "latitude", "longitude", "timezone"], field)
    label = string(p.get("label", "Custom location"), field + " label", 100)
    if not label:
        reject(field + " label")
    zone = string(p.get("timezone"), field + " timezone", 80)
    if zone not in {"UTC", "Etc/UTC"} and "/" not in zone:
        reject(field + " IANA timezone")
    try:
        ZoneInfo(zone)
    except Exception:
        reject(field + " IANA timezone")
    return Place(
        label,
        number(p.get("latitude"), field + " latitude", -90, 90),
        number(p.get("longitude"), field + " longitude", -180, 180),
        zone,
    )


def parse_moment(value, field, birth=False):
    p = mapping(value, ["date", "time", "place", "fold"] + (["uncertainty_seconds"] if birth else []), field)
    try:
        d = date.fromisoformat(string(p.get("date"), field + " date", 10))
        t = time.fromisoformat(string(p.get("time"), field + " time", 24))
    except (ValueError, TypeError):
        reject(field + " date/time")
    if not 1900 <= d.year <= 2099 or t.tzinfo is not None:
        reject(field + " local date/time")
    fold = p.get("fold")
    if fold is not None and (type(fold) is not int or fold not in (0, 1)):
        reject(field + " DST occurrence")
    values = (d, t, parse_place(p.get("place"), field + " place"), fold)
    if not birth:
        return Moment(*values)
    u = p.get("uncertainty_seconds", 60)
    if type(u) is not int or not 0 <= u <= 1800:
        reject("birth uncertainty")
    return Birth(*values, u)


def parse_request(value):
    r = mapping(value, ["birth", "analysis", "domain", "question", "node_mode", "include_transits"], "request")
    domain = r.get("domain", "career")
    if domain not in DOMAINS:
        reject("domain")
    mode = r.get("node_mode", "mean")
    if mode not in {"mean", "true"}:
        reject("node mode")
    include = r.get("include_transits", True)
    if type(include) is not bool:
        reject("transit option")
    return Request(
        parse_moment(r.get("birth"), "birth", True),
        parse_moment(r.get("analysis"), "analysis"),
        Domain(domain),
        string(r.get("question", ""), "question"),
        mode,
        include,
    )
