# Documentation consulted / provenance

Checked on 30 September 2026. Upstream claims are not substituted for the local test evidence.

- OpenEphem repository and source licence: MIT notice inspected and retained; upstream labels the project beta. [1](https://github.com/NoahChristian/openephem)
- Skyfield package metadata: MIT licence. [5](https://pypi.org/project/skyfield/)
- Skyfield/JPL ephemeris guidance: DE440s is the short DE440 kernel; this product intentionally restricts its own supported dates to 1900–2099. [1](https://rhodesmill.org/skyfield/planets.html)
- OpenAI Custom GPT Actions require an OpenAPI schema and real configured endpoints. [2](https://platform.openai.com/docs/actions/getting-started)
- Actions authentication options include API keys and OAuth. [1](https://developers.openai.com/api/docs/actions/authentication)
- Google Gems documentation describes custom instructions and knowledge-file uploads. This product therefore supplies an explicit handoff workflow, not an invented arbitrary API connector. [1](https://support.google.com/gemini/answer/15235603?hl=en)
- Gemini developer documentation describes API/tool workflows. A developer API bridge is distinct from a consumer Gem configuration. [2](https://ai.google.dev/gemini-api/docs)

Direct technical/data sources (not endorsements):
- NASA/JPL bundled kernel URL and checksum: `data/manifest.json`.
- Pinned installed dependency versions/notices: `requirements-lock.txt`, `frontend/package-lock.json`, `licenses/dependency-inventory.json`.
- Actual reference fixtures and comparison metadata: `backend/tests/fixtures/astronomy-reference.json`, `qa/reference-residuals.json`.
- Supplied file hashes and missing-source record: `qa/source-manifest.json`.
