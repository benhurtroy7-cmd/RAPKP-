import { Capacitor } from '@capacitor/core';
import { validateEndpoint, type BaseConnection, type Connection, type ConnectionMode } from './api';
export const emptyCloud = ():BaseConnection => ({primary:'',primaryToken:'',fallback:'',fallbackToken:'',allowFallback:false});
export const defaultTermux = ():BaseConnection => ({primary:'http://127.0.0.1:8000',primaryToken:'',fallback:'',fallbackToken:'',allowFallback:false});
export const isLoopback = (url:string):boolean => {try{const u=new URL(url);return u.protocol==='http:'&&['127.0.0.1','localhost'].includes(u.hostname);}catch{return false;}};
export function inferredMode(c:Connection):ConnectionMode {
 if(c.mode==='cloud'||c.mode==='termux'||c.mode==='web')return c.mode;
 return !c.primary ? Capacitor.isNativePlatform()?'cloud':'web' : isLoopback(c.primary)?'termux':'cloud';
}
export function profilesFor(c:Connection):{cloud:BaseConnection;termux:BaseConnection} {
 const basic:BaseConnection={primary:c.primary,primaryToken:c.primaryToken,fallback:c.fallback,fallbackToken:c.fallbackToken,allowFallback:c.allowFallback};
 const mode=inferredMode(c);
 return {cloud:{...(c.profiles?.cloud || (mode==='cloud'?basic:emptyCloud()))},termux:{...(c.profiles?.termux || (mode==='termux'?basic:defaultTermux()))}};
}
export function permanentCloudUrl(value:string):string {
 const v=validateEndpoint(value);
 if(!v)throw new Error('Cloud setup is required. Deploy a backend in your hosting account, then paste its real HTTPS URL here. The APK does not create that server.');
 const u=new URL(v);
 if(u.protocol!=='https:')throw new Error('Permanent Cloud requires an HTTPS service. Use Local Termux for this phone’s HTTP server.');
 if(u.hostname.endsWith('.e2b.app')||u.hostname.endsWith('.e2b.dev'))throw new Error('Arena/e2b preview addresses are temporary or platform-protected, not your permanent cloud backend. Use the URL from your own hosting deployment.');
 if(u.hostname==='your-api.example'||u.hostname==='api.your-domain.example'||u.hostname==='example.com'||u.hostname==='your-domain.example')throw new Error('That is a placeholder address, not a deployed cloud server. Copy the real URL from your hosting dashboard.');
 return v;
}
export function modeConnection(mode:ConnectionMode,profiles:{cloud:BaseConnection;termux:BaseConnection},web:BaseConnection):Connection {
 if(mode==='web')return {...web,primary:'',mode,profiles};
 const current={...profiles[mode]};
 if(mode==='cloud')current.primary=permanentCloudUrl(current.primary);
 else {
  if(Capacitor.getPlatform()!=='android')throw new Error('Same-phone Termux mode is available only inside the Android app.');
  current.primary=validateEndpoint(current.primary);
  if(!isLoopback(current.primary))throw new Error('Local Termux must use http://127.0.0.1:<port> or localhost on this Android phone.');
  current.fallback='';current.fallbackToken='';current.allowFallback=false;
 }
 if(current.allowFallback){current.fallback=validateEndpoint(current.fallback);if(!current.fallback)throw new Error('Enter the explicitly authorised fallback address.');}
 if(current.fallback&&current.fallback===current.primary)throw new Error('Primary and fallback endpoints must be different.');
 return {...current,mode,profiles:{...profiles,[mode]:current}};
}
