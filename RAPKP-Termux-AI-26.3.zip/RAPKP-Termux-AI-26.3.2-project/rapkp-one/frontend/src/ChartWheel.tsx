import { colors, glyphs } from './utils';
import type { Chart } from './types';

export default function ChartWheel({ chart }: { chart?: Chart }) {
  const cx = 185, cy = 185;
  const point = (angle: number, r: number) => [cx + r * Math.cos(angle * Math.PI / 180), cy + r * Math.sin(angle * Math.PI / 180)];
  const origin = chart?.angles.ascendant || 0;
  const angle = (lon: number) => 180 - (lon - origin);
  const zodiac = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'];
  return <svg className={`chart-wheel ${chart ? 'calculated' : ''}`} viewBox="0 0 370 370" role="img" aria-label={chart ? 'Calculated sidereal chart wheel' : 'Decorative chart outline. No chart calculated yet.'}>
    <defs><radialGradient id="chartGlow"><stop offset="0%" stopColor="#edf1e8" /><stop offset="100%" stopColor="#fbfbf7" /></radialGradient></defs>
    <circle cx={cx} cy={cy} r="169" fill="url(#chartGlow)" stroke="#d8dfd1" />
    <circle cx={cx} cy={cy} r="136" fill="none" stroke="#d8dfd1" /><circle cx={cx} cy={cy} r="106" fill="none" stroke="#d8dfd1" strokeDasharray="2 5" />
    <circle cx={cx} cy={cy} r="71" fill="#fafbf7" stroke="#dfe5d9" />
    {Array.from({ length: 72 }, (_, i) => { const a = i * 5; const p1 = point(a, i % 6 === 0 ? 136 : 163), p2 = point(a, 169); return <line key={`t${i}`} x1={p1[0]} y1={p1[1]} x2={p2[0]} y2={p2[1]} stroke="#cbd5c5" strokeWidth={i % 6 === 0 ? 1 : .7} />; })}
    {zodiac.map((z, i) => { const p = point(angle(i * 30 + 15), 151); return <text key={z} x={p[0]} y={p[1]} textAnchor="middle" dominantBaseline="central" fill="#6d8570" fontSize="16">{z + '\uFE0E'}</text>; })}
    {(chart?.cusps || Array.from({ length: 12 }, (_, i) => ({ longitude: i * 30, house: i + 1 }))).map(c => { const a = angle(c.longitude), p1 = point(a, 73), p2 = point(a, 134), mid = point(a - 12, 89); return <g key={c.house}><line x1={p1[0]} y1={p1[1]} x2={p2[0]} y2={p2[1]} stroke="#dce3d6" /><text x={mid[0]} y={mid[1]} textAnchor="middle" fontSize="9" fill="#98a18f">{c.house}</text></g>; })}
    {chart && Object.entries(chart.bodies).map(([name, p], i) => { const a = angle(p.longitude), [x, y] = point(a, 112 + (i % 3) * 8); return <g key={name}><circle cx={x} cy={y} r="10" fill="#fbfbf7" /><text x={x} y={y} textAnchor="middle" dominantBaseline="central" fontSize="17" fill={colors[name]}>{glyphs[name]}</text></g>; })}
    <text x={cx} y={164} textAnchor="middle" fontSize="8" letterSpacing="2" fill="#7e9077">{chart ? 'SIDEREAL ASCENDANT' : 'YOUR CELESTIAL MAP'}</text>
    <text x={cx} y={193} textAnchor="middle" fontSize={chart ? '26' : '22'} fontFamily="Georgia, serif" fill="#2b493d">{chart ? chart.cusps[0].sign : 'A little clarity.'}</text>
    <text x={cx} y={213} textAnchor="middle" fontSize="9" fill="#8b977e">{chart ? 'KRISHNAMURTI · PLACIDUS' : 'START WITH YOUR DETAILS'}</text>
    <circle cx="15" cy={cy} r="3" fill="#365e4c" /><line x1="2" y1={cy} x2="13" y2={cy} stroke="#365e4c" />
    {chart && <text x="8" y={cy - 9} fontSize="7" fill="#365e4c">ASC</text>}
  </svg>;
}
