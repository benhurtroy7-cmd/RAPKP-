package com.rapkp.one;

import static org.junit.Assert.*;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Device-only checks, supplied for the owner's validation. Not claimed as executed in CI. */
@RunWith(AndroidJUnit4.class)
public class DevicePolicyInstrumentedTest {
    @Test public void correctPackageAndBackupPolicy() {
        Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertTrue(c.getPackageName().startsWith("com.rapkp.one"));
        assertEquals(0,c.getApplicationInfo().flags & ApplicationInfo.FLAG_ALLOW_BACKUP);
    }
    @Test public void androidKeystoreRoundTripWithoutExportableKey() throws Exception {
        String alias="rapkp.device-test."+System.nanoTime();
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        try {
            KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
            SecretKey key=g.generateKey();assertNull(key.getEncoded());
            byte[] data="Synthetic test token, not a real credential".getBytes(StandardCharsets.UTF_8);
            ConnectionCipher.Envelope e=ConnectionCipher.seal(key,data);
            assertArrayEquals(data,ConnectionCipher.open(key,e.iv,e.ciphertext));
        } finally {if(store.containsAlias(alias))store.deleteEntry(alias);}
    }
}
