#!/usr/bin/env python3
"""Bundle source only, no ephemeris library/binary/data and no secrets."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'frontend/android/app/src/main/assets/termux'
DEST.mkdir(parents=True,exist_ok=True)
# Keep this list in sync with what rapkp.report imports at runtime. report.py
# imports source_rules (the supplied structural step layer), so a bundle without it
# installs a connector that cannot start on the phone.
FILES=['__init__.py','constants.py','errors.py','kp.py','dasha.py','timeutils.py','rules.py','report.py','source_rules.py']
p=DEST/'backend.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in FILES:z.write(ROOT/'backend/rapkp'/name,'rapkp/'+name)
    for path in (ROOT/'backend/rapkp/termux_runtime').glob('*.py'):z.write(path,'rapkp/termux_runtime/'+path.name)
    z.write(ROOT/'termux-connector/run.py','run.py')
    z.write(ROOT/'LICENSE','LICENSE.shared-code.txt')
    z.write(ROOT/'termux-connector/LICENSING.md','LICENSING.md')
    if (ROOT/'licenses/AGPL-3.0.txt').exists():z.write(ROOT/'licenses/AGPL-3.0.txt','AGPL-3.0.txt')
(DEST/'bootstrap.py').write_bytes((ROOT/'termux-connector/bootstrap.py').read_bytes())
metadata={'version':'26.3.2-termux.1','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'port':8765,'scope':'Source-only connector. Existing phone ephemeris modules/data are reused; model API key configured separately.'}
assert p.stat().st_size<140000,'Keep RUN_COMMAND extras below Android IPC limits'
(DEST/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Termux connector bundle',metadata)
