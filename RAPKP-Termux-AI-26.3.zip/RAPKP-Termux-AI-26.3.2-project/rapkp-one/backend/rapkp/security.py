import hashlib
import hmac
import time
from collections import OrderedDict
from threading import Lock

from fastapi import HTTPException
from starlette.responses import JSONResponse


class RateLimiter:
    def __init__(self, limit: int, redis_url: str = ""):
        self.limit = limit
        self.lock = Lock()
        self.buckets: OrderedDict = OrderedDict()
        self.remote = None
        if redis_url:
            import redis

            self.remote = redis.Redis.from_url(
                redis_url, socket_timeout=2, socket_connect_timeout=2, decode_responses=True
            )

    def check(self, identity: str):
        now = time.time()
        window = int(now // 60)
        digest = hashlib.sha256(identity.encode()).hexdigest()[:24]
        key = f"rapkp:rate:{window}:{digest}"
        if self.remote is not None:
            try:
                count = int(
                    self.remote.eval(
                        "local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],120) end; return n",
                        1,
                        key,
                    )
                )
            except Exception as e:
                raise HTTPException(
                    503,
                    detail={
                        "code": "THROTTLE_UNAVAILABLE",
                        "message": "Shared rate limiter unavailable; requests are not bypassed.",
                    },
                ) from e
        else:
            with self.lock:
                expired = [k for k in self.buckets if int(k.split(":")[2]) < window - 1]
                for k in expired:
                    self.buckets.pop(k, None)
                count = self.buckets.get(key, 0) + 1
                self.buckets[key] = count
                # Bound memory without allowing fresh identities to evict existing limits.
                if len(self.buckets) > 10000:
                    self.buckets.pop(key, None)
                    raise HTTPException(
                        503, detail={"code": "THROTTLE_CAPACITY", "message": "Rate limiter capacity reached."}
                    )
        if count > self.limit:
            raise HTTPException(
                429,
                detail={"code": "RATE_LIMIT", "message": "Too many requests. Wait before retrying."},
                headers={"Retry-After": str(max(1, 60 - int(now % 60)))},
            )


def check_bearer(authorization: str, expected: str, required: bool):
    if not required and not expected:
        return
    prefix, _, token = authorization.partition(" ")
    if prefix.lower() != "bearer" or not expected or not hmac.compare_digest(token.encode(), expected.encode()):
        raise HTTPException(
            401,
            detail={"code": "AUTH_REQUIRED", "message": "A valid server API token is required."},
            headers={"WWW-Authenticate": "Bearer"},
        )


class RequestSizeLimit:
    """Limit streaming request bodies, including requests without Content-Length."""

    def __init__(self, app, max_bytes: int = 32768):
        self.app, self.max_bytes = app, max_bytes

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("method") not in {"POST", "PUT", "PATCH"}:
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers", []))
        if b"content-length" in headers:
            try:
                length = int(headers[b"content-length"])
                if length < 0:
                    raise ValueError
            except ValueError:
                return await JSONResponse({"error": {"code": "INVALID_CONTENT_LENGTH"}}, status_code=400)(
                    scope, receive, send
                )
            if length > self.max_bytes:
                return await JSONResponse(
                    {"error": {"code": "BODY_TOO_LARGE", "message": "Maximum body size is 32 KiB."}}, status_code=413
                )(scope, receive, send)
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            body.extend(message.get("body", b""))
            if len(body) > self.max_bytes:
                return await JSONResponse(
                    {"error": {"code": "BODY_TOO_LARGE", "message": "Maximum body size is 32 KiB."}}, status_code=413
                )(scope, receive, send)
            if not message.get("more_body", False):
                break
        replayed = False

        async def replay():
            nonlocal replayed
            if not replayed:
                replayed = True
                return {"type": "http.request", "body": bytes(body), "more_body": False}
            return await receive()

        await self.app(scope, replay, send)
