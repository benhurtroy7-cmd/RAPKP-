# BOT Handover Checklist

## Build phase

- [ ] Confirm client branding name
- [ ] Confirm logo/theme color
- [ ] Configure backend URL
- [ ] Configure token/license key
- [ ] Build signed APK
- [ ] Deploy backend to Render/Railway/VPS
- [ ] Test /health
- [ ] Test /api/ask
- [ ] Test chart PDF
- [ ] Test PDF reading
- [ ] Test correction/rules

## Operate phase

- [ ] Monitor bugs
- [ ] Review corrections
- [ ] Add prediction rules
- [ ] Export/backup data weekly
- [ ] Confirm cloud uptime
- [ ] Handle customer feedback

## Transfer phase

- [ ] Transfer GitHub repo
- [ ] Transfer Render/Railway project or deployment guide
- [ ] Transfer APK signing notes
- [ ] Transfer database dump
- [ ] Transfer environment variables
- [ ] Provide admin token
- [ ] Provide runbook
- [ ] Provide disclaimer/privacy docs
