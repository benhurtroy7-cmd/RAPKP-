import { defineConfig, devices } from '@playwright/test';
import path from 'node:path';
export default defineConfig({
  testDir: './tests', testMatch: '**/termux.spec.ts', timeout: 45000, expect: { timeout: 10000 }, fullyParallel: false, workers: 1,
  reporter: [['list'], ['json', { outputFile: '../qa/playwright-results.json' }]],
  use: { baseURL: 'http://127.0.0.1:8000', serviceWorkers: 'block', trace: 'retain-on-failure', screenshot: 'only-on-failure' },
  projects: [
    { name: 'desktop-chromium', use: { viewport: { width: 1440, height: 1000 } } },
    { name: 'mobile-viewport', use: { ...devices['Pixel 7'] } },
  ],
  webServer: {
    command: 'python -m uvicorn rapkp.api:create_app --factory --host 0.0.0.0 --port 8000 --no-access-log',
    cwd: path.resolve(import.meta.dirname, '..'),
    env: { RAPKP_ENV: 'test', RAPKP_RATE_LIMIT: '10000', PYTHONPATH: 'backend' },
    url: 'http://127.0.0.1:8000/health/ready', reuseExistingServer: !process.env.CI, timeout: 60000,
  },
});
