#!/usr/bin/env python3
"""Collect installed distribution notices and inventory metadata for this build."""
import json
import re
from importlib.metadata import distribution
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    inventory=[]
    for line in (ROOT/'requirements-lock.txt').read_text().splitlines():
        if not line or line.startswith('#'):continue
        name,version=line.split('==',1)
        dist=distribution(name)
        notices=[]
        for f in dist.files or []:
            fname=Path(str(f)).name.lower()
            if re.match(r'^(licen[sc]e|copying|notice|copyright)(\.|$|[-_])',fname):
                source=Path(dist.locate_file(f))
                if not source.is_file():continue
                # The license directory might include vendored notices; preserve each.
                relative=str(f).replace('/','__')
                target=ROOT/'licenses/python'/name/relative
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(source.read_bytes())
                notices.append(str(target.relative_to(ROOT)))
        license_id=dist.metadata.get('License-Expression') or dist.metadata.get('License') or 'See license files/classifiers'
        if len(license_id)>250:license_id='See full licence text in licenses/python/'+name
        inventory.append({'ecosystem':'pypi','name':name,'version':version,'license_metadata':license_id,'notices':notices})
    lock=json.loads((ROOT/'frontend/package-lock.json').read_text())
    for relative,meta in lock['packages'].items():
        if not relative:continue
        source=ROOT/'frontend'/relative
        if not (source/'package.json').is_file():continue
        package=json.loads((source/'package.json').read_text())
        name=package['name'];version=package['version'];notices=[]
        for f in source.iterdir():
            if f.is_file() and re.match(r'^(licen[sc]e|copying|notice|copyright)(\.|$|[-_])',f.name,re.I):
                target=ROOT/'licenses/npm'/name.replace('/','__')/f'{version}__{f.name}'
                target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes());notices.append(str(target.relative_to(ROOT)))
        inventory.append({'ecosystem':'npm','name':name,'version':version,'development_only':bool(meta.get('dev')),'license_metadata':package.get('license',meta.get('license','See package notices')),'notices':notices})
    (ROOT/'licenses/dependency-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
    print(f'Collected {len(inventory)} dependency records and retained installed notice files.')


if __name__=='__main__':main()
