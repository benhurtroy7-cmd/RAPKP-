> Historical/general baseline. The current release is Termux-only; use TERMUX_AI_START.md, API_TERMUX.md and QA_TERMUX_AI.md. Native automation/live-account/device limits and AGPL engine terms there take precedence.

# API and command contract

## Main request

`POST /api/v1/readings` with `Content-Type: application/json`. In protected mode use `Authorization: Bearer <token>`.

```json
{
  "birth": {
    "date": "1990-06-15",
    "time": "10:30:00",
    "place": {"label": "Chennai, India", "latitude": 13.0827, "longitude": 80.2707, "timezone": "Asia/Kolkata"},
    "uncertainty_seconds": 60
  },
  "analysis": {
    "date": "2026-09-30",
    "time": "12:00:00",
    "place": {"label": "Chennai, India", "latitude": 13.0827, "longitude": 80.2707, "timezone": "Asia/Kolkata"}
  },
  "domain": "career",
  "question": "Explore the connections in this synthetic example.",
  "node_mode": "mean",
  "include_transits": true
}
```

Birth and analysis locations are separate on purpose. Add `fold: 0` or `fold: 1` within the relevant moment only when resolving a repeated DST time. No automatic timezone/geocoder API is used. The UI's small city list is an explicit convenience; confirm coordinates yourself.

Response: versioned report with chart, nine bodies, twelve cusps, Dasha/Bhukti/Antara, future antara boundaries, ruling planets, link traces, baseline assessment, sensitivity, warnings and validation statuses. `assessment.probability` is **null** and `binary_answer` is **NOT DETERMINED** in this release. The server creates no persistent report record.

## Other routes

| Route | Purpose |
|---|---|
| `GET /health/live` | Process liveness |
| `GET /health/ready` | Kernel and configured shared limiter readiness |
| `GET /api/v1/status` | Version, execution mode, truthful integration/readiness/QA summary |
| `GET /api/v1/domains` | Supported, explicitly sourced domain house sets |
| `GET /api/v1/rules` | Baseline sequence and 21 disabled source-rule slots |
| `GET /api/v1/horary/{1..249}` | Segment lookup only; auth/rate limits apply |
| `POST /api/ask` | Structured backward-path alias, not a natural-language profile parser |
| `GET /api/ask?query=...` | Returns 400: structured inputs required; no default personal profile |
| `POST /api/report_bug` | Consent-gated report preparation only; no storage or Arena upload |
| `GET /openapi.json` | Machine-readable current API schema; never contains service secrets |

Key statuses: **401** authentication, **413** body size, **422** invalid/unsupported inputs, **429** rate/compute limit (Retry-After), **503** unavailable/corrupt engine or limiter. A response never silently substitutes a different ephemeris or house system.

The public Action schema is in `integrations/chatgpt/openapi.json`; replace its server URL. The internal full schema is in `integrations/openapi-full.json`. Do not place API keys in a query string.

## Output provenance

`report_id` hashes normalised request content, application version and the kernel digest. It assists deterministic comparison but is **not signed**, not authentication, and not anonymisation. Preserve the app/kernel/ruleset version and input conventions when comparing outputs. Generated timestamps naturally differ across repeated requests.
