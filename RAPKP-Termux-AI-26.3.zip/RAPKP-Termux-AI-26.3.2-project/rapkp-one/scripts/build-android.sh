#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${JAVA_HOME:?Set JAVA_HOME to JDK 21 or newer}"
export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
: "${ANDROID_HOME:?Set ANDROID_HOME to an installed Android SDK with platform 36}"
export PATH="$JAVA_HOME/bin:$PATH"
node -e 'const v=process.versions.node.split(".").map(Number);if(v[0]<22||(v[0]===22&&v[1]<12))throw new Error("Node 22.12+ required")'
npm ci --prefix frontend --no-fund --no-audit
npm run native:sync --prefix frontend
(cd frontend/android && chmod +x gradlew && ./gradlew --no-daemon --max-workers=1 '-Dorg.gradle.jvmargs=-Xmx512m -XX:MaxMetaspaceSize=512m' -Pandroid.experimental.lint.heapSize=384m :app:assembleDebug :app:bundleRelease :app:testDebugUnitTest)
(cd frontend/android && ./gradlew --no-daemon --max-workers=1 '-Dorg.gradle.jvmargs=-Xmx512m -XX:MaxMetaspaceSize=512m' -Pandroid.experimental.lint.heapSize=384m :app:lintDebug)
mkdir -p native-artifacts/android
cp frontend/android/app/build/outputs/apk/debug/app-debug.apk native-artifacts/android/RAPKP-Termux-AI-26.3.2.apk
cp frontend/android/app/build/outputs/bundle/release/app-release.aab native-artifacts/android/RAPKP-Termux-AI-26.3.2-unsigned.aab
printf '\nBuilt preview APK and unsigned release AAB. Physical-device tests and owner release signing are separate.\n'
