import base64
import hashlib
import hmac
import io
import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

import pytest
from rapkp.config import ROOT
from rapkp.errors import CalculationError
from rapkp.models import ReadingRequest
from rapkp.report import create_report
from rapkp.termux_runtime.ai import SCHEMA, interpret
from rapkp.termux_runtime.contracts import parse_request
from rapkp.termux_runtime.providers import SwissAdapter
from rapkp.termux_runtime.server import State, atomic_json


def test_lite_contract_matches_typed_contract(payload):
    assert parse_request(payload).model_dump() == ReadingRequest.model_validate(payload).model_dump(mode="json")


@pytest.mark.parametrize(
    "mutate",
    [
        lambda p: p.update(extra="no"),
        lambda p: p["birth"].update(fold=True),
        lambda p: p["birth"]["place"].update(latitude=float("nan")),
        lambda p: p["birth"].update(time="09:00+05:30"),
        lambda p: p.update(node_mode="fake"),
        lambda p: p.update(include_transits="yes"),
        lambda p: p.update(question="x" * 601),
    ],
)
def test_lite_contract_fails_closed(payload, mutate):
    mutate(payload)
    with pytest.raises(CalculationError):
        parse_request(payload)


def test_swiss_missing_data_is_not_moshier(tmp_path):
    pytest.importorskip("swisseph")
    with pytest.raises(CalculationError) as e:
        SwissAdapter("swisseph", str(tmp_path))
    assert e.value.code == "EPHEMERIS_FILES_MISSING"


def test_swiss_explicit_qa_mode_has_truthful_metadata(payload):
    pytest.importorskip("swisseph")
    e = SwissAdapter("swisseph", allow_moshier=True)
    r = create_report(e, parse_request(payload))
    assert r["calculation"]["kernel_sha256"] is None
    assert r["verification"][1]["status"] == "recorded"
    assert any("Moshier mode" in x for x in r["warnings"])
    assert r["chart"]["bodies"]["Ketu"]["speed"] == r["chart"]["bodies"]["Rahu"]["speed"]


@pytest.mark.parametrize("lat", [66, -66, 80])
def test_provider_never_substitutes_polar_houses(lat):
    pytest.importorskip("swisseph")
    e = SwissAdapter("swisseph", allow_moshier=True)
    with pytest.raises(CalculationError) as r:
        e.calculate_at_ut1(2451545, lat, 0)
    assert r.value.code == "PLACIDUS_LATITUDE"


def valid_ai(report):
    return {
        "report_id": report["report_id"],
        "summary": "Within this symbolic framework, consider the available connections; no guaranteed outcome is established.",
        "themes": [
            {
                "title": "Career context",
                "interpretation": "Review the tenth cusp together with the active period.",
                "evidence_ids": ["cusp:10", "period:mahadasha"],
            }
        ],
        "timing_context": "The listed period boundaries are context, not event forecasts.",
        "practical_steps": ["Use actual work opportunities and evidence."],
        "limitations": ["Missing complete 21-rule definitions; no calibrated probability."],
    }


@pytest.mark.parametrize("provider,model", [("openai", "gpt-6-astra"), ("gemini", "gemini-3.8-flash")])
def test_ai_request_is_grounded_and_key_not_in_prompt(provider, model):
    report = json.loads((ROOT / "qa/sample-report.json").read_text())
    calls = []

    def opener(req, timeout):
        calls.append(req)
        body = json.loads(req.data)
        assert "private-provider-key" not in req.data.decode()
        answer = valid_ai(report)
        if provider == "openai":
            assert req.full_url == "https://api.openai.com/v1/responses"
            assert body["store"] is False and body["model"] == model
            assert body["text"]["format"]["schema"] == SCHEMA
            return io.BytesIO(
                json.dumps(
                    {"output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(answer)}]}]}
                ).encode()
            )
        assert "x-goog-api-key" in {k.lower() for k in req.headers}
        return io.BytesIO(json.dumps({"candidates": [{"content": {"parts": [{"text": json.dumps(answer)}]}}]}).encode())

    result = interpret(
        report, {"provider": provider, "model": model, "api_key": "private-provider-key", "consent": True}, opener
    )
    assert len(calls) == 1 and result["status"] == "completed"
    assert result["prediction_probability"] is None and result["prose_fact_checked"] is False


def test_ai_does_not_call_without_consent_or_key():
    report = json.loads((ROOT / "qa/sample-report.json").read_text())

    def never(*a, **k):
        raise AssertionError("network was called")

    for cfg in [{"api_key": "", "consent": True}, {"api_key": "x", "consent": False}]:
        with pytest.raises(CalculationError):
            interpret(report, cfg, never)


@pytest.mark.parametrize(
    "status,code",
    [
        (401, "AI_AUTH"),
        (403, "AI_AUTH"),
        (404, "AI_MODEL_UNAVAILABLE"),
        (429, "AI_RATE_LIMIT"),
        (500, "AI_PROVIDER_ERROR"),
    ],
)
def test_ai_error_does_not_leak_provider_body(status, code):
    report = json.loads((ROOT / "qa/sample-report.json").read_text())

    def broken(*args, **kwargs):
        raise urllib.error.HTTPError(
            "https://api.openai.com", status, "private key was sk-secret-value", {}, io.BytesIO(b"secret")
        )

    with pytest.raises(CalculationError) as e:
        interpret(report, {"provider": "openai", "model": "gpt-6-astra", "api_key": "key", "consent": True}, broken)
    assert e.value.code == code and "secret" not in e.value.message


@pytest.mark.parametrize(
    "change",
    [
        lambda r: r.update(report_id="forged"),
        lambda r: r["themes"][0].update(evidence_ids=["planet:Invented"]),
        lambda r: r.update(summary="Success probability is 99%"),
    ],
)
def test_ai_unsupported_output_is_rejected(change):
    report = json.loads((ROOT / "qa/sample-report.json").read_text())
    answer = valid_ai(report)
    change(answer)

    def opener(*a, **k):
        return io.BytesIO(
            json.dumps(
                {"output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(answer)}]}]}
            ).encode()
        )

    with pytest.raises(CalculationError):
        interpret(report, {"provider": "openai", "model": "gpt-6-astra", "api_key": "key", "consent": True}, opener)


def test_provider_change_does_not_forward_old_key(tmp_path):
    atomic_json(
        tmp_path / "config.json",
        {
            "token": "x" * 64,
            "ephemeris": {"provider": "swisseph", "qa_moshier": True},
            "ai": {"provider": "openai", "model": "gpt-6-astra", "api_key": "openai-only", "consent": True},
        },
    )
    s = State(tmp_path, testing=True)
    try:
        status = s.settings({"ai": {"provider": "gemini", "model": "gemini-3.8-flash", "consent": True}})
        assert status["ai"]["key_present"] is False
        assert "openai-only" not in json.dumps(status)
    finally:
        s.close()


def test_async_job_reuse_does_not_repeat_paid_request(tmp_path):
    import threading

    started = threading.Event()
    release = threading.Event()
    calls = []

    def fake(report, config):
        calls.append(report["report_id"])
        started.set()
        release.wait(5)
        return {"status": "completed", "answer": valid_ai(report), "report_id": report["report_id"]}

    atomic_json(
        tmp_path / "config.json",
        {
            "token": "x" * 64,
            "ephemeris": {"provider": "swisseph", "qa_moshier": True},
            "ai": {"provider": "openai", "model": "gpt-6-astra", "api_key": "test", "consent": True},
        },
    )
    s = State(tmp_path, testing=True, ai_callable=fake)
    try:
        report = json.loads((ROOT / "qa/sample-report.json").read_text())
        s.reports[report["report_id"]] = (time.monotonic(), report)
        a = s.submit_ai({"report_id": report["report_id"], "consent": True})
        assert started.wait(5)
        b = s.submit_ai({"report_id": report["report_id"], "consent": True})
        assert a["job_id"] == b["job_id"]
        assert len(calls) == 1
        assert s.get_job(a["job_id"])["status"] == "running"
    finally:
        release.set()
        s.close()


def test_bootstrap_bundle_installs_private_config_without_replacing_libraries(tmp_path):
    import base64
    import hashlib
    import os
    import subprocess
    import sys

    bundle = (ROOT / "frontend/android/app/src/main/assets/termux/backend.zip").read_bytes()
    payload = {
        "token": "a" * 64,
        "version": "26.3.2-termux.1",
        "bundle": base64.b64encode(bundle).decode(),
        "sha256": hashlib.sha256(bundle).hexdigest(),
    }
    marker = tmp_path / "existing-ephemeris"
    marker.write_text("preserve")
    p = subprocess.run(
        [sys.executable, str(ROOT / "termux-connector/bootstrap.py")],
        input=json.dumps(payload),
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=15,
    )
    assert p.returncode == 0, p.stdout + p.stderr
    assert json.loads(p.stdout)["ok"] is True
    cfg = tmp_path / ".rapkp-one/config.json"
    assert (cfg.stat().st_mode & 0o777) == 0o600
    assert marker.read_text() == "preserve"
    assert (tmp_path / ".termux/boot/90-rapkp-one").is_file()
    assert "token" not in p.stdout and "a" * 64 not in p.stdout


# --- Regression tests for the 26.3 pairing dead-end -------------------------------
# An installed connector kept port 8765 after its config was removed, so every later
# pairing verified against the old key forever ("not the paired RAPKP connector").
BOOTSTRAP = ROOT / "termux-connector/bootstrap.py"
BUNDLE = (ROOT / "frontend/android/app/src/main/assets/termux/backend.zip").read_bytes()
LOCAL = "http://127.0.0.1:8765"


def _port_free():
    with socket.socket() as s:
        try:
            s.bind(("127.0.0.1", 8765))
            return True
        except OSError:
            return False


def _run_bootstrap(home, token):
    payload = {
        "token": token,
        "version": "26.3.2-termux.1",
        "bundle": base64.b64encode(BUNDLE).decode(),
        "sha256": hashlib.sha256(BUNDLE).hexdigest(),
    }
    return subprocess.run(
        [sys.executable, str(BOOTSTRAP)],
        input=json.dumps(payload),
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(home)},
        timeout=90,
    )


def _app_verify(token):
    """Exactly what the APK does before it will send a token or a request."""
    nonce = secrets.token_hex(16)
    with urllib.request.urlopen(f"{LOCAL}/health/challenge?nonce={nonce}", timeout=4) as r:
        data = json.load(r)
    expected = hmac.new(token.encode(), ("rapkp-server-v1\n" + nonce).encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(data.get("proof", ""), expected)


def _alive():
    try:
        with urllib.request.urlopen(LOCAL + "/health/live", timeout=2) as r:
            return json.load(r)
    except Exception:
        return None


def _wait_alive(seconds=25):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if _alive():
            return True
        time.sleep(0.2)
    return False


def _stop(token):
    try:
        req = urllib.request.Request(
            LOCAL + "/api/v1/control/stop",
            data=b"{}",
            headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass
    end = time.monotonic() + 10
    while time.monotonic() < end and _alive():
        time.sleep(0.2)


def _start(home):
    log = open(home / ".rapkp-one/service.log", "ab")
    return subprocess.Popen(
        [sys.executable, str(home / ".rapkp-one/start.py")],
        stdout=log,
        stderr=log,
        env={**os.environ, "HOME": str(home)},
    )


@pytest.mark.skipif(not _port_free(), reason="port 8765 is busy in this environment")
def test_repair_reclaims_port_after_connector_home_was_removed(tmp_path):
    """The user-visible bug: re-pairing could never recover the port again."""
    first = secrets.token_hex(32)
    second = secrets.token_hex(32)
    p = _run_bootstrap(tmp_path, first)
    assert p.returncode == 0, p.stdout + p.stderr
    proc = _start(tmp_path)
    try:
        assert _wait_alive()
        assert _app_verify(first)
        # Advice previously given for a stuck pairing: remove the connector home.
        # The already-running service keeps the port and the old key.
        shutil.rmtree(tmp_path / ".rapkp-one")
        p2 = _run_bootstrap(tmp_path, second)
        assert p2.returncode == 0, p2.stdout + p2.stderr
        proc2 = _start(tmp_path)
        try:
            assert _wait_alive(), "the fresh connector never took over the port"
            assert _app_verify(second), "the app still cannot verify its own pairing"
        finally:
            proc2.kill()
    finally:
        proc.kill()
        _stop(second)


@pytest.mark.skipif(not _port_free(), reason="port 8765 is busy in this environment")
def test_repair_reclaims_port_when_stored_token_differs_from_running_instance(tmp_path):
    """An orphan whose key no longer matches config.json is stopped without a token."""
    first = secrets.token_hex(32)
    p = _run_bootstrap(tmp_path, first)
    assert p.returncode == 0, p.stdout + p.stderr
    proc = _start(tmp_path)
    try:
        assert _wait_alive()
        config = tmp_path / ".rapkp-one/config.json"
        stored = json.loads(config.read_text())
        stored["token"] = secrets.token_hex(32)  # config rewritten by another pairing
        config.write_text(json.dumps(stored))
        p2 = _run_bootstrap(tmp_path, secrets.token_hex(32))
        assert p2.returncode == 0, p2.stdout + p2.stderr
        proc2 = _start(tmp_path)
        try:
            assert _wait_alive(), "the orphan kept the port"
            assert _app_verify(json.loads(config.read_text())["token"])
        finally:
            proc2.kill()
    finally:
        proc.kill()
        _stop(json.loads((tmp_path / ".rapkp-one/config.json").read_text())["token"])


@pytest.mark.skipif(not _port_free(), reason="port 8765 is busy in this environment")
def test_bootstrap_never_replaces_a_foreign_service_on_the_port(tmp_path):
    """Only a RAPKP instance is ever stopped; another service is left completely alone."""
    import http.server

    class Foreign(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body = json.dumps({"product": "Some Other Local Service"}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    foreign = http.server.ThreadingHTTPServer(("127.0.0.1", 8765), Foreign)
    thread = threading.Thread(target=foreign.serve_forever, daemon=True)
    thread.start()
    try:
        p = _run_bootstrap(tmp_path, secrets.token_hex(32))
        assert p.returncode != 0
        assert "another service" in p.stdout
        assert not (tmp_path / ".rapkp-one/config.json").exists()
        with urllib.request.urlopen(LOCAL + "/health/live", timeout=2) as r:
            assert json.load(r)["product"] == "Some Other Local Service"
    finally:
        foreign.shutdown()
        foreign.server_close()
        thread.join(timeout=5)


def test_stop_request_only_from_a_fresh_signal_and_file_is_consumed(tmp_path):
    import httpx
    from rapkp.termux_runtime.server import Server

    atomic_json(
        tmp_path / "config.json",
        {"token": "c" * 64, "ephemeris": {"provider": "swisseph"}, "ai": {"provider": "openai", "model": "gpt-6-astra"}},
    )
    state = State(tmp_path)
    server = Server(("127.0.0.1", 0), state)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        # A request file left over from an interrupted run must not kill a new service.
        stale = tmp_path / "stop-request"
        stale.write_text("")
        old = time.time() - 600
        os.utime(stale, (old, old))
        with httpx.Client(base_url=f"http://127.0.0.1:{server.server_port}", timeout=5) as c:
            assert c.get("/health/live").status_code == 200
            time.sleep(1.0)
            assert c.get("/health/live").status_code == 200
            assert thread.is_alive()
            # A request that arrives before the shutdown hook is wired must be kept,
            # not lost and not crash the service.
            stale.write_text("")
            time.sleep(1.0)
            assert c.get("/health/live").status_code == 200
            state.stop_hook = server.shutdown
            deadline = time.monotonic() + 8
            while time.monotonic() < deadline and thread.is_alive():
                time.sleep(0.1)
        assert not thread.is_alive()
        assert not stale.exists()
    finally:
        server.shutdown()
        server.server_close()
        state.close()
        thread.join(timeout=5)


def test_http_server_auth_size_jobs_and_settings(tmp_path):
    import threading

    import httpx
    from rapkp.termux_runtime.server import Server

    token = "b" * 64
    atomic_json(
        tmp_path / "config.json",
        {
            "token": token,
            "ephemeris": {"provider": "swisseph"},
            "ai": {"provider": "openai", "model": "gpt-6-astra", "api_key": "never-return-this", "consent": True},
        },
    )
    state = State(tmp_path)
    server = Server(("127.0.0.1", 0), state)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        base = f"http://127.0.0.1:{server.server_port}"
        with httpx.Client(base_url=base, timeout=10) as c:
            assert c.get("/health/live").status_code == 200
            assert c.get("/api/v1/status").status_code == 401
            headers = {"Authorization": "Bearer " + token}
            status = c.get("/api/v1/status", headers=headers)
            assert status.status_code == 200
            assert "never-return-this" not in status.text and token not in status.text
            assert c.get("/api/v1/horary/249", headers=headers).status_code == 200
            assert c.get("/api/v1/horary/250", headers=headers).status_code == 422
            assert c.post("/api/v1/readings", headers=headers, content="x" * 40000).status_code == 413
            assert c.post("/api/v1/readings", headers=headers, content="{broken").status_code == 422
            assert (
                c.post("/api/v1/ai/jobs", headers=headers, json={"report_id": "missing", "consent": True}).status_code
                == 404
            )
            assert (
                c.post("/api/v1/settings", headers=headers, json={"ai": {"provider": "evil", "model": "x"}}).status_code
                == 422
            )
    finally:
        server.shutdown()
        server.server_close()
        state.close()
        thread.join(timeout=5)


def test_no_live_ai_in_unprotected_demo(tmp_path):
    atomic_json(
        tmp_path / "config.json",
        {
            "token": "a" * 64,
            "ephemeris": {"provider": "swisseph", "qa_moshier": True},
            "ai": {"provider": "openai", "model": "gpt-6-astra", "api_key": "fake", "consent": True},
        },
    )
    state = State(tmp_path, testing=True)
    try:
        report = json.loads((ROOT / "qa/sample-report.json").read_text())
        state.reports[report["report_id"]] = (time.monotonic(), report)
        job = state.submit_ai({"report_id": report["report_id"], "consent": True})
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            result = state.get_job(job["job_id"])
            if result["status"] == "failed":
                break
            time.sleep(0.01)
        assert result["error"]["code"] == "AI_DEMO_DISABLED"
    finally:
        state.close()


def test_libephemeris_default_local_backend_is_computable():
    pytest.importorskip("libephemeris")
    engine = SwissAdapter("libephemeris")
    a = engine.calculate_at_ut1(2451545.0, 13.08, 80.27, "true")
    assert len(a["bodies"]) == 9 and len(a["cusps"]) == 12
    assert engine.report_metadata["ephemeris_files_sha256"]
    assert a["bodies"]["Ketu"]["speed"] == a["bodies"]["Rahu"]["speed"]


def test_local_service_complete_http_path(tmp_path, payload):
    import threading

    import httpx
    from rapkp.termux_runtime.server import Server

    atomic_json(
        tmp_path / "config.json",
        {
            "token": "e" * 64,
            "ephemeris": {"provider": "swisseph", "qa_moshier": True},
            "ai": {"provider": "openai", "model": "gpt-6-astra", "api_key": "fake-test", "consent": True},
        },
    )

    def fake(report, config):
        return {"status": "completed", "report_id": report["report_id"], "answer": valid_ai(report)}

    state = State(tmp_path, testing=True, ai_callable=fake)
    deadline = time.monotonic() + 5
    while state.engine is None and time.monotonic() < deadline:
        time.sleep(0.01)
    assert state.engine is not None, state.engine_error
    server = Server(("127.0.0.1", 0), state)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        with httpx.Client(base_url=f"http://127.0.0.1:{server.server_port}", timeout=10) as c:
            assert c.get("/health/ready").status_code == 200
            assert c.get("/api/v1/rules").status_code == 200
            assert c.get("/api/v1/domains").status_code == 200
            assert c.get("/unknown").status_code == 404
            report = c.post("/api/v1/readings", json=payload)
            assert report.status_code == 200, report.text
            rid = report.json()["report_id"]
            job = c.post("/api/v1/ai/jobs", json={"report_id": rid, "consent": True})
            assert job.status_code == 202
            jid = job.json()["job_id"]
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                result = c.get("/api/v1/ai/jobs/" + jid).json()
                if result["status"] == "completed":
                    break
                time.sleep(0.01)
            assert result["result"]["report_id"] == rid
            bad = c.post("/api/v1/settings", json={"ephemeris": {"provider": "invalid"}})
            assert bad.status_code == 422
            good = c.post(
                "/api/v1/settings",
                json={
                    "ai": {
                        "provider": "openai",
                        "model": "gpt-6.1-sol",
                        "api_key": "",
                        "consent": False,
                        "language": "Tamil",
                    }
                },
            )
            assert good.status_code == 200 and good.json()["ai"]["key_present"]
            assert c.post("/api/v1/ai/jobs", json={"report_id": rid, "consent": True}).status_code == 409
            assert c.post("/api/v1/settings", json={"ai": {"clear_key": True}}).status_code == 200
            assert c.post("/api/v1/ai/jobs", json={"report_id": rid, "consent": True}).status_code == 409
            changed = c.post(
                "/api/v1/settings", json={"ephemeris": {"provider": "libephemeris", "path": "", "lib_file": ""}}
            )
            assert changed.status_code == 200
            raw = json.dumps(payload).encode()

            def chunks():
                yield raw[:50]
                yield raw[50:]

            # Wait for the asynchronous provider check, not a fabricated ready flag.
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                if c.get("/health/ready").status_code == 200:
                    break
                time.sleep(0.02)
            assert (
                c.post("/api/v1/readings", content=chunks(), headers={"Content-Type": "application/json"}).status_code
                == 200
            )
            assert c.post("/api/v1/control/stop", json={}).status_code == 200
    finally:
        server.shutdown()
        server.server_close()
        state.close()
        t.join(timeout=3)


@pytest.mark.parametrize(
    "settings", [{"provider": "not-real"}, {"provider": "libephemeris", "lib_file": "/definitely/missing.bsp"}]
)
def test_provider_config_missing_files_fails(settings):
    with pytest.raises(CalculationError):
        SwissAdapter(**settings)


# --- Supplied structural KP steps (user-supplied public outline, 2026-10-03) -------
def test_supplied_structural_steps_are_evaluated_with_evidence(tmp_path):
    import sys

    sys.path.insert(0, str(ROOT / "backend"))
    from rapkp.config import ROOT as BACKEND_ROOT
    from rapkp.engine import AstroEngine
    from rapkp.models import ReadingRequest
    from rapkp.report import create_report
    from rapkp.rules import registry
    from rapkp.source_rules import registry as source_registry

    req = ReadingRequest.model_validate(json.loads((ROOT / "qa/sample-request.json").read_text()))
    report = create_report(AstroEngine(BACKEND_ROOT / "data/de440s.bsp"), req)
    ev = report["source_rule_evaluation"]

    assert [r["id"] for r in ev["rules"]] == [f"PROF-{i:02d}" for i in range(1, 11)]
    assert all(r["status"] in {"supported", "contradicted", "not_evaluable"} for r in ev["rules"])
    assert all(r["evidence"] for r in ev["rules"])
    # The count of checks must never read as a probability or a verdict.
    assert ev["probability"] is None and ev["is_probability"] is False
    assert ev["binary_answer"] == "NOT DETERMINED"
    assert "not a score" in ev["aggregate_meaning"]
    assert ev["counts"]["supported"] + ev["counts"]["contradicted"] + ev["counts"]["not_evaluable"] == 10

    # Every step keeps its supplied wording for auditability.
    assert all(r["supplied_step"] for r in ev["rules"])
    assert {r["group"] for r in ev["rules"]} == {
        "7 fundamental predictive steps",
        "4 advanced verification steps",
        "5 event-timing steps",
    }

    # Proxy steps are labelled, and the proxy orbs are disclosed constants.
    proxies = [r for r in ev["rules"] if r["proxy_basis"]]
    assert {r["id"] for r in proxies} == {"PROF-06", "PROF-07", "PROF-10"}
    assert all("PROXY BASIS" in r["note"] for r in proxies)

    # Gap accounting: the headings claim 16 steps, 10 were supplied, 11 user rules absent.
    sr = source_registry()
    assert (sr["claimed_professor_steps"], sr["supplied_professor_steps"], sr["missing_professor_steps"]) == (16, 10, 6)
    assert sr["user_rules_supplied"] == 0 and sr["user_rules_expected"] == 11
    assert sr["rule_slots_defined"] == 10 and sr["rule_slots_expected"] == 21
    assert sr["rule_slots_calibrated"] == 0
    assert sr["additional_claimed_steps_without_definition"] == 6
    # 10 implemented professor steps + 6 claimed-but-undefined steps + 11 undefined user rules.
    assert len(sr["pending_rules"]) == 27 and sr["pending_entries"] == 27
    assert sum(1 for r in sr["pending_rules"] if r["enabled"]) == 10
    assert "definition_not_supplied" in {r["status"] for r in sr["pending_rules"]}
    reg = registry()
    assert reg["source_rule_slots_defined"] == 10
    assert reg["source_rule_slots_calibrated"] == 0
    assert "10-step public structural outline" in reg["supplied_outline_scope"]


def test_structural_steps_fail_closed_without_transits(tmp_path):
    import sys

    sys.path.insert(0, str(ROOT / "backend"))
    from rapkp.config import ROOT as BACKEND_ROOT
    from rapkp.engine import AstroEngine
    from rapkp.models import ReadingRequest
    from rapkp.report import create_report

    payload = json.loads((ROOT / "qa/sample-request.json").read_text())
    payload["include_transits"] = False
    req = ReadingRequest.model_validate(payload)
    report = create_report(AstroEngine(BACKEND_ROOT / "data/de440s.bsp"), req)
    by_id = {r["id"]: r for r in report["source_rule_evaluation"]["rules"]}
    assert by_id["PROF-10"]["status"] == "not_evaluable"
    assert by_id["PROF-10"]["evidence"]["available"] is False
    assert by_id["PROF-10"]["probability"] is None


def test_dusthana_rule_reports_the_link_it_was_asked_to_check():
    import sys

    sys.path.insert(0, str(ROOT / "backend"))
    from rapkp.source_rules import DUSTHANAS, evaluate

    chart = {
        "bodies": {n: {"longitude": 10.0, "retrograde": False, "near_station": False, "house": 1, "star_lord": "Sun"} for n in ("Sun", "Moon", "Mars")},
        "cusps": [{"house": 1, "longitude": 0.0, "sign": "Aries", "sign_lord": "Mars", "star_lord": "Sun", "sub_lord": "Sun", "sub_sub_lord": "Sun"}],
    }
    sig = {"Sun": {"houses": [6, 8, 12], "hierarchy": []}, "Moon": {"houses": [2], "hierarchy": []}, "Mars": {"houses": [3], "hierarchy": []}}
    dasha = {
        "mahadasha": {"lord": "Sun"}, "bhukti": {"lord": "Moon"}, "antara": {"lord": "Mars"},
        "system": "Vimshottari", "year_days": 365.2425,
    }
    ruling = {"ascendant_sign_lord": "Mars", "ascendant_star_lord": "Sun", "ascendant_sub_lord": "Sun",
              "moon_sign_lord": "Moon", "moon_star_lord": "Sun", "day_lord": "Sun"}
    result = evaluate(chart, sig, [], dasha, ruling, {"label": "Test", "primary": 1, "supporting": [], "_birth_date": "1990-01-01"}, None, None)
    by_id = {r["id"]: r for r in result["rules"]}
    assert by_id["PROF-05"]["status"] == "supported"
    assert by_id["PROF-05"]["evidence"]["sub_lord_dusthana_houses"] == sorted(DUSTHANAS)
    assert by_id["PROF-05"]["evidence"]["link_found"] is True
    assert by_id["PROF-10"]["status"] == "not_evaluable"
    assert by_id["PROF-03"]["evidence"]["retrograde_lords"] == []


# --- Regression test for the packaged connector bundle ---------------------------
# The bundle is what actually runs on the phone. rapkp.report imports source_rules,
# so a bundle built without that module installs a connector that cannot start.
def test_packaged_bundle_imports_and_reports_the_supplied_steps(tmp_path):
    import zipfile

    bundle = ROOT / "frontend/android/app/src/main/assets/termux/backend.zip"
    assert bundle.is_file()
    with zipfile.ZipFile(bundle) as z:
        names = z.namelist()
        assert "rapkp/source_rules.py" in names, "report.py cannot be imported without it"
        z.extractall(tmp_path)
    manifest = json.loads((ROOT / "frontend/android/app/src/main/assets/termux/manifest.json").read_text())
    assert manifest["version"] == __import__("rapkp").__version__
    p = subprocess.run(
        [sys.executable, "-c", "from rapkp.termux_runtime.server import main; from rapkp.report import create_report; print('import ok')"],
        capture_output=True, text=True, cwd=tmp_path, timeout=120,
        env={**os.environ, "PYTHONPATH": str(tmp_path)},
    )
    assert p.returncode == 0, p.stdout + p.stderr
    assert "import ok" in p.stdout
