#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Keep on device loopback. Do not expose a no-auth Termux server publicly.
export RAPKP_BIND=127.0.0.1
export RAPKP_ENV="${RAPKP_ENV:-local}"
exec bash scripts/run-local.sh
