# Commercial Disclaimer and Privacy Template

## Disclaimer

This product provides astrology-based probability and timing analysis for guidance, research, and entertainment. Predictions are probabilistic and not guaranteed. Users should not make financial, medical, legal, or life-critical decisions solely based on the output.

## Privacy

The app may store birth details, questions, PDF text extracts, corrections, and prediction history in the configured cloud backend. The operator is responsible for securing user data and complying with local privacy laws.

## Data deletion

Customers should be allowed to request deletion of their chart/profile/prediction data.
