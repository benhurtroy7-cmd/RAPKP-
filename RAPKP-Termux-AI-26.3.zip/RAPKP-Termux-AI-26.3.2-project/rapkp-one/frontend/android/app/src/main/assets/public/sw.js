const CACHE='rapkp-ui-34e5dd623010';
const ASSETS=["/","/icon.svg","/icon-192.png","/icon-512.png","/manifest.webmanifest","/assets/index-CbV1Gb2I.css","/assets/index-D2yXMh1D.js","/assets/web-C-vS0ivo.js","/assets/web-C123CWFu.js"];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS))); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('rapkp-ui-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  // Never cache reports, POST bodies, credentials, health endpoints or external origins.
  if (e.request.method !== 'GET' || u.origin !== self.location.origin || u.pathname.startsWith('/api') || u.pathname.startsWith('/health') || e.request.headers.has('Authorization')) return;
  if (e.request.mode === 'navigate') { e.respondWith(fetch(e.request).catch(() => caches.match('/'))); return; }
  if (ASSETS.includes(u.pathname)) e.respondWith(caches.match(e.request).then(c => c || fetch(e.request)));
});
