package com.rapkp.one;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.json.JSONObject;

/** No telemetry. Only an explicitly requested connection is stored, encrypted at rest. */
@CapacitorPlugin(name="RapkpDevice")
public class RapkpDevicePlugin extends Plugin {
    private static final String ALIAS="rapkp.connection.v1";
    private final Object vaultLock=new Object();
    private SharedPreferences prefs() { return getContext().getSharedPreferences("rapkp.encrypted.connection",0); }
    private SecretKey key(boolean create) throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(ALIAS))return (SecretKey)store.getKey(ALIAS,null);
        if(!create)throw new IllegalStateException("Key not available");
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }
    @PluginMethod public void saveConnection(PluginCall call) {
        synchronized(vaultLock) {
            try {
                String json=call.getString("json");if(json==null)throw new IllegalArgumentException();
                JSONObject input=new JSONObject(json);
                if(!input.has("primary")||!input.has("primaryToken")||!input.has("allowFallback"))throw new IllegalArgumentException();
                ConnectionCipher.Envelope e=ConnectionCipher.seal(key(true),json.getBytes(StandardCharsets.UTF_8));
                boolean ok=prefs().edit().putString("iv",Base64.encodeToString(e.iv,Base64.NO_WRAP))
                    .putString("ciphertext",Base64.encodeToString(e.ciphertext,Base64.NO_WRAP)).commit();
                if(!ok)throw new IllegalStateException();
                JSObject result=new JSObject();result.put("saved",true);call.resolve(result);
            } catch(Exception ignored) { call.reject("Could not save the encrypted connection. Nothing was stored in plaintext."); }
        }
    }
    @PluginMethod public void loadConnection(PluginCall call) {
        synchronized(vaultLock) {
            try {
                String encrypted=prefs().getString("ciphertext",null);JSObject result=new JSObject();
                if(encrypted==null){result.put("found",false);call.resolve(result);return;}
                byte[] iv=Base64.decode(prefs().getString("iv",""),Base64.NO_WRAP);
                byte[] clear=ConnectionCipher.open(key(false),iv,Base64.decode(encrypted,Base64.NO_WRAP));
                String json=new String(clear,StandardCharsets.UTF_8);new JSONObject(json);
                result.put("found",true);result.put("json",json);call.resolve(result);
            } catch(Exception ignored) { call.reject("Saved connection is unavailable. Re-enter it or forget the saved connection."); }
        }
    }
    @PluginMethod public void clearConnection(PluginCall call) {
        synchronized(vaultLock) {
            try {
                if(!prefs().edit().clear().commit())throw new IllegalStateException();
                KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
                if(store.containsAlias(ALIAS))store.deleteEntry(ALIAS);
                JSObject result=new JSObject();result.put("cleared",true);call.resolve(result);
            } catch(Exception ignored) { call.reject("Could not clear the saved connection. Try again."); }
        }
    }
    @PluginMethod public void openTermux(PluginCall call) {
        try {
            Intent intent=getContext().getPackageManager().getLaunchIntentForPackage("com.termux");
            if(intent==null){call.reject("Termux is not installed. Install the official Termux app, then install/start the RAPKP backend there.");return;}
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);getContext().startActivity(intent);
            JSObject result=new JSObject();result.put("opened",true);call.resolve(result);
        }catch(Exception ignored){call.reject("Could not open Termux. Open it manually; no command was executed.");}
    }
    @PluginMethod public void exportJson(PluginCall call) {
        try {
            String text=call.getString("text");String filename=call.getString("filename","rapkp-export.json");
            if(text==null||text.getBytes(StandardCharsets.UTF_8).length>1048576)throw new IllegalArgumentException();
            new JSONObject(text);
            filename=filename.replaceAll("[^A-Za-z0-9._-]","_");
            if(filename.length()>100)filename=filename.substring(0,100);
            if(!filename.endsWith(".json"))filename+=".json";
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE,filename);
            startActivityForResult(call,intent,"writeJsonDocument");
        } catch(Exception ignored) { call.reject("Could not open the file picker for this JSON export."); }
    }
    @ActivityCallback private void writeJsonDocument(PluginCall call, ActivityResult activityResult) {
        if(call==null)return;
        if(activityResult.getResultCode()!=Activity.RESULT_OK){JSObject r=new JSObject();r.put("saved",false);r.put("cancelled",true);call.resolve(r);return;}
        try {
            Intent data=activityResult.getData();Uri uri=data==null?null:data.getData();
            if(uri==null)throw new IllegalStateException();
            String text=call.getString("text");if(text==null)throw new IllegalStateException();
            try(OutputStream stream=getContext().getContentResolver().openOutputStream(uri,"wt")) {
                if(stream==null)throw new IllegalStateException();stream.write(text.getBytes(StandardCharsets.UTF_8));
            }
            JSObject r=new JSObject();r.put("saved",true);call.resolve(r);
        } catch(Exception ignored){call.reject("Could not save the file. Choose a writable location.");}
    }
}
