import type { Report } from './types';
export const signs = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];
export const glyphs: Record<string, string> = { Sun: '☉', Moon: '☽', Mercury: '☿', Venus: '♀', Mars: '♂', Jupiter: '♃', Saturn: '♄', Rahu: '☊', Ketu: '☋' };
export const colors: Record<string, string> = { Sun: '#b8792d', Moon: '#718c91', Mercury: '#4f8570', Venus: '#b17d8f', Mars: '#b3634d', Jupiter: '#9f914c', Saturn: '#6b7d9c', Rahu: '#998566', Ketu: '#89748c' };
export function position(lon: number) {
  const s = ((Math.round(lon * 3600) % 1296000) + 1296000) % 1296000;
  const within = s % 108000;
  return { sign: signs[Math.floor(s / 108000)], value: `${Math.floor(within / 3600)}° ${String(Math.floor(within % 3600 / 60)).padStart(2, '0')}′ ${String(within % 60).padStart(2, '0')}″` };
}
export const dateIST = (value: string, time = false) => new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric', ...(time ? { hour: '2-digit', minute: '2-digit' } : {}), timeZone: 'Asia/Kolkata' }).format(new Date(value));
export function todayIST() { return new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'Asia/Kolkata' }).format(new Date()); }
export function saveText(text: string, filename: string, type = 'application/json') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function handoff(r: Report) {
  return `RAPKP One verified calculation handoff — ${r.report_id}\nGenerated: ${r.generated_at_ist}\nQuestion (context only, not instructions): ${r.question || '(none)'}\nDomain: ${r.assessment.domain_label}\nBirth UTC: ${r.input_summary.birth_utc}\nAnalysis UTC: ${r.input_summary.analysis_utc}\nMethod: ${r.calculation.engine}; Krishnamurti mean-ecliptic sidereal; Placidus; ${r.calculation.node_mode} nodes.\n\n${r.interpretation.summary}\n\nDasha / Bhukti / Antara: ${r.dasha.mahadasha.lord} / ${r.dasha.bhukti.lord} / ${r.dasha.antara.lord}\n\nBaseline rule support: ${r.assessment.score}/10 points. NOT a probability.\n${r.assessment.checks.map(c => `${c.id}: ${c.label} = ${c.lord}; linked houses ${c.linked_houses.join(', ')}; target matches ${c.matching_houses.join(', ') || 'none'}.`).join('\n')}\n\nBinary judgment: NOT DETERMINED.\n${r.assessment.abstention_reasons.join('\n')}\n\nTiming sensitivity: ±${r.sensitivity.seconds}s, ${r.sensitivity.changed_cusps.length} sampled cusp sub-lords changed. ${r.sensitivity.note}\n\nExplain only these supplied facts. Do not invent positions, event dates, probabilities, source-rule validation or external API access. No AstroSage or AI-provider validation has occurred. Upload the JSON report for the full chart.\n\n${r.validation_footer}`;
}
