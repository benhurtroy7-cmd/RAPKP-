#!/usr/bin/env python3
"""Atomically package the upgraded product; never ship caches or signing secrets."""
import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
VERSION='26.3.0-termux.1'
EXCLUDE_DIRS={'.git','.venv','node_modules','__pycache__','.pytest_cache','.ruff_cache','.hypothesis','.cache','.gradle','test-results','playwright-report','build','dist','coverage','out','target','xcuserdata'}
EXCLUDE_FILES={'.env','.coverage','.DS_Store','local.properties','tsconfig.tsbuildinfo'}
def files():
 for base,dirs,names in os.walk(ROOT):
  dirs[:]=[d for d in dirs if d not in EXCLUDE_DIRS]
  for name in names:
   if name in EXCLUDE_FILES or (name.startswith('.env.') and name!='.env.example') or name.endswith(('.pyc','.zip','.tsbuildinfo','.jks','.keystore','.p12','.mobileprovision')):continue
   p=Path(base)/name
   if p.is_symlink():raise RuntimeError(f'Review symlink: {p}')
   yield p

def main():
 q=json.loads((ROOT/'qa/verification.json').read_text())
 assert q['version']==VERSION and q['current_release_regression_complete']
 assert all(q[k]['failed']==0 for k in ['automated_tests','browser_tests','native_client_tests','upgrade_client_tests','java_crypto_tests'])
 for name,h in q['tested_source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
 apk=ROOT/f'native-artifacts/android/RAPKP-One-{VERSION}.apk';aab=ROOT/f'native-artifacts/android/RAPKP-One-{VERSION}-unsigned.aab'
 assert hashlib.sha256(apk.read_bytes()).hexdigest()==q['android']['apk_sha256']
 assert hashlib.sha256(aab.read_bytes()).hexdigest()==q['android']['aab_sha256']
 release={'product':'RAPKP One','version':VERSION,'packaged_at':datetime.now(timezone.utc).isoformat(),'release_status':'android_preview','android_package':'com.rapkp.one.preview','android_launcher':'RAPKP One 26.2','android_version_code':2603001,'android_apk':apk.relative_to(ROOT).as_posix(),'android_unsigned_aab':aab.relative_to(ROOT).as_posix(),'apk_sha256':q['android']['apk_sha256'],'native_features':['opt-in Android Keystore connection storage','system document-picker JSON export','native Back handling'],'web_features':['validated input/report import','request snapshots','session-preserved workbench','installed build/About view'],'tests':{k:q[k] for k in ['automated_tests','browser_tests','native_client_tests','upgrade_client_tests','java_crypto_tests']},'android_lint':q['android']['lint'],'physical_device_tested':False,'ios_compiled':False,'store_approved':False,'prediction_accuracy_established':False,'start':'START_HERE.html','new_source_license':'MIT; other code/data retain their terms'}
 (ROOT/'RELEASE.json').write_text(json.dumps(release,indent=2)+'\n')
 checks=[]
 for p in sorted(files()):
  if p.name!='CHECKSUMS.sha256':checks.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix())
 (ROOT/'CHECKSUMS.sha256').write_text('\n'.join(checks)+'\n')
 dest=ROOT.parent/f'RAPKP-One-v{VERSION}.zip';temp=ROOT.parent/'.cache/rapkp-release'/f'{dest.name}.partial';temp.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(files()):z.write(p,'rapkp-one/'+p.relative_to(ROOT).as_posix())
 with zipfile.ZipFile(temp) as z:
  assert z.testzip() is None
  for wanted in ['START_HERE.html','docs/QA_REPORT.pdf',apk.relative_to(ROOT).as_posix(),aab.relative_to(ROOT).as_posix(),'frontend/site/index.html','data/de440s.bsp','frontend/android/app/src/main/java/com/rapkp/one/RapkpDevicePlugin.java']:
   assert 'rapkp-one/'+wanted in z.namelist(),wanted
  for line in z.read('rapkp-one/CHECKSUMS.sha256').decode().splitlines():
   expected,rel=line.split('  ',1);assert hashlib.sha256(z.read('rapkp-one/'+rel)).hexdigest()==expected,rel
  print('Verified',len(z.namelist()),'archive entries and all checksums.')
 temp.replace(dest);digest=hashlib.sha256(dest.read_bytes()).hexdigest();dest.with_suffix('.zip.sha256').write_text(digest+'  '+dest.name+'\n')
 standalone=ROOT.parent/f'RAPKP-One-{VERSION}.apk';standalone.write_bytes(apk.read_bytes());standalone.with_suffix('.apk.sha256').write_text(q['android']['apk_sha256']+'  '+standalone.name+'\n')
 print('Project:',dest,round(dest.stat().st_size/1024/1024,2),'MiB')
 print('APK:',standalone,round(standalone.stat().st_size/1024/1024,2),'MiB')
 print('Archive SHA256:',digest)
if __name__=='__main__':main()
