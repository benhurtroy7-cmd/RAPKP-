import json
import math
from datetime import datetime, timezone

import pytest
from rapkp.config import ROOT
from rapkp.engine import AstroEngine, angular_distance
from rapkp.errors import CalculationError

REFERENCE = json.loads((ROOT / "backend/tests/fixtures/astronomy-reference.json").read_text())


@pytest.mark.parametrize("fixture", REFERENCE["fixtures"], ids=lambda f: f["id"])
@pytest.mark.parametrize("mode", ["mean", "true"])
def test_independent_reference_chart(engine, fixture, mode):
    chart = engine.calculate_at_ut1(fixture["jd_ut1"], fixture["latitude"], fixture["longitude"], mode)
    assert len(chart["cusps"]) == 12 and len(chart["bodies"]) == 9
    for name in ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn"]:
        actual = chart["bodies"][name]
        assert angular_distance(actual["longitude"], fixture["bodies"][name]["longitude"]) * 3600 < 5.0
        assert abs(actual["speed"] - fixture["bodies"][name]["speed"]) < 0.0005
    for actual, ref in zip(chart["cusps"], fixture["cusps"], strict=True):
        assert angular_distance(actual["longitude"], ref) * 3600 < 5.0
    key = "MeanNode" if mode == "mean" else "TrueNode"
    tolerance = 2.5 if mode == "mean" else 40.0
    assert (
        angular_distance(chart["bodies"]["Rahu"]["longitude"], fixture["bodies"][key]["longitude"]) * 3600 < tolerance
    )
    assert abs(chart["ayanamsa"]["mean_degrees"] - fixture["ayanamsa"]) * 3600 < 0.001
    assert (
        abs(angular_distance(chart["bodies"]["Ketu"]["longitude"], chart["bodies"]["Rahu"]["longitude"]) - 180) < 1e-9
    )
    assert chart["bodies"]["Ketu"]["speed"] == chart["bodies"]["Rahu"]["speed"]


def test_missing_kernel_fails_closed(tmp_path):
    with pytest.raises(CalculationError) as e:
        AstroEngine(tmp_path / "missing.bsp")
    assert e.value.code == "KERNEL_MISSING" and e.value.status == 503


def test_corrupt_kernel_fails_closed(tmp_path):
    p = tmp_path / "bad.bsp"
    p.write_bytes(b"not a kernel")
    with pytest.raises(CalculationError) as e:
        AstroEngine(p)
    assert e.value.code == "KERNEL_INTEGRITY"


@pytest.mark.parametrize("lat", [66, 70, 90, -66, -90])
def test_polar_placidus_never_substitutes_equal(engine, lat):
    with pytest.raises(CalculationError) as e:
        engine.calculate_at_ut1(2451545, lat, 80)
    assert e.value.code == "PLACIDUS_LATITUDE"


@pytest.mark.parametrize(
    "lat,lon,mode", [(float("nan"), 0, "mean"), (0, float("inf"), "mean"), (0, 181, "mean"), (0, 0, "unknown")]
)
def test_primitive_inputs_rejected(engine, lat, lon, mode):
    with pytest.raises(CalculationError):
        engine.calculate_at_ut1(2451545, lat, lon, mode)


def test_cached_result_not_mutable_by_caller(engine):
    a = engine.calculate_at_ut1(2451545, 13, 80)
    expected = a["bodies"]["Sun"]["longitude"]
    a["bodies"]["Sun"]["longitude"] = 0
    assert engine.calculate_at_ut1(2451545, 13, 80)["bodies"]["Sun"]["longitude"] == expected


def test_missing_planet_does_not_become_zero(engine, monkeypatch):
    engine._cached_compute.cache_clear()

    def failure(*args):
        raise RuntimeError("secret/private failure detail")

    with monkeypatch.context() as m:
        m.setattr(engine.planet_engine, "ecliptic_longitude", failure)
        with pytest.raises(CalculationError) as e:
            engine.calculate_at_ut1(2451555, 12, 81)
        assert "secret" not in e.value.message
        assert e.value.code == "CALCULATION_FAILED"


def test_invalid_house_values_rejected(engine, monkeypatch):
    engine._cached_compute.cache_clear()

    class Broken:
        cusps = [float("nan")] * 12

    with monkeypatch.context() as m:
        m.setattr("rapkp.engine.compute", lambda *args: Broken())
        with pytest.raises(CalculationError) as e:
            engine.calculate_at_ut1(2451556, 12, 81)
        assert e.value.code == "INVALID_CUSPS"


def test_utc_and_ut1_distinguished(engine):
    jd = engine.utc_to_ut1(datetime(2000, 1, 1, 12, tzinfo=timezone.utc))
    assert 0 < abs(jd - 2451545) * 86400 < 1
    with pytest.raises(ValueError):
        engine.utc_to_ut1(datetime(2000, 1, 1))


def test_body_ranges_and_node_modes(engine):
    a = engine.calculate_at_ut1(2461313, 13.08, 80.27, "mean")
    b = engine.calculate_at_ut1(2461313, 13.08, 80.27, "true")
    assert a["bodies"]["Rahu"]["longitude"] != b["bodies"]["Rahu"]["longitude"]
    for p in a["bodies"].values():
        assert 0 <= p["longitude"] < 360 and math.isfinite(p["speed"])
        assert 1 <= p["house"] <= 12
        assert type(p["retrograde"]) is bool
