import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { isNative } from './api';
import './styles.css';
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
// Cache only the UI shell. The service worker never caches API requests or birth data.
if (!isNative() && 'serviceWorker' in navigator && (window.location.protocol === 'https:' || ['localhost','127.0.0.1'].includes(window.location.hostname))) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => {}); });
}
