> Historical/general baseline. The current release is Termux-only; use TERMUX_AI_START.md, API_TERMUX.md and QA_TERMUX_AI.md. Native automation/live-account/device limits and AGPL engine terms there take precedence.

> Historical RC2 update: Android evaluation APK and unsigned release AAB were compiled; 25 mocked native-client tests passed. Physical-device/store validation remain open; the complete RC2 software regression rerun has passed. See RC2_RELEASE_NOTES.md for authoritative current scope.

# Architecture and scalability

```text
React web UI / Capacitor Android & iOS / Custom GPT Action / Gemini API bridge
                                   |
                    Structured, versioned POST request
                                   |
                         RAPKP One stateless API
                 auth → size/rate/compute limits → validation
                                   |
               IANA local time → UTC → UT1/TT → DE440s
                  apparent planets + IAU 2000A nutation
                                   |
                KP sidereal + real Placidus + sub-lords
                                   |
              corrected Vimshottari + inspectable link graph
                                   |
            baseline assessment + sensitivity + explicit abstention
                                   |
                     JSON / UI / print / AI handoff
```

## One core, not five independent calculators

Cloud and Termux run the same Python modules. Native shells call the same contract using Capacitor's native HTTP bridge; browser clients default to relative, same-origin `/api/...` requests. ChatGPT consumes an actual deployed Action; a consumer Gem consumes an explicit exported report unless separately granted a supported connector. AI prose never becomes the numerical source of truth.

The core does not require or call a model provider. The optional Gemini bridge is separate, requires consent and fixed user-confirmed input, permits exactly one whitelisted tool and labels the provider's explanation unverified. There is no “built-in AstroSage” or “GPT-6 validation” switch.

## Numerical contract

- Dates restricted to **1900–2099 UTC**, geographic longitude ±180°, Placidus latitude **strictly inside ±66°**.
- Explicit IANA timezone and local civil time. DST gaps are rejected; repeated times need a fold choice.
- Geocentric apparent classical planet positions, JPL outer-system barycentres; explicitly selected mean or true/osculating nodes.
- Krishnamurti mean ayanamsa polynomial + removal of nutation in longitude for the selected mean-ecliptic sidereal convention.
- Placidus geometry uses apparent sidereal time and true obliquity. No equal-house fallback.
- Dasha year fixed at **365.2425 days**. Full first-mahadasha start reconstructed before selecting subperiods. Child boundaries use exact integer microsecond partitions.
- Longitudes stay unrounded internally. Display formatting is separate.
- Ruling weekday currently means **local civil weekday**. It is not silently represented as a sunrise-based KP day.
- Birth-time sensitivity samples earlier/recorded/later times; it is **not** exhaustive interval analysis or rectification.

## Scaling model

API requests have no persistent report database. Each worker loads a verified read-only kernel and owns a bounded 96-entry in-memory chart cache. Reports are assembled on demand. A lock protects the pinned engine/cache; increase **processes/replicas**, not unbounded threads, for CPU throughput. Cache hits and cold chart requests have very different costs.

Request bodies are limited to 32 KiB, questions to 600 characters and active calculation slots to a configurable bounded count. Overload returns 429, not a queued unbounded job. Per-token fixed-window throttling is process-local by default; **configure private Valkey/Redis for multiple workers or replicas**. Remote limiter failure returns 503 rather than disabling throttling. The key is a digest, not a stored plaintext token.

Two API instances sharing a real local Valkey quota are included in the recorded tests. The local benchmark is **one FastAPI TestClient process**, not real network/TLS traffic or production replica scaling. The Kubernetes manifest is a template, not a deployment that was exercised here.

Before capacity claims: provision a real staging cluster, pin image digests, add edge request timeouts/WAF, run cold/warm mixed loads and fault injection, measure p95/p99 under representative tenants, establish observability and key/identity lifecycle, and test rolling restarts. Requests do not depend on sticky sessions; a shared rate limiter is the main cross-worker dependency.

## Failure / fallback semantics

The client retries a **separately configured, expressly authorised** fallback only for transport errors and 502/503/504 responses. A 401, 422 or 429 is not retried against another service. Primary tokens are not forwarded to fallback. A failed new calculation clears the old report from the active answer area. An offline cached UI is not an offline ephemeris engine.

## Deliberate scope exclusions

No billing/subscriptions, persistent birth-profile vault (26.2 does implement an opt-in encrypted Android connection record), OAuth provider, tenant database, push notifications, cloud auto-provisioning, custom model training, full horary judgment, missing 21-rule implementation, AstroSage connector or owner-release-signed/store-approved mobile binaries. A debug-signed Android evaluation APK and an unsigned AAB are included; iOS is source-only. These cannot be inferred from a single PDF or tested without their requirements/credentials.

## Current HTTP verification

RC2 completed a protected two-worker loopback HTTP check with shared Valkey throttling. It verified 64 distinct requests, 120 repeated requests, an 80-request burst with controlled overload rejection, and fail-closed limiter outage. See `qa/http-two-worker-check.json`. This is not production-cluster/TLS capacity certification.
