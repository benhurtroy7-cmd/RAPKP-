import type { MomentInput, Place, ReadingInput } from './types';
const domains=new Set(['career','marriage','property','education','travel','business','wealth','meeting','remarriage','handover']);
const obj=(v:unknown):v is Record<string,unknown>=>typeof v==='object' && v!==null && !Array.isArray(v);
function bad(field:string):never {throw new Error(`Invalid ${field} in the input file. Review the saved inputs.`);}
function text(v:unknown,field:string,max:number):string {if(typeof v!=='string'||v.length>max)bad(field);return v as string;}
function date(v:unknown,field:string):string {
  const s=text(v,field,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(s))bad(field);
  const [y,m,d]=s.split('-').map(Number);const t=new Date(Date.UTC(y,m-1,d));
  if(y<1900||y>2099||t.getUTCFullYear()!==y||t.getUTCMonth()!==m-1||t.getUTCDate()!==d)bad(field);return s;
}
function time(v:unknown,field:string):string {
  const s=text(v,field,18);const m=/^(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?$/.exec(s);
  if(!m||Number(m[1])>23||Number(m[2])>59||Number(m[3]||0)>59)bad(field+' (local HH:MM:SS, at most milliseconds in the UI)');return s;
}
function place(v:unknown,field:string):Place {
  if(!obj(v))bad(field);const p=v as Record<string,unknown>;
  const label=p.label===undefined?'Imported location':text(p.label,field+' label',96);
  if(typeof p.latitude!=='number'||!Number.isFinite(p.latitude)||Math.abs(p.latitude)>=66)bad(field+' latitude (Placidus requires |latitude| < 66°)');
  if(typeof p.longitude!=='number'||!Number.isFinite(p.longitude)||Math.abs(p.longitude)>180)bad(field+' longitude');
  const timezone=text(p.timezone,field+' timezone',80);
  if(timezone!=='UTC'&&!timezone.includes('/'))bad(field+' IANA timezone');
  try {new Intl.DateTimeFormat('en',{timeZone:timezone}).format(new Date());}catch{bad(field+' IANA timezone');}
  return {label,latitude:p.latitude as number,longitude:p.longitude as number,timezone};
}
function moment(v:unknown,field:string):MomentInput {
  if(!obj(v))bad(field);const p=v as Record<string,unknown>;
  const fold=p.fold===undefined?null:p.fold;if(fold!==null&&fold!==0&&fold!==1)bad(field+' DST occurrence');
  return {date:date(p.date,field+' date'),time:time(p.time,field+' time'),place:place(p.place,field+' location'),fold:fold as 0|1|null};
}
export function parseReadingInput(raw: string): { input: ReadingInput; fromReport: boolean } {
  if(new TextEncoder().encode(raw).length>512*1024)throw new Error('Choose a JSON file smaller than 512 KiB.');
  let data: unknown;try{data=JSON.parse(raw);}catch{throw new Error('This is not a valid JSON input file.');}
  if(!obj(data))bad('request');let fromReport=false;
  if(data.schema_version==='1.0'&&obj(data.input_summary)) {
    const r=data;fromReport=true;
    data={birth:r.input_summary && (r.input_summary as Record<string,unknown>).birth,analysis:(r.input_summary as Record<string,unknown>).analysis,domain:r.domain,question:r.question??'',node_mode:obj(r.calculation)?r.calculation.node_mode:'mean',include_transits:r.transits!==null};
  }
  if(!obj(data))bad('request');const r=data as Record<string,unknown>;
  const allowed=new Set(['birth','analysis','domain','question','node_mode','include_transits']);
  if(Object.keys(r).some(k=>!allowed.has(k)))throw new Error('Unsupported request fields. Import a RAPKP input file or a version 1.0 report.');
  const birth=moment(r.birth,'birth');const analysis=moment(r.analysis,'analysis');
  const u=obj(r.birth)&&r.birth.uncertainty_seconds!==undefined?r.birth.uncertainty_seconds:60;
  if(typeof u!=='number'||!Number.isInteger(u)||u<0||u>1800)bad('birth-time uncertainty');
  const domain=text(r.domain??'career','domain',30);if(!domains.has(domain))bad('domain');
  const node=r.node_mode??'mean';if(node!=='mean'&&node!=='true')bad('node mode');
  const include=r.include_transits??true;if(typeof include!=='boolean')bad('transit option');
  return {fromReport,input:{birth:{...birth,uncertainty_seconds:u as number},analysis,domain,question:text(r.question??'','question',600),node_mode:node,include_transits:include}};
}
