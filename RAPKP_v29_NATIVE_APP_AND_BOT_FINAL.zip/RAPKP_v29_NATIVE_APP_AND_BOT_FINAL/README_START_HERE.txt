RAPKP v29 FINAL: Native App + BOT Commercial Suite

This package contains BOTH requested deliverables:

1) NATIVE ANDROID APP
   Folder: 01_NATIVE_ANDROID_APP/
   - RAPKP_v29_NATIVE_APP.apk
   - native_android_source/

   APK identity:
   - App display name: RAPKP BOT
   - Android package: in.rapkp.v26
   - versionCode: 35
   - versionName: v29.0 BOT Commercial Suite
   - Signature verified: APK Signature Scheme v2 and v3

   Cloud status:
   - The app is cloud-ready and cloud-first.
   - Cloud is the official prediction brain for commercial precision.
   - To become Cloud LIVE, the backend must be deployed and the Cloud API URL must be set in the app, or hardcoded before customer delivery.
   - Without a deployed Render/cloud URL, the app can only use demo/emergency fallback.

2) BOT COMMERCIAL SUITE
   Folder: 02_BOT_COMMERCIAL_SUITE/

3) CLOUD BACKEND
   Folder: 03_CLOUD_BACKEND/

4) DEPLOYMENT PACKAGES
   Folder: 04_DEPLOYMENT_PACKAGES/

Business model:
Build -> Operate -> Transfer
