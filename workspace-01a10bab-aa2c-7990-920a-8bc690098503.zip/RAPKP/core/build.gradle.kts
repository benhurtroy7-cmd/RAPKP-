// RAPKP core: pure Kotlin/JVM module.
// Every deterministic calculation, rule, evidence and audit path lives here so that the
// exact shipped code can be executed by the JVM test suite (no Android runtime needed and
// no re-implementation for tests).
plugins {
    id("org.jetbrains.kotlin.jvm")
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}

tasks.withType<Test>().configureEach {
    testLogging {
        events("passed", "failed", "skipped")
        showStandardStreams = true
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
    // Deterministic engine tests are single threaded on purpose: results must be
    // reproducible and must not depend on scheduling.
    maxParallelForks = 1
}
