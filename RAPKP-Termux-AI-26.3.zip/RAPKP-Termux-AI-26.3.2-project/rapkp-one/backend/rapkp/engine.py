"""Fail-closed OpenEphem/Skyfield adapter, pinned to a checked JPL kernel.

We deliberately do not call assemble(), whose degraded-chart behavior is useful
for visualization but inappropriate for making a complete KP report.
"""

import copy
import hashlib
import math
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from threading import RLock

from openephem.houses import compute, mean_obliquity
from openephem.planets_skyfield import SkyfieldPlanetEngine
from openephem.vedic import ayanamsa
from skyfield.nutationlib import iau2000a_radians

from .constants import KERNEL_SHA256
from .errors import CalculationError
from .kp import house_of, lords

PLANETS = ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn"]


def angular_distance(a: float, b: float) -> float:
    return abs((a - b + 180) % 360 - 180)


class AstroEngine:
    def __init__(self, kernel_path: Path):
        self.kernel_path = kernel_path
        if not kernel_path.is_file():
            raise CalculationError(
                "KERNEL_MISSING", "The verified JPL DE440s kernel is missing. Install data before calculating.", 503
            )
        digest = hashlib.sha256()
        with kernel_path.open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != KERNEL_SHA256:
            raise CalculationError(
                "KERNEL_INTEGRITY",
                "Ephemeris checksum failed. Restore the verified kernel; no substitute will be used.",
                503,
            )
        try:
            self.planet_engine = SkyfieldPlanetEngine(str(kernel_path.resolve()))
        except Exception as e:
            raise CalculationError(
                "ENGINE_UNAVAILABLE", "The astronomical engine could not load the verified ephemeris.", 503
            ) from e
        self.lock = RLock()
        self._cached_compute = lru_cache(maxsize=96)(self._compute)

    def close(self):
        """Release per-worker caches and the ephemeris file mapping."""
        with self.lock:
            self._cached_compute.cache_clear()
            self.planet_engine._eph.close()

    def utc_to_ut1(self, moment: datetime) -> float:
        if moment.tzinfo is None:
            raise ValueError("Timezone-aware moment required")
        # Skyfield's bundled timescale handles UTC/TT/UT1 instead of treating UTC as UT1.
        return float(self.planet_engine._ts.from_datetime(moment).ut1)

    def chart_at(self, moment: datetime, latitude: float, longitude: float, node_mode: str = "mean") -> dict:
        result = self.calculate_at_ut1(self.utc_to_ut1(moment), latitude, longitude, node_mode)
        result["utc"] = moment.isoformat()
        return result

    def calculate_at_ut1(self, jd_ut1: float, latitude: float, longitude: float, node_mode: str = "mean") -> dict:
        if not all(math.isfinite(x) for x in [jd_ut1, latitude, longitude]):
            raise CalculationError("NONFINITE_INPUT", "All numerical inputs must be finite.")
        if not -180 <= longitude <= 180 or not -90 <= latitude <= 90:
            raise CalculationError("INVALID_COORDINATES", "Coordinates are outside their valid range.")
        if abs(latitude) >= 66:
            raise CalculationError(
                "PLACIDUS_LATITUDE",
                "This Placidus implementation supports |latitude| < 66°. No equal-house fallback is substituted.",
            )
        if node_mode not in {"mean", "true"}:
            raise CalculationError("NODE_MODE", "Choose mean or true nodes explicitly.")
        try:
            with self.lock:
                return copy.deepcopy(self._cached_compute(jd_ut1, latitude, longitude, node_mode))
        except CalculationError:
            raise
        except Exception as e:
            raise CalculationError(
                "CALCULATION_FAILED",
                "Calculation failed; no chart or prediction was produced. Check the date range and installed data.",
                503,
            ) from e

    def _sidereal_shift(self, jd: float) -> tuple[float, float, float]:
        t = self.planet_engine._t(jd)
        dpsi, deps = iau2000a_radians(t)
        ay = ayanamsa(jd, "krishnamurti")
        # Sidereal reference uses the mean ecliptic/equinox of date. Subtract
        # nutation in longitude as well as the mean ayanamsa from true-of-date
        # apparent tropical longitudes. The legacy PDF omitted this distinction.
        return ay + math.degrees(float(dpsi)), ay, math.degrees(float(deps))

    def _compute(self, jd: float, latitude: float, longitude: float, node_mode: str) -> dict:
        t = self.planet_engine._t(jd)
        shift, ay, deps = self._sidereal_shift(jd)
        armc = (float(t.gast) * 15 + longitude) % 360
        eps = mean_obliquity(float(t.tt)) + deps
        houses = compute(armc, eps, latitude, "Placidus")
        cusps = [(float(c) - shift) % 360 for c in houses.cusps]
        if len(cusps) != 12 or any(not math.isfinite(c) for c in cusps):
            raise CalculationError("INVALID_CUSPS", "Twelve finite Placidus cusps were not obtained.", 503)
        # Validate the cycle even if every body happened to lie away from a bad cusp.
        house_of(cusps[0], cusps)
        step = 1 / 1440  # central difference at ±60 seconds, not the legacy ±12 hours
        low_shift = self._sidereal_shift(jd - step)[0]
        high_shift = self._sidereal_shift(jd + step)[0]
        bodies = {}
        node_name = "MeanNode" if node_mode == "mean" else "TrueNode"
        for source in PLANETS + [node_name]:
            tropical = float(self.planet_engine.ecliptic_longitude(jd, source))
            low = (self.planet_engine.ecliptic_longitude(jd - step, source) - low_shift) % 360
            high = (self.planet_engine.ecliptic_longitude(jd + step, source) - high_shift) % 360
            speed = float(((high - low + 180) % 360 - 180) / (2 * step))
            lon = (tropical - shift) % 360
            if not all(math.isfinite(x) for x in (lon, speed, tropical)):
                raise CalculationError("INVALID_BODY", "An incomplete planetary position was rejected.", 503)
            name = "Rahu" if source == node_name else source
            bodies[name] = {
                "name": name,
                "longitude": lon,
                "tropical_longitude": tropical,
                "speed": speed,
                "retrograde": speed < 0,
                "near_station": abs(speed) < 0.0001,
                "house": house_of(lon, cusps),
                **lords(lon),
            }
        rahu = bodies["Rahu"]
        ketu = (rahu["longitude"] + 180) % 360
        bodies["Ketu"] = {
            "name": "Ketu",
            "longitude": ketu,
            "tropical_longitude": (rahu["tropical_longitude"] + 180) % 360,
            "speed": rahu["speed"],
            "retrograde": rahu["retrograde"],
            "near_station": rahu["near_station"],
            "house": house_of(ketu, cusps),
            **lords(ketu),
        }
        cusp_analysis = [{"house": i + 1, "longitude": lon, **lords(lon)} for i, lon in enumerate(cusps)]
        warnings = []
        for name, body in bodies.items():
            margin = 60 if name in {"Rahu", "Ketu"} and node_mode == "true" else 5
            if body["sub_boundary_distance_arcsec"] < margin or body["sub_sub_boundary_distance_arcsec"] < margin:
                warnings.append(
                    f"{name} is close to a sub/sub-sub boundary. Small numerical or input changes may change the assigned lord."
                )
            if body["near_station"]:
                warnings.append(f"{name} is near a station; the retrograde flag is sensitive to the motion convention.")
        return {
            "jd_ut1": jd,
            "latitude": latitude,
            "longitude": longitude,
            "zodiac": "sidereal",
            "house_system": "Placidus",
            "ayanamsa": {
                "name": "Krishnamurti",
                "mean_degrees": ay,
                "effective_shift_degrees": shift,
                "method": "openephem polynomial + IAU 2000A nutation removal",
            },
            "angles": {"ascendant": cusps[0], "midheaven": cusps[9], "armc": armc, "true_obliquity": eps},
            "node_mode": node_mode,
            "bodies": bodies,
            "cusps": cusp_analysis,
            "warnings": warnings,
            "conventions": [
                "Geocentric apparent planetary positions",
                "Mean-ecliptic-of-date KP sidereal convention",
                "Outer planet system barycentres in DE440s",
                "UTC→UT1/TT via Skyfield bundled timescale",
                "No zero-position or alternative-house fallback",
            ],
        }
