import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Settings:
    environment: str = "production"
    api_key: str = field(default="", repr=False)
    kernel_path: Path = ROOT / "data" / "de440s.bsp"
    redis_url: str = field(default="", repr=False)
    requests_per_minute: int = 30
    max_concurrent: int = 4
    workers: int = 1
    allowed_origins: tuple[str, ...] = ()
    static_path: Path = ROOT / "frontend" / "site"

    def validate(self):
        if self.environment not in {"production", "demo", "local", "test"}:
            raise ValueError("RAPKP_ENV must be production, demo, local or test")
        if self.environment == "production" and (
            len(self.api_key) < 32 or self.api_key.startswith(("REPLACE_", "CHANGE_"))
        ):
            raise ValueError("Production requires a RAPKP_API_KEY of at least 32 characters")
        if self.environment == "production" and "*" in self.allowed_origins:
            raise ValueError("Production CORS must use an explicit origin list")
        if self.environment == "production" and self.workers > 1 and not self.redis_url:
            raise ValueError("Multiple workers require RAPKP_REDIS_URL for shared throttling")
        if (
            not 1 <= self.requests_per_minute <= 10000
            or not 1 <= self.max_concurrent <= 32
            or not 1 <= self.workers <= 32
        ):
            raise ValueError("Invalid resource limits")
        return self

    @classmethod
    def from_env(cls):
        return cls(
            environment=os.getenv("RAPKP_ENV", "production"),
            api_key=os.getenv("RAPKP_API_KEY", ""),
            kernel_path=Path(os.getenv("RAPKP_KERNEL_PATH", str(ROOT / "data/de440s.bsp"))),
            redis_url=os.getenv("RAPKP_REDIS_URL", ""),
            requests_per_minute=int(os.getenv("RAPKP_RATE_LIMIT", "30")),
            max_concurrent=int(os.getenv("RAPKP_MAX_CONCURRENT", "4")),
            workers=int(os.getenv("RAPKP_WORKERS", "1")),
            allowed_origins=tuple(x.strip() for x in os.getenv("RAPKP_ALLOWED_ORIGINS", "").split(",") if x.strip()),
        ).validate()
