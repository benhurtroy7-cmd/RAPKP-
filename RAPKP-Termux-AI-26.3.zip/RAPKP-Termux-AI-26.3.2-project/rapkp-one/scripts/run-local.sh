#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${RAPKP_PYTHON:-.venv/bin/python}"
if [ ! -x "$PYTHON" ]; then echo "Run bash scripts/install.sh first." >&2; exit 1; fi
export RAPKP_ENV="${RAPKP_ENV:-local}"
export PYTHONPATH="$PWD/backend${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
BIND="${RAPKP_BIND:-127.0.0.1}"
PORT="${PORT:-8000}"
if [ "$BIND" != "127.0.0.1" ] && [ "$RAPKP_ENV" != "production" ]; then
  echo 'Refusing a public unauthenticated bind. Configure production and a strong API key, or use device loopback.' >&2; exit 1
fi
printf 'RAPKP One → http://%s:%s\nStop with Ctrl+C. No chart is stored by the service.\n' "$BIND" "$PORT"
exec "$PYTHON" -m uvicorn rapkp.api:create_app --factory --host "$BIND" --port "$PORT" --no-access-log
