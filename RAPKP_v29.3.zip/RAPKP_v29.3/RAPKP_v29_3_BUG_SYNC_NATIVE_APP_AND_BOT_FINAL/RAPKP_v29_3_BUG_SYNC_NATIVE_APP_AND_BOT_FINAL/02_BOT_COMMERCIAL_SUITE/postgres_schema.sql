CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  name TEXT,
  phone TEXT,
  email TEXT,
  role TEXT DEFAULT 'customer',
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS charts (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  user_id INTEGER,
  name TEXT,
  dob DATE,
  tob TEXT,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION,
  tz DOUBLE PRECISION,
  place TEXT,
  relation TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS predictions (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  chart_id INTEGER,
  query TEXT,
  domain TEXT,
  answer_date DATE,
  answer_time TEXT,
  probability DOUBLE PRECISION,
  dasha TEXT,
  asc_text TEXT,
  payload JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rules (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  title TEXT,
  rule TEXT,
  rule_type TEXT DEFAULT 'auto',
  active BOOLEAN DEFAULT TRUE,
  source TEXT,
  applied_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS corrections (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  query TEXT,
  domain TEXT,
  chart TEXT,
  correct_date DATE,
  correct_time TEXT,
  note TEXT,
  applied BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bugs (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  query TEXT,
  error TEXT,
  context TEXT,
  engine TEXT,
  status TEXT DEFAULT 'open',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pdf_readings (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  filename TEXT,
  chart TEXT,
  query TEXT,
  pages INTEGER,
  chars INTEGER,
  domain TEXT,
  answer_date DATE,
  probability DOUBLE PRECISION,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT DEFAULT 'default',
  actor TEXT,
  action TEXT,
  payload JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
