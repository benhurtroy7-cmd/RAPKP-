package com.rapkp.one;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.json.JSONObject;

/** Only fixed, bundled setup/start commands are exposed. Never interpolates user questions or model keys. */
@CapacitorPlugin(name="TermuxBridge",permissions={@Permission(alias="termux",strings={"com.termux.permission.RUN_COMMAND"})})
public class TermuxBridgePlugin extends Plugin {
    static final AtomicInteger NEXT=new AtomicInteger(1000);
    static final ConcurrentHashMap<Integer,PluginCall> PENDING=new ConcurrentHashMap<>();
    private static final String ALIAS="rapkp.termux.pair.v1";
    private SharedPreferences prefs(){return getContext().getSharedPreferences("rapkp.termux.pair",0);}
    private String asset(String name)throws Exception{return new String(assetBytes(name),StandardCharsets.UTF_8);}
    private byte[] assetBytes(String name)throws Exception{
        try(InputStream in=getContext().getAssets().open("termux/"+name);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>180000)throw new IllegalArgumentException("Oversized trusted bundle");}return out.toByteArray();
        }
    }
    private SecretKey key()throws Exception{
        KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);if(s.containsAlias(ALIAS))return (SecretKey)s.getKey(ALIAS,null);
        KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());return g.generateKey();
    }
    private synchronized String token()throws Exception{
        String stored=prefs().getString("cipher",null);
        if(stored!=null)return new String(ConnectionCipher.open(key(),Base64.decode(prefs().getString("iv",""),Base64.NO_WRAP),Base64.decode(stored,Base64.NO_WRAP)),StandardCharsets.UTF_8);
        byte[] random=new byte[32];new SecureRandom().nextBytes(random);StringBuilder b=new StringBuilder();for(byte x:random)b.append(String.format(java.util.Locale.ROOT,"%02x",x&255));
        String t=b.toString();ConnectionCipher.Envelope e=ConnectionCipher.seal(key(),t.getBytes(StandardCharsets.UTF_8));
        if(!prefs().edit().putString("iv",Base64.encodeToString(e.iv,Base64.NO_WRAP)).putString("cipher",Base64.encodeToString(e.ciphertext,Base64.NO_WRAP)).commit())throw new IllegalStateException();return t;
    }
    private boolean installed(String name){try{getContext().getPackageManager().getPackageInfo(name,0);return true;}catch(Exception ignored){return false;}}
    @PluginMethod public void status(PluginCall call){
        JSObject r=new JSObject();r.put("termuxInstalled",installed("com.termux"));r.put("bootInstalled",installed("com.termux.boot"));r.put("permissionGranted",getPermissionState("termux")==PermissionState.GRANTED);r.put("paired",prefs().getBoolean("connectorInstalled",false));
        try{PackageInfo p=getContext().getPackageManager().getPackageInfo("com.termux",0);r.put("termuxVersion",p.versionName);}catch(Exception ignored){}
        call.resolve(r);
    }
    @PluginMethod public void requestAccess(PluginCall call){
        if(!installed("com.termux")){call.reject("Termux is not installed. Install the official Termux app first.");return;}
        if(getPermissionState("termux")==PermissionState.GRANTED){JSObject r=new JSObject();r.put("granted",true);call.resolve(r);return;}
        requestPermissionForAlias("termux",call,"accessResult");
    }
    @PermissionCallback private void accessResult(PluginCall call){JSObject r=new JSObject();r.put("granted",getPermissionState("termux")==PermissionState.GRANTED);call.resolve(r);}
    @PluginMethod public void connection(PluginCall call){
        try{JSObject r=new JSObject();r.put("primary","http://127.0.0.1:8765");r.put("primaryToken",token());r.put("fallback","");r.put("fallbackToken","");r.put("allowFallback",false);call.resolve(r);}catch(Exception ignored){call.reject("Could not access the app's local pairing key.");}
    }
    @PluginMethod public void openTermux(PluginCall call){openPackage(call,"com.termux");}
    @PluginMethod public void openBoot(PluginCall call){openPackage(call,"com.termux.boot");}
    private void openPackage(PluginCall call,String name){try{Intent i=getContext().getPackageManager().getLaunchIntentForPackage(name);if(i==null)throw new IllegalStateException();i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);getContext().startActivity(i);call.resolve();}catch(Exception ignored){call.reject("Could not open the installed Termux component. Open it manually.");}}
    private Intent command(String path,String[] args){
        Intent i=new Intent();i.setClassName("com.termux","com.termux.app.RunCommandService");i.setAction("com.termux.RUN_COMMAND");i.putExtra("com.termux.RUN_COMMAND_PATH",path);i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",args);i.putExtra("com.termux.RUN_COMMAND_WORKDIR","~/");i.putExtra("com.termux.RUN_COMMAND_BACKGROUND",true);i.putExtra("com.termux.RUN_COMMAND_BACKGROUND_CUSTOM_LOG_LEVEL","0");i.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL","RAPKP local connector");return i;
    }
    private void requireAccess()throws Exception{if(!installed("com.termux")||getPermissionState("termux")!=PermissionState.GRANTED)throw new SecurityException();}
    @PluginMethod public void installConnector(PluginCall call){
        try{
            requireAccess();byte[] bundle=assetBytes("backend.zip");JSONObject manifest=new JSONObject(asset("manifest.json"));
            byte[] h=MessageDigest.getInstance("SHA-256").digest(bundle);StringBuilder hex=new StringBuilder();for(byte b:h)hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
            if(!hex.toString().equals(manifest.getString("sha256")))throw new IllegalStateException();
            JSONObject payload=new JSONObject();payload.put("token",token());payload.put("version",manifest.getString("version"));payload.put("sha256",hex.toString());payload.put("bundle",Base64.encodeToString(bundle,Base64.NO_WRAP));
            String stdin=payload.toString();if(stdin.length()>210000)throw new IllegalStateException();
            Intent i=command("$PREFIX/bin/python",new String[]{"-c",asset("bootstrap.py")});i.putExtra("com.termux.RUN_COMMAND_STDIN",stdin);
            int id=NEXT.incrementAndGet();Intent result=new Intent(getContext(),TermuxResultReceiver.class);result.putExtra("requestId",id);
            int flags=PendingIntent.FLAG_ONE_SHOT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
            PendingIntent pending=PendingIntent.getBroadcast(getContext(),id,result,flags);i.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT",pending);PENDING.put(id,call);
            try{getContext().startService(i);}catch(Exception e){PENDING.remove(id);throw e;}
            new Handler(Looper.getMainLooper()).postDelayed(()->{PluginCall waiting=PENDING.remove(id);if(waiting!=null)waiting.reject("Termux setup did not return in time. Check RUN_COMMAND permission and allow-external-apps=true, then retry. No provider key was sent in a command.");},45000);
        }catch(SecurityException ignored){call.reject("Grant Run commands in Termux to RAPKP, then enable allow-external-apps=true inside Termux.");}
        catch(Exception ignored){call.reject("Could not install the local connector. Check Termux/Python and command permissions.");}
    }
    @PluginMethod public void startBackend(PluginCall call){
        try{
            requireAccess();String root=getContext().getPackageManager().getApplicationInfo("com.termux",0).dataDir+"/files/home/.rapkp-one/start.py";
            Intent i=command("$PREFIX/bin/python",new String[]{root});getContext().startService(i);
            JSObject r=new JSObject();r.put("requested",true);r.put("note","Start intent sent. App must verify HTTP readiness before claiming connection.");call.resolve(r);
        }catch(Exception ignored){call.reject("Termux could not be started. Check permission, allow-external-apps and the installed connector.");}
    }
}
