import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Download, Upload, ArrowDownRight, ArrowRight, ArrowUpRight, CalendarDays, Check, ChevronDown, CircleDot, Clock3, Database, Fingerprint, Info, Loader2, LockKeyhole, MapPin, Orbit, RotateCcw, ShieldCheck, SlidersHorizontal, Sparkles } from 'lucide-react';
import { api, type Connection } from './api';
import type { Horary, Place, ReadingInput, Report, Status, AIJob } from './types';
import { position, todayIST } from './utils';
import type { View } from './App';
import ChartWheel from './ChartWheel';
import ReportView from './ReportView';
import { exportJsonFile } from './device';
import { parseReadingInput } from './snapshots';
import AIReading from './AIReading';
import { APP_SERIES } from './version';

const places: Place[] = [
  { label: 'Chennai, India', latitude: 13.0827, longitude: 80.2707, timezone: 'Asia/Kolkata' },
  { label: 'Bengaluru, India', latitude: 12.9716, longitude: 77.5946, timezone: 'Asia/Kolkata' },
  { label: 'Mumbai, India', latitude: 19.076, longitude: 72.8777, timezone: 'Asia/Kolkata' },
  { label: 'Delhi, India', latitude: 28.6139, longitude: 77.209, timezone: 'Asia/Kolkata' },
  { label: 'London, UK', latitude: 51.5074, longitude: -.1278, timezone: 'Europe/London' },
  { label: 'New York, USA', latitude: 40.7128, longitude: -74.006, timezone: 'America/New_York' },
  { label: 'Singapore', latitude: 1.3521, longitude: 103.8198, timezone: 'Asia/Singapore' },
  { label: 'Sydney, Australia', latitude: -33.8688, longitude: 151.2093, timezone: 'Australia/Sydney' },
];
const domains = [['career', 'Career & work'], ['marriage', 'Marriage'], ['property', 'Property'], ['education', 'Education'], ['travel', 'Foreign travel'], ['business', 'Business'], ['wealth', 'Wealth'], ['meeting', 'Meeting'], ['remarriage', 'Remarriage'], ['handover', 'Property handover']];

function PlacePicker({ value, onChange, label, id }: { value: Place | null; onChange: (v: Place) => void; label: string; id: string }) {
  const preset = places.find(p => p.label === value?.label);
  return <div className="place-picker"><label className="field" htmlFor={id}><span>{label}</span><div className="input-with-icon"><MapPin size={16} /><select id={id} value={value ? preset?.label || 'custom' : ''} required onChange={e => { const p = places.find(p => p.label === e.target.value); if (p) onChange({ ...p }); else if (e.target.value === 'custom') onChange({ label: 'Custom location', latitude: 0, longitude: 0, timezone: 'UTC' }); }}><option value="" disabled>Select a location</option>{places.map(p => <option key={p.label}>{p.label}</option>)}<option value="custom">Enter coordinates manually</option></select></div></label>
    {value && <details className="coordinate-details" open={!preset || undefined}><summary>{value.timezone} <span>· {value.latitude.toFixed(4)}, {value.longitude.toFixed(4)}</span><ChevronDown size={12} /></summary><div className="form-grid coordinate-grid"><label className="field"><span>Latitude</span><input aria-label={`${label} latitude`} type="number" min="-90" max="90" step="any" value={value.latitude} onChange={e => onChange({ ...value, latitude: Number(e.target.value) })} /></label><label className="field"><span>Longitude</span><input aria-label={`${label} longitude`} type="number" min="-180" max="180" step="any" value={value.longitude} onChange={e => onChange({ ...value, longitude: Number(e.target.value) })} /></label><label className="field full-width"><span>IANA timezone</span><input aria-label={`${label} timezone`} value={value.timezone} onChange={e => onChange({ ...value, timezone: e.target.value })} required /></label></div><small>Confirm coordinates and historical timezone. Placidus is supported only for |latitude| &lt; 66°.</small></details>}
  </div>;
}

export default function Workbench({ connection, status, toast, navigate, openConnection }: { connection: Connection; status: Status | null; toast: (v: string) => void; navigate: (v: View) => void; openConnection: () => void }) {
  const [mode, setMode] = useState<'natal' | 'horary'>('natal');
  const [birthDate, setBirthDate] = useState(''); const [birthTime, setBirthTime] = useState('');
  const [birthPlace, setBirthPlace] = useState<Place | null>(null);
  const [analysisDate, setAnalysisDate] = useState(todayIST()); const [analysisTime, setAnalysisTime] = useState('12:00');
  const [samePlace, setSamePlace] = useState(true); const [analysisPlace, setAnalysisPlace] = useState<Place | null>(null);
  const [domain, setDomain] = useState('career'); const [question, setQuestion] = useState('');
  const [uncertainty, setUncertainty] = useState(60); const [nodeMode, setNodeMode] = useState<'mean' | 'true'>('mean');
  const [birthFold, setBirthFold] = useState(''); const [analysisFold, setAnalysisFold] = useState('');
  const [autoClear, setAutoClear] = useState(true); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const [aiJob,setAiJob]=useState<AIJob|null>(null);
  const [useAI,setUseAI]=useState(true);
  const generation=useRef(0);
  useEffect(()=>()=>{generation.current++;},[]);
  const [report, setReport] = useState<Report | null>(null); const [reportRoute, setReportRoute] = useState('');
  const [sample, setSample] = useState(false);
  const [includeTransits, setIncludeTransits] = useState(true);
  const fileRef=useRef<HTMLInputElement>(null);
  const [horaryNumber, setHoraryNumber] = useState('1'); const [horary, setHorary] = useState<Horary | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const run = async (payload: ReadingInput) => {
    const serial=++generation.current;setAiJob(null);
    setBusy(true); setError(''); setReport(null);
    try { const { data, route } = await api<Report>(connection, '/api/v1/readings', payload); setReport(data); setReportRoute(route);
      if(useAI){
        if(!status?.ai?.configured)setAiJob({status:'not_configured',report_id:data.report_id});
        else void (async()=>{
          try{
            let job=(await api<AIJob>(connection,'/api/v1/ai/jobs',{report_id:data.report_id,consent:true})).data;
            if(generation.current!==serial)return;setAiJob(job);
            for(let i=0;i<180&&['queued','running'].includes(job.status);i++){
              await new Promise(r=>setTimeout(r,1000));if(generation.current!==serial)return;
              job=(await api<AIJob>(connection,`/api/v1/ai/jobs/${job.job_id}`)).data;if(generation.current===serial)setAiJob(job);
            }
            if(['queued','running'].includes(job.status)&&generation.current===serial)setAiJob({status:'failed',error:{code:'AI_WAIT_TIMEOUT',message:'Stopped waiting for the model. It may still be running in Termux; do not repeat the paid request immediately.'}});
          }catch(e){if(generation.current===serial)setAiJob({status:'failed',error:{code:'AI_REQUEST',message:e instanceof Error?e.message:'AI request failed; the chart remains available.'}});}
        })();
      }
      if (autoClear) setQuestion(''); toast(autoClear ? 'Calculated. Question field cleared; the report still includes your submitted question.' : 'Calculation complete. The server did not persist your report.'); }
    catch (e) { setError(e instanceof Error ? e.message : 'Calculation failed'); }
    finally { setBusy(false); }
  };
  const currentInput = ():ReadingInput => {
    const ap=samePlace?birthPlace:analysisPlace;
    if(!birthPlace||!ap)throw new Error('Choose both the birth location and analysis location.');
    return parseReadingInput(JSON.stringify({birth:{date:birthDate,time:birthTime,place:birthPlace,uncertainty_seconds:uncertainty,fold:birthFold?Number(birthFold):null},analysis:{date:analysisDate,time:analysisTime,place:ap,fold:analysisFold?Number(analysisFold):null},domain,question,node_mode:nodeMode,include_transits:includeTransits})).input;
  };
  const submit=(e:FormEvent)=>{e.preventDefault();try{const input=currentInput();setSample(false);void run(input);}catch(e){setError(e instanceof Error?e.message:'Review the inputs.');}};
  const saveInputs=async()=>{try{const input=currentInput();const result=await exportJsonFile(JSON.stringify(input,null,2),`rapkp-inputs-${input.birth.date}.json`);toast(result==='cancelled'?'Export cancelled.':`Inputs ${result}. The JSON contains birth details and your question.`);}catch(e){setError(e instanceof Error?e.message:'Could not export inputs.');}};
  const importInputs=async(file:File)=>{
    setBusy(true);setError('');
    try{
      if(file.size>512*1024)throw new Error('Choose a JSON file smaller than 512 KiB.');
      const {input:p,fromReport}=parseReadingInput(await file.text());
      setBirthDate(p.birth.date);setBirthTime(p.birth.time);setBirthPlace(p.birth.place);setUncertainty(p.birth.uncertainty_seconds);setBirthFold(p.birth.fold===null||p.birth.fold===undefined?'':String(p.birth.fold));
      setAnalysisDate(p.analysis.date);setAnalysisTime(p.analysis.time);setAnalysisPlace(p.analysis.place);setAnalysisFold(p.analysis.fold===null||p.analysis.fold===undefined?'':String(p.analysis.fold));setSamePlace(JSON.stringify(p.birth.place)===JSON.stringify(p.analysis.place));
      setDomain(p.domain);setQuestion(p.question);setNodeMode(p.node_mode);setIncludeTransits(p.include_transits);setReport(null);setAiJob(null);generation.current++;setSample(false);setMode('natal');
      toast(fromReport?'Inputs restored from the report. Positions and interpretation were not imported; review and recalculate.':'Inputs loaded locally. Review them before calculation; nothing has been sent.');
    }catch(e){setError(e instanceof Error?e.message:'Could not import the input file.');}
    finally{setBusy(false);if(fileRef.current)fileRef.current.value='';}
  };
  const loadSample = () => {
    const p = { ...places[0] }, date = todayIST();
    setBirthDate('1990-06-15'); setBirthTime('10:30'); setBirthPlace(p); setAnalysisDate(date); setAnalysisTime('12:00'); setSamePlace(true); setDomain('career'); setUncertainty(60); setNodeMode('mean'); setBirthFold(''); setAnalysisFold(''); setIncludeTransits(true); setSample(true); setMode('natal');
    const q = 'Explore the career connections in this synthetic example.'; setQuestion(q);
    void run({ birth: { date: '1990-06-15', time: '10:30', place: p, uncertainty_seconds: 60 }, analysis: { date, time: '12:00', place: p }, domain: 'career', question: q, node_mode: 'mean', include_transits: true });
  };
  const reset = () => { setBirthDate(''); setBirthTime(''); setBirthPlace(null); setAnalysisPlace(null); setQuestion(''); setReport(null); setAiJob(null); generation.current++; setError(''); setSample(false); setHorary(null); toast('Workbench cleared. No birth details were saved to browser storage.'); };
  const lookup = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setError(''); try { const { data } = await api<Horary>(connection, `/api/v1/horary/${Number(horaryNumber)}`); setHorary(data); } catch (e) { setError(e instanceof Error ? e.message : 'Lookup failed'); } finally { setBusy(false); } };

  return <>
    <div className="page-heading"><div><div className="eyebrow"><span className="tiny-spark">✧</span> THE RAPKP WORKBENCH <span className="upgrade-chip">{APP_SERIES}</span></div><h1>A clearer view of your chart.</h1><p>Precise inputs. Traceable calculations. Room for uncertainty.</p></div><button className="secondary-button sample-button" onClick={loadSample} disabled={busy}><Sparkles size={15} /> Try a sample <ArrowUpRight size={14} /></button></div>
    <div className="overview-strip"><div className="overview-item"><span className="mini-icon"><Database size={18} /></span><div><span className="small-label">CALCULATION CORE</span><b>{({swisseph:'Swiss Ephemeris',libephemeris:'libephemeris',openephem:'OpenEphem + Skyfield'} as Record<string,string>)[status?.ephemeris?.active_provider||status?.ephemeris?.provider||'']||'Checking provider'}</b><small><span className={`mini-dot ${status?.engine_ready ? 'green' : ''}`} />{status?.engine_ready?(status?.ephemeris?.active_provider==='openephem'?'Verified JPL kernel · chart check passed':'Installed provider / chart check passed'):'Waiting for engine verification'}</small></div></div><button className="overview-item method-item" onClick={() => navigate('rules')}><span className="mini-icon"><Orbit size={19} /></span><div><span className="small-label">CHART METHOD</span><b>Krishnamurti · Placidus</b><small>Explicit, inspectable conventions</small></div><ArrowUpRight size={14} /></button><div className="overview-item"><span className="mini-icon"><LockKeyhole size={17} /></span><div><span className="small-label">PRIVATE BY DEFAULT</span><b>No persistent chart storage</b><small>No automatic external AI calls</small></div></div></div>
    <div className="input-tools"><div><span className="small-label">YOUR INPUTS, PORTABLE</span><p>Save a request or restore inputs from an older report. No automatic calculation.</p></div><div className="input-tool-actions"><input ref={fileRef} type="file" accept="application/json,.json" className="sr-only" aria-label="Import calculation inputs" disabled={busy} onChange={e=>{const f=e.target.files?.[0];if(f)void importInputs(f);}}/><button className="secondary-button" disabled={busy} onClick={()=>fileRef.current?.click()}><Upload size={14}/> Import inputs</button><button className="secondary-button" disabled={busy} onClick={()=>void saveInputs()}><Download size={14}/> Save inputs</button></div></div>
    <div className="mode-bar"><div className="segmented"><button className={mode === 'natal' ? 'selected' : ''} onClick={() => { setMode('natal'); setError(''); }}><CircleDot size={15} /> Natal analysis</button><button className={mode === 'horary' ? 'selected' : ''} onClick={() => { setMode('horary'); setError(''); }}>Horary lookup <span>1–249</span></button></div><span className="candidate-label"><span /> VALIDATION CANDIDATE</span></div>
    {mode === 'natal' ? <div className="workbench-grid">
      <form className="card input-card" onSubmit={submit}>
        <div className="card-heading"><div className="step-label">01</div><div><h2>Start with the essentials</h2><p>A known birth time is required for cuspal analysis.</p></div><button type="button" className="icon-button" onClick={reset} aria-label="Clear workbench" title="Clear workbench"><RotateCcw size={16} /></button></div>
        <div className="form-body">
          {sample && <div className="sample-notice"><Sparkles size={13} /> Synthetic demonstration · not your personal profile</div>}
          <div className="form-grid"><label className="field"><span><CalendarDays size={12} /> Birth date</span><input aria-label="Birth date" type="date" min="1900-01-01" max="2099-12-31" required value={birthDate} onChange={e => { setBirthDate(e.target.value); setSample(false); }} /></label><label className="field"><span><Clock3 size={12} /> Birth time</span><input aria-label="Birth time" type="time" step="any" required value={birthTime} onChange={e => { setBirthTime(e.target.value); setSample(false); }} /></label></div>
          <PlacePicker value={birthPlace} onChange={setBirthPlace} label="Birth location" id="birth-place" />
          <div className="form-grid"><label className="field"><span>Focus of the reading</span><select aria-label="Focus of the reading" value={domain} onChange={e => setDomain(e.target.value)}>{domains.map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select></label><label className="field"><span>Birth-time uncertainty</span><select aria-label="Birth-time uncertainty" value={uncertainty} onChange={e => setUncertainty(Number(e.target.value))}><option value={60}>±1 minute</option><option value={300}>±5 minutes</option><option value={900}>±15 minutes</option><option value={0}>No sensitivity sample</option>{![0,60,300,900].includes(uncertainty) && <option value={uncertainty}>±{uncertainty} seconds (imported)</option>}</select></label></div>
          <label className="field"><span>Your question <small>OPTIONAL</small></span><textarea aria-label="Your question" value={question} maxLength={600} onChange={e => setQuestion(e.target.value)} placeholder="What would you like to understand about this area of life?" rows={2} /><small className="input-footnote">Context for your report; not an instruction to guarantee an outcome.</small></label>
          <details className="evaluation-settings" open><summary><span><SlidersHorizontal size={14} /> Evaluation & calculation settings</span><ChevronDown size={14} /></summary><div className="settings-inner"><div className="form-grid"><label className="field"><span>Evaluation date</span><input aria-label="Evaluation date" type="date" min="1900-01-01" max="2099-12-31" required value={analysisDate} onChange={e => setAnalysisDate(e.target.value)} /></label><label className="field"><span>Local evaluation time</span><input aria-label="Evaluation time" type="time" step="any" required value={analysisTime} onChange={e => setAnalysisTime(e.target.value)} /></label></div><label className="checkbox-line"><input type="checkbox" checked={samePlace} onChange={e => setSamePlace(e.target.checked)} /><span>Use the birth location for analysis and ruling planets</span></label>{!samePlace && <PlacePicker value={analysisPlace} onChange={setAnalysisPlace} label="Analysis location" id="analysis-place" />}<label className="checkbox-line"><input type="checkbox" checked={includeTransits} onChange={e=>setIncludeTransits(e.target.checked)}/><span>Include the transit table in the report</span></label><div className="node-setting"><span>Lunar nodes</span><div className="mini-segmented"><button type="button" className={nodeMode === 'mean' ? 'selected' : ''} onClick={() => setNodeMode('mean')}>Mean</button><button type="button" className={nodeMode === 'true' ? 'selected' : ''} onClick={() => setNodeMode('true')}>True / osculating</button></div></div><details className="dst-settings"><summary>Resolve an ambiguous daylight-saving time</summary><div className="form-grid"><label className="field"><span>Birth occurrence</span><select aria-label="Birth DST occurrence" value={birthFold} onChange={e => setBirthFold(e.target.value)}><option value="">Require clarification if ambiguous</option><option value="0">First occurrence</option><option value="1">Second occurrence</option></select></label><label className="field"><span>Evaluation occurrence</span><select aria-label="Evaluation DST occurrence" value={analysisFold} onChange={e => setAnalysisFold(e.target.value)}><option value="">Require clarification if ambiguous</option><option value="0">First occurrence</option><option value="1">Second occurrence</option></select></label></div></details></div></details>
          {error && <div className="inline-error" role="alert">{error}{status?.authentication_required && <button type="button" onClick={openConnection}>Check API token</button>}</div>}
          <button type="submit" className="primary-button calculate-button" disabled={busy}>{busy ? <><Loader2 className="spin" size={17} /> Calculating & checking…</> : <><Orbit size={17} /> Calculate & ask AI <ArrowRight size={17} /></>}</button>
          <label className="checkbox-line ai-opt-in"><input type="checkbox" checked={useAI} onChange={e=>setUseAI(e.target.checked)}/><span>Ask the configured AI after calculation (via Termux; provider consent/key required)</span></label><div className="form-bottom"><label className="checkbox-line"><input type="checkbox" checked={autoClear} onChange={e => setAutoClear(e.target.checked)} /><span>Clear question field after a successful calculation</span></label><span><LockKeyhole size={11} /> Inputs are sent to your configured API; reports are not persisted</span></div>
        </div>
      </form>
      <aside className="chart-column">
        <div className="card chart-card"><div className="chart-card-heading"><span className="small-label">{report ? 'LAST CALCULATED CHART' : 'A MAP, NOT A VERDICT'}</span><span className={`subtle-badge ${report ? 'green-badge' : ''}`}><span />{report ? 'Calculated' : 'Awaiting inputs'}</span></div><ChartWheel chart={report?.chart} />
          {report ? <><div className="chart-placement-strip">{[['Ascendant', report.chart.cusps[0]], ['Sun', report.chart.bodies.Sun], ['Moon', report.chart.bodies.Moon]].map(([name, p]) => { const pt = p as Report['chart']['cusps'][0]; return <div key={name as string}><small>{name as string}</small><b>{pt.sign}</b><span>{position(pt.longitude).value}</span></div>; })}</div><button className="inspect-link" onClick={() => reportRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>Inspect the full calculation <ArrowDownRight size={16} /></button></> : <div className="chart-empty-caption"><h3>Your chart begins with context.</h3><p>Add your details to reveal planetary positions, cuspal links and calculated periods.</p><span><Fingerprint size={13} /> No default person. No invented chart.</span></div>}
        </div>
        {report ? <div className="assessment-preview"><div className="preview-label"><span>BASELINE RULE SUPPORT</span><Info size={14} /></div><div className="score-row"><b>{report.assessment.score}<span>/10</span></b><span>weighted match points<br /><strong>not an event probability</strong></span></div><div className="support-track"><span style={{ width: `${report.assessment.support_percent}%` }} /></div><div className="decision-row"><span>Event judgment</span><b>Not determined</b></div><p>All 21 source-rule definitions are still pending. High support does not mean “yes.”</p></div> : <div className="gentle-note"><span className="soft-icon"><ShieldCheck size={20} /></span><div><h3>Clarity includes the limits.</h3><p>Calculations can be checked. Personal-event predictions cannot be guaranteed. We keep those two things separate.</p><button onClick={() => navigate('quality')}>See what’s verified <ArrowUpRight size={13} /></button></div></div>}
        <div className="source-note"><Info size={15} /><p><strong>A note on completeness.</strong> The supplied v26 files are the source baseline. Historical v17–v25 documents and the full numbered 21 rules have not been supplied.</p></div>
      </aside>
    </div> : <div className="horary-layout"><form className="card horary-card" onSubmit={lookup}><div className="eyebrow">KP SUBDIVISION REFERENCE</div><h2>One number.<br />One explicit interval.</h2><p>Explore the 249 sign / star / sub-lord segments. This tool maps the number only; it does not create a horary judgment.</p><label className="field"><span>Horary number · 1 to 249</span><input aria-label="Horary number" type="number" min="1" max="249" step="1" required value={horaryNumber} onChange={e => setHoraryNumber(e.target.value)} /></label><button className="primary-button" disabled={busy}>{busy ? <Loader2 size={16} className="spin" /> : <Orbit size={16} />} Look up segment <ArrowRight size={16} /></button>{error && <div className="inline-error" role="alert">{error}</div>}</form><div className="card horary-result">{horary ? <><span className="subtle-badge green-badge"><Check size={12} /> Table mapping</span><div className="horary-number">{horary.number.toString().padStart(3, '0')}</div><h2>{horary.sign} <span>· {horary.nakshatra}</span></h2><div className="horary-lords">{[['Sign lord', horary.sign_lord], ['Star lord', horary.star_lord], ['Sub-lord', horary.sub_lord]].map(([label, val]) => <div key={label}><small>{label}</small><b>{val}</b></div>)}</div><div className="interval"><span>{horary.start_degrees.toFixed(6)}° <small>INCLUSIVE</small></span><ArrowRight size={18} /><span>{horary.end_degrees.toFixed(6)}° <small>EXCLUSIVE</small></span></div><p className="source-note">{horary.note}</p></> : <><div className="horary-placeholder"><Orbit size={54} strokeWidth={.75} /></div><h3>The mathematics is inspectable.</h3><p>243 nakshatra/sub intervals, split at six additional sign boundaries, produce 249 segments.</p></>}</div></div>}
    {report && mode === 'natal' && <AIReading job={aiJob} onSetup={openConnection}/>}
    {report && mode === 'natal' && <div ref={reportRef} className="report-anchor"><ReportView report={report} route={reportRoute} toast={toast} aiJob={aiJob} /></div>}
  </>;
}
