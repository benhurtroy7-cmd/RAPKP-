import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.rapkp.one',
  appName: 'RAPKP One',
  webDir: 'site',
  server: { androidScheme: 'https' },
  loggingBehavior: 'none',
  android: { webContentsDebuggingEnabled: false },
};
export default config;
