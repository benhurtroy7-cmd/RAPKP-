"""Optional real Valkey/Redis protocol tests. Skipped when no server binary exists.

Set RAPKP_TEST_VALKEY_BINARY to a trusted local binary. No service survives the
fixture. Numeric tests and API tests do not require this optional executable.
"""

import os
import shutil
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from rapkp.api import create_app
from rapkp.config import Settings
from rapkp.security import RateLimiter


@pytest.fixture
def valkey(tmp_path):
    binary = os.getenv("RAPKP_TEST_VALKEY_BINARY") or shutil.which("valkey-server") or shutil.which("redis-server")
    if not binary:
        pytest.skip("No local Valkey/Redis server binary; shared-service tests not executed")
    # Isolated disposable server, device-loopback only. Blocking log read waits for
    # readiness without leaving a background service or polling a live deployment.
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    process = subprocess.Popen(
        [
            binary,
            "--bind",
            "127.0.0.1",
            "--port",
            str(port),
            "--save",
            "",
            "--appendonly",
            "no",
            "--dir",
            str(tmp_path),
            "--loglevel",
            "notice",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        while True:
            line = process.stdout.readline()
            if not line:
                raise RuntimeError("Ephemeral rate-limit server failed to start")
            if "Ready to accept connections" in line:
                break
        yield f"redis://127.0.0.1:{port}/0"
    finally:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        process.stdout.close()


def test_shared_atomic_limit_across_instances(valkey):
    a, b = RateLimiter(10, valkey), RateLimiter(10, valkey)

    def attempt(i):
        try:
            (a if i % 2 else b).check("same-service-token")
            return 200
        except HTTPException as exc:
            return exc.status_code

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(attempt, range(40)))
    assert results.count(200) == 10
    assert results.count(429) == 30
    keys = list(a.remote.scan_iter(match="rapkp:rate:*"))
    assert keys and 1 <= a.remote.ttl(keys[0]) <= 120
    assert "same-service-token" not in keys[0]
    a.remote.close()
    b.remote.close()


def test_two_api_instances_share_one_quota(valkey):
    settings = Settings(
        environment="production",
        api_key="test-only-not-a-shipped-key-" + "x" * 40,
        redis_url=valkey,
        workers=2,
        requests_per_minute=3,
    )
    header = {"Authorization": f"Bearer {settings.api_key}"}
    with TestClient(create_app(settings)) as a, TestClient(create_app(settings)) as b:
        assert a.get("/health/ready").status_code == 200
        assert a.get("/api/v1/horary/1", headers=header).status_code == 200
        assert b.get("/api/v1/horary/1", headers=header).status_code == 200
        assert a.get("/api/v1/horary/1", headers=header).status_code == 200
        assert b.get("/api/v1/horary/1", headers=header).status_code == 429
        assert b.get("/api/v1/status").json()["rate_limit_scope"] == "shared"


def test_shared_limiter_outage_fails_closed():
    # A closed, explicitly reserved-and-released local port has no rate service.
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    limiter = RateLimiter(10, f"redis://127.0.0.1:{port}/0")
    with pytest.raises(HTTPException) as e:
        limiter.check("test-client")
    assert e.value.status_code == 503
    with TestClient(create_app(Settings(environment="test", redis_url=f"redis://127.0.0.1:{port}/0"))) as c:
        assert c.get("/health/ready").status_code == 503
