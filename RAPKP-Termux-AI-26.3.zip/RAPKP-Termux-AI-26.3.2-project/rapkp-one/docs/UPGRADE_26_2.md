> Historical/general baseline. The current release is Termux-only; use TERMUX_AI_START.md, API_TERMUX.md and QA_TERMUX_AI.md. Native automation/live-account/device limits and AGPL engine terms there take precedence.

# What changed: 26.1 RC2 → 26.2

This is a feature upgrade and new Android build, not a renamed RC2 ZIP.

| Area | Earlier RC2 | 26.2 upgrade |
|---|---|---|
| Android identity | `com.rapkp.one`, code 2601002 | `com.rapkp.one.preview`, code **2603001**, launcher **RAPKP One 26.2** |
| Connection storage | Re-enter after every reload | Optional encrypted device-local connection using Android Keystore/AES-GCM; explicit forget action |
| Android JSON export | Text-only share sheet | Native system document picker saves actual JSON files |
| Inputs | Manual entry or synthetic demo | Request import/export; restore inputs from an earlier schema-1.0 report without trusting its positions/predictions |
| Navigation | Workbench lost when changing pages | Workbench/report preserved in memory across pages; Android Back handling |
| Build visibility | Small version/footer | About & updates page with UI/backend/installed package and build identity |
| Native privacy | Basic backup flag | Legacy + Android-12 backup/transfer exclusions; platform logging and WebView debugging disabled |
| Android artwork | Template bitmap splash and icon warnings | Vector splash, transparent legacy icons, adaptive/monochrome icons |
| Toolchain | Gradle 8.14.3, AppCompat 1.7.1 | Gradle **8.14.5**, AppCompat **1.8.0**, Capacitor App **8.1.1** |
| Android lint | 32 warnings | **0 errors, 0 warnings** in the recorded run |
| New checks | 25 native-HTTP contract cases | Those 25 plus **35 import/storage/export cases**, **6 JVM crypto cases**, and **12 additional browser cases** |

The ephemeris/numerical conventions remain pinned for reproducibility and passed their regression suite. This release does not invent the missing 21 rules or claim improved/calibrated personal-event prediction accuracy.

## Migration

Install the new preview APK normally and open **RAPKP One 26.2**, not the older icon. It is a separate package to avoid signing-key conflicts; it does not replace or migrate the old app automatically. Export an old report as JSON, import it in 26.2, review the recovered inputs, and recalculate. Re-enter your endpoint/token; opt in to encrypted storage only if you want it.

The APK remains a hybrid Capacitor app with native Android Java functionality. Its calculator runs on your configured HTTPS service or same-phone Termux, not as an embedded Python runtime in the APK. No physical Android device/emulator, hardware Keystore, system-picker interaction or store approval is claimed as tested here.
