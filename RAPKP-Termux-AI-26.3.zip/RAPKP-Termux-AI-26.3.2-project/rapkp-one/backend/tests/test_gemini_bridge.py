import importlib.util
import json

import httpx
import pytest
from rapkp.config import ROOT

spec = importlib.util.spec_from_file_location("gemini_bridge", ROOT / "integrations/gemini/bridge.py")
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


def test_bridge_requires_consent_before_network():
    class Never:
        def post(self, *args, **kwargs):
            raise AssertionError("network must not be called")

    with pytest.raises(ValueError, match="consent"):
        bridge.run_bridge(
            {}, model="available-model", gemini_key="key", rapkp_base="https://api.example", client=Never()
        )


@pytest.mark.parametrize(
    "base",
    [
        "file:///tmp",
        "http://external.example",
        "https://user:pass@example.com",
        "https://example.com/?key=x",
        "not-a-url",
    ],
)
def test_bridge_rejects_unsafe_config(base):
    with pytest.raises(ValueError):
        bridge.check_base(base)


def test_mock_function_call_keeps_frozen_inputs_and_separates_prose(payload):
    calls = []
    report = json.loads((ROOT / "qa/sample-report.json").read_text())

    def handler(request):
        calls.append(request)
        body = json.loads(request.content)
        if request.url.host == "api.example":
            assert body == payload
            assert request.headers["authorization"] == "Bearer backend-only"
            assert "x-goog-api-key" not in request.headers
            return httpx.Response(200, json=report)
        assert request.headers["x-goog-api-key"] == "provider-only"
        assert "authorization" not in request.headers
        if len(calls) == 1:
            return httpx.Response(
                200,
                json={
                    "candidates": [
                        {
                            "content": {
                                "role": "model",
                                "parts": [
                                    {
                                        "functionCall": {"name": "calculate_rapkp", "args": {}},
                                        "thoughtSignature": "preserve-me",
                                    }
                                ],
                            }
                        }
                    ]
                },
            )
        shared = body["contents"][2]["parts"][0]["functionResponse"]["response"]["report"]
        assert "input_summary" not in shared and "question" not in shared
        assert "latitude" not in shared["chart"] and "utc" not in shared["chart"]
        assert body["contents"][1]["parts"][0]["thoughtSignature"] == "preserve-me"
        return httpx.Response(
            200,
            json={
                "candidates": [
                    {
                        "content": {
                            "role": "model",
                            "parts": [{"text": "Mock explanation. The judgment remains not determined."}],
                        }
                    }
                ]
            },
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as c:
        result = bridge.run_bridge(
            payload,
            model="account-available-model",
            gemini_key="provider-only",
            rapkp_base="https://api.example",
            rapkp_key="backend-only",
            allow_external=True,
            client=c,
        )
    assert len(calls) == 3
    assert result["calculation_report"] == report
    assert result["prediction_probability"] is None
    assert result["provider_output_fact_checked"] is False


def test_model_cannot_change_request_or_select_other_tool(payload):
    def handler(request):
        return httpx.Response(
            200,
            json={
                "candidates": [
                    {
                        "content": {
                            "role": "model",
                            "parts": [
                                {"functionCall": {"name": "calculate_rapkp", "args": {"url": "https://evil.example"}}}
                            ],
                        }
                    }
                ]
            },
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as c:
        with pytest.raises(ValueError, match="approved"):
            bridge.run_bridge(
                payload,
                model="account-model",
                gemini_key="key",
                rapkp_base="https://api.example",
                allow_external=True,
                client=c,
            )


def test_bridge_model_id_and_key_are_explicit():
    with pytest.raises(ValueError, match="model ID"):
        bridge.run_bridge(
            {}, model="../../elsewhere", gemini_key="key", rapkp_base="https://api.example", allow_external=True
        )
    with pytest.raises(ValueError, match="API_KEY"):
        bridge.run_bridge({}, model="valid-model", gemini_key="", rapkp_base="https://api.example", allow_external=True)
