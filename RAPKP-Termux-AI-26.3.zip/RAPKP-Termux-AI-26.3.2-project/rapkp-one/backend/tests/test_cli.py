import json

from rapkp.__main__ import main


def test_cli_horary(capsys):
    assert main(["horary", "249"]) == 0
    assert json.loads(capsys.readouterr().out)["number"] == 249


def test_cli_rejects_bad_horary(capsys):
    assert main(["horary", "0"]) == 1
    assert "not completed" in capsys.readouterr().err


def test_cli_calculate_and_bad_input(tmp_path, payload, capsys):
    src = tmp_path / "request.json"
    out = tmp_path / "report.json"
    src.write_text(json.dumps(payload))
    assert main(["calculate", str(src), "--output", str(out)]) == 0
    assert json.loads(out.read_text())["assessment"]["probability"] is None
    src.write_text("{malformed")
    assert main(["calculate", str(src)]) == 1
    assert "traceback" not in capsys.readouterr().err.lower()


def test_cli_batch_does_not_turn_bad_rows_into_data(tmp_path, payload, capsys):
    src = tmp_path / "requests.jsonl"
    out = tmp_path / "reports.jsonl"
    src.write_text(json.dumps(payload) + "\n\n" + json.dumps({"question": "missing mandatory fields"}) + "\n")
    assert main(["batch", str(src), str(out)]) == 2
    rows = [json.loads(line) for line in out.read_text().splitlines()]
    assert rows[0]["ok"] is True and rows[1]["ok"] is False
    assert "report" not in rows[1]
    assert main(["batch", str(src), str(src)]) == 1
