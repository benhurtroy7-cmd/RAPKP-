"""Explicit KP subdivisions. Boundary intervals are start-inclusive, end-exclusive.

No rule in this module is attributed to the missing proprietary 21-rule set.
"""

import math
from bisect import bisect_right
from fractions import Fraction

ORDER = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"]
YEARS = dict(zip(ORDER, [7, 20, 6, 10, 7, 18, 16, 19, 17], strict=True))
SIGNS = [
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
    "Capricorn",
    "Aquarius",
    "Pisces",
]
SIGN_LORDS = [
    "Mars",
    "Venus",
    "Mercury",
    "Moon",
    "Sun",
    "Mercury",
    "Venus",
    "Mars",
    "Jupiter",
    "Saturn",
    "Saturn",
    "Jupiter",
]
NAKSHATRAS = [
    "Ashwini",
    "Bharani",
    "Krittika",
    "Rohini",
    "Mrigashira",
    "Ardra",
    "Punarvasu",
    "Pushya",
    "Ashlesha",
    "Magha",
    "Purva Phalguni",
    "Uttara Phalguni",
    "Hasta",
    "Chitra",
    "Swati",
    "Vishakha",
    "Anuradha",
    "Jyeshtha",
    "Mula",
    "Purva Ashadha",
    "Uttara Ashadha",
    "Shravana",
    "Dhanishta",
    "Shatabhisha",
    "Purva Bhadrapada",
    "Uttara Bhadrapada",
    "Revati",
]


def norm(lon: float) -> float:
    if not math.isfinite(lon):
        raise ValueError("Longitude must be finite")
    return lon % 360


def cyclic_lords(first: str) -> list[str]:
    index = ORDER.index(first)
    return ORDER[index:] + ORDER[:index]


def _segments(start: Fraction, span: Fraction, first: str):
    position = start
    result = []
    for lord in cyclic_lords(first):
        end = position + span * YEARS[lord] / 120
        result.append((position, end, lord))
        position = end
    return result


STAR_WIDTH = Fraction(40, 3)
SUB_SEGMENTS = []
SUBSUB_SEGMENTS = []
for n in range(27):
    for lo, hi, lord in _segments(n * STAR_WIDTH, STAR_WIDTH, ORDER[n % 9]):
        SUB_SEGMENTS.append((lo, hi, ORDER[n % 9], lord, n))
        for a, b, subsub in _segments(lo, hi - lo, lord):
            SUBSUB_SEGMENTS.append((a, b, ORDER[n % 9], lord, subsub, n))
SUB_STARTS = [float(s[0]) for s in SUB_SEGMENTS]
SUBSUB_STARTS = [float(s[0]) for s in SUBSUB_SEGMENTS]


def lords(longitude: float) -> dict:
    lon = norm(longitude)
    sub = SUB_SEGMENTS[bisect_right(SUB_STARTS, lon) - 1]
    deep = SUBSUB_SEGMENTS[bisect_right(SUBSUB_STARTS, lon) - 1]
    lo, hi, star_lord, sub_lord, idx = sub
    nak_start = float(idx * STAR_WIDTH)
    nak_progress = max(0, min(1, (lon - nak_start) / float(STAR_WIDTH)))
    return {
        "sign": SIGNS[int(lon // 30)],
        "sign_lord": SIGN_LORDS[int(lon // 30)],
        "degree_in_sign": lon % 30,
        "nakshatra": NAKSHATRAS[idx],
        "nakshatra_index": idx,
        "pada": min(4, int((lon - nak_start) / (float(STAR_WIDTH) / 4)) + 1),
        "star_lord": star_lord,
        "sub_lord": sub_lord,
        "sub_sub_lord": deep[4],
        "nakshatra_fraction_elapsed": nak_progress,
        "sub_boundary_distance_arcsec": max(0, min(lon - float(lo), float(hi) - lon) * 3600),
        "sub_sub_boundary_distance_arcsec": max(0, min(lon - float(deep[0]), float(deep[1]) - lon) * 3600),
    }


def house_of(longitude: float, cusps: list[float]) -> int:
    if len(cusps) != 12 or any(not math.isfinite(x) for x in cusps):
        raise ValueError("Twelve finite cusps are required")
    lon = norm(longitude)
    spans = [(cusps[(i + 1) % 12] - c) % 360 for i, c in enumerate(cusps)]
    if any(s <= 0 for s in spans) or not math.isclose(sum(spans), 360, abs_tol=1e-7):
        raise ValueError("Cusps must cover one non-degenerate zodiac cycle")
    for i, c in enumerate(cusps):
        if (lon - c) % 360 < spans[i]:
            return i + 1
    raise ValueError("House assignment failed")


# The 243 nakshatra/sub intervals split at six additional rashi boundaries = 249.
HORARY_SEGMENTS = []
for lo, hi, star, sub, idx in SUB_SEGMENTS:
    cuts = [lo] + [Fraction(k * 30) for k in range(1, 12) if lo < k * 30 < hi] + [hi]
    for a, b in zip(cuts, cuts[1:], strict=False):
        HORARY_SEGMENTS.append(
            {
                "number": len(HORARY_SEGMENTS) + 1,
                "start_degrees": float(a),
                "end_degrees": float(b),
                "sign": SIGNS[int(a // 30)],
                "sign_lord": SIGN_LORDS[int(a // 30)],
                "star_lord": star,
                "sub_lord": sub,
                "nakshatra": NAKSHATRAS[idx],
            }
        )
assert len(HORARY_SEGMENTS) == 249


def horary_segment(number: int) -> dict:
    if isinstance(number, bool) or not isinstance(number, int) or not 1 <= number <= 249:
        raise ValueError("Horary number must be an integer from 1 to 249")
    return {
        **HORARY_SEGMENTS[number - 1],
        "status": "table_only",
        "note": "Verified subdivision mapping, not a horary judgment or a derived house chart. Full horary judgment requires an approved convention and rule pack.",
    }
