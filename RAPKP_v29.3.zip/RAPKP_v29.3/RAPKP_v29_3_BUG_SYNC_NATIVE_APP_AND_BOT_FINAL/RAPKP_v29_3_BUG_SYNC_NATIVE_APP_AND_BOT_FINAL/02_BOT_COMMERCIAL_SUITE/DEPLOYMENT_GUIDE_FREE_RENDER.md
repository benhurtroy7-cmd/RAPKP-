# Free Render Deployment Guide

## Files required in GitHub repo root

- Dockerfile
- render.yaml
- requirements.txt
- server.py
- engine.py
- domains.py
- pdf_report.py

## Environment variables

RAPKP_TOKEN=client-secret-token
PORT=8000

## Test URLs

/health
/api/ask?query=third%20marriage&token=TOKEN
/api/chart?token=TOKEN
/api/chart-pdf?token=TOKEN
/api/pdf-reading?token=TOKEN
/api/rules?token=TOKEN

## Free Render limitation

Render Free may sleep. First request can take 30–90 seconds. v28/v29 APK includes cloud warm-up retry and demo fallback.
