import json
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from threading import BoundedSemaphore
from uuid import uuid4
from zoneinfo import ZoneInfo

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .config import ROOT, Settings
from .engine import KERNEL_SHA256, AstroEngine
from .errors import CalculationError
from .kp import horary_segment
from .models import ReadingRequest, ReadingResponse, ReportBugRequest
from .report import create_report
from .rules import DOMAINS, registry
from .security import RateLimiter, RequestSizeLimit, check_bearer


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = (settings or Settings.from_env()).validate()

    @asynccontextmanager
    async def lifespan(app):
        try:
            app.state.engine = AstroEngine(settings.kernel_path)
            app.state.engine_error = None
        except CalculationError as e:
            app.state.engine = None
            app.state.engine_error = {"code": e.code, "message": e.message}
        try:
            yield
        finally:
            if app.state.engine is not None:
                app.state.engine.close()

    app = FastAPI(
        title="RAPKP One API",
        version=__version__,
        lifespan=lifespan,
        description="Auditable KP calculation API. Rule support is not an outcome probability. No external model is needed for core computation.",
        docs_url=None,
        redoc_url=None,
    )
    app.state.settings = settings
    app.state.limiter = RateLimiter(settings.requests_per_minute, settings.redis_url)
    app.state.slots = BoundedSemaphore(settings.max_concurrent)
    app.state.engine = None
    app.state.engine_error = {"code": "NOT_STARTED", "message": "Engine not initialized"}
    app.add_middleware(RequestSizeLimit, max_bytes=32768)
    if settings.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(settings.allowed_origins),
            allow_methods=["GET", "POST"],
            allow_headers=["Authorization", "Content-Type"],
            allow_credentials=False,
        )

    @app.middleware("http")
    async def headers(request: Request, call_next):
        request_id = uuid4().hex[:12]
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        if request.url.path.startswith("/api"):
            response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self' https:; object-src 'none'; base-uri 'self'; form-action 'self'"
        )
        return response

    @app.exception_handler(CalculationError)
    async def calculation_error(request: Request, exc: CalculationError):
        return JSONResponse(
            {
                "error": {"code": exc.code, "message": exc.message},
                "request_id": getattr(request.state, "request_id", None),
            },
            status_code=exc.status,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        errors = [
            {"field": ".".join(str(x) for x in e["loc"]), "message": e["msg"], "type": e["type"]} for e in exc.errors()
        ]
        return JSONResponse(
            {"error": {"code": "INPUT_VALIDATION", "message": "Correct the supplied fields.", "fields": errors}},
            status_code=422,
        )

    @app.exception_handler(Exception)
    async def unexpected_error(request: Request, exc: Exception):
        # Deliberately omit payloads, secrets and exception strings from responses.
        return JSONResponse(
            {
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "The request could not be completed. No substitute prediction was generated.",
                },
                "request_id": getattr(request.state, "request_id", None),
            },
            status_code=500,
        )

    def authorized(request: Request, authorization: str = Header(default="")):
        check_bearer(authorization, settings.api_key, settings.environment == "production")
        identity = authorization if settings.api_key else (request.client.host if request.client else "local")
        app.state.limiter.check(identity)

    @app.get("/health/live", include_in_schema=False)
    def liveness():
        return {"status": "alive", "version": __version__}

    @app.get("/health/ready", include_in_schema=False)
    def readiness():
        if app.state.engine is None:
            return JSONResponse({"status": "not_ready", "error": app.state.engine_error}, status_code=503)
        if app.state.limiter.remote is not None:
            try:
                app.state.limiter.remote.ping()
            except Exception:
                return JSONResponse({"status": "not_ready", "error": {"code": "THROTTLE_UNAVAILABLE"}}, status_code=503)
        return {"status": "ready", "kernel_verified": True}

    @app.get("/api/v1/status", operation_id="getRapkpStatus")
    def status():
        qa_path = ROOT / "qa/verification.json"
        qa = json.loads(qa_path.read_text()) if qa_path.is_file() else {"status": "not_run"}
        return {
            "product": "RAPKP One",
            "version": __version__,
            "environment": settings.environment,
            "release_status": "validation_candidate",
            "now_ist": datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(),
            "engine_ready": app.state.engine is not None,
            "engine_error": app.state.engine_error,
            # The cloud/QA service really computes with the pinned OpenEphem/Skyfield
            # kernel. Report it instead of letting the interface imply another engine.
            "ephemeris": {
                "provider": "openephem",
                "active_provider": "openephem",
                "path": str(settings.kernel_path),
                "lib_file": "",
                "engine": "OpenEphem 0.3.0 + Skyfield 1.55 + JPL DE440s",
            },
            "authentication_required": bool(settings.api_key) or settings.environment == "production",
            "rate_limit_scope": "shared" if settings.redis_url else "per_process",
            "kernel_sha256": KERNEL_SHA256,
            "qa": qa,
            "source_rules_expected": 21,
            "source_rules_defined": 10,
            "source_rules_calibrated": 0,
            "astrosage": "not_configured",
            "external_ai": "not_connected",
            "event_accuracy": "not_established",
            "privacy": {
                "persistent_chart_storage": False,
                "in_memory_chart_cache_entries_per_worker": 96,
                "outbound_ai_calls": False,
                "automatic_bug_uploads": False,
            },
            "limits": {
                "dates": "1900–2099",
                "placidus_latitude": "strictly between −66° and +66°",
                "body_bytes": 32768,
            },
        }

    @app.get("/api/v1/domains", operation_id="listDomains")
    def domains():
        return {"domains": [{"id": key, **val} for key, val in DOMAINS.items()]}

    @app.get("/api/v1/rules", operation_id="getRuleCoverage")
    def rules():
        return registry()

    @app.get("/api/v1/horary/{number}", operation_id="getHorarySegment", dependencies=[Depends(authorized)])
    def horary(number: int):
        try:
            return horary_segment(number)
        except ValueError as e:
            raise CalculationError("HORARY_RANGE", str(e)) from e

    @app.post(
        "/api/v1/readings",
        response_model=ReadingResponse,
        operation_id="calculateRapkpReading",
        dependencies=[Depends(authorized)],
    )
    def reading(payload: ReadingRequest):
        if app.state.engine is None:
            error = app.state.engine_error
            raise CalculationError(error["code"], error["message"], 503)
        if not app.state.slots.acquire(blocking=False):
            raise HTTPException(
                429,
                detail={"code": "COMPUTE_BUSY", "message": "All compute slots are occupied. Retry shortly."},
                headers={"Retry-After": "2"},
            )
        try:
            return create_report(app.state.engine, payload)
        finally:
            app.state.slots.release()

    @app.post("/api/ask", response_model=ReadingResponse, include_in_schema=False, dependencies=[Depends(authorized)])
    def legacy_post(payload: ReadingRequest):
        return reading(payload)

    @app.get("/api/ask", include_in_schema=False)
    def legacy_get():
        return JSONResponse(
            {
                "error": {
                    "code": "STRUCTURED_INPUT_REQUIRED",
                    "message": "Use POST /api/v1/readings with explicit birth and analysis inputs. A free-text GET query will not use a default person's profile.",
                }
            },
            status_code=400,
        )

    @app.post("/api/report_bug", dependencies=[Depends(authorized)], include_in_schema=False)
    def bug_report(payload: ReportBugRequest):
        return {
            "report_id": uuid4().hex,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "status": "prepared_only",
            "sent_to_arena": False,
            "stored": False,
            "report": payload.model_dump(),
            "note": "Download and send this report to your own support channel. No Arena reporting endpoint has been authenticated.",
        }

    @app.get("/api/v1/integration/{name}", include_in_schema=False)
    def integration(name: str):
        allow = {
            "chatgpt-schema": ROOT / "integrations/chatgpt/openapi.json",
            "chatgpt-instructions": ROOT / "integrations/chatgpt/INSTRUCTIONS.md",
            "gem-instructions": ROOT / "integrations/gemini/GEM_INSTRUCTIONS.md",
        }
        path = allow.get(name)
        if path is None or not path.is_file():
            raise HTTPException(404, detail="Integration file not found")
        return FileResponse(path, filename=path.name)

    @app.get("/manifest.webmanifest", include_in_schema=False)
    def manifest():
        path = settings.static_path / "manifest.webmanifest"
        if not path.is_file():
            raise HTTPException(404)
        return FileResponse(path, media_type="application/manifest+json")

    if (settings.static_path / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=settings.static_path / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def frontend(path: str):
        if path.startswith(("api/", "health/")):
            raise HTTPException(404, detail="Unknown API endpoint")
        safe_files = {"icon.svg", "icon-192.png", "icon-512.png", "sw.js"}
        if path in safe_files and (settings.static_path / path).is_file():
            response = FileResponse(settings.static_path / path)
            if path == "sw.js":
                response.headers["Cache-Control"] = "no-cache"
            return response
        index = settings.static_path / "index.html"
        if not index.is_file():
            return JSONResponse(
                {"product": "RAPKP One", "message": "API ready. Build the frontend to enable the workbench."}
            )
        response = FileResponse(index)
        response.headers["Cache-Control"] = "no-cache"
        return response

    return app
