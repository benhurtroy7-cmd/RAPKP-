const test=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');const ts=require('typescript');
const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/device.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const conn={primary:'https://api.example',primaryToken:'synthetic-key',fallback:'',fallbackToken:'',allowFallback:false};
function moduleFor(platform,plugin={},available=true){let saved;const result={};vm.runInNewContext(code,{exports:result,Error,require:n=>{
 if(n==='@capacitor/core')return {Capacitor:{getPlatform:()=>platform,isPluginAvailable:()=>available},registerPlugin:()=>plugin};
 if(n==='@capacitor/share')return {Share:{share:async()=>{}}};
 if(n==='./api')return {isNative:()=>platform!=='web',validateEndpoint:v=>{if(!v)return '';const u=new URL(v);if(u.protocol!=='https:'&&!(platform==='android'&&u.hostname==='127.0.0.1'))throw new Error('unsafe URL');return v;}};
 if(n==='./utils')return {saveText:(text,name)=>{saved={text,name};}};throw new Error(n);
}});return {api:result,saved:()=>saved};}
test('browser never attempts native connection persistence',async()=>{let called=false;const {api}=moduleFor('web',{loadConnection:()=>{called=true;}});assert.equal(await api.restoreConnection(),null);await api.forgetConnection();assert.equal(called,false);await assert.rejects(api.rememberConnection(conn),/requires this Android build/);});
test('Android restores the validated encrypted payload',async()=>{const {api}=moduleFor('android',{loadConnection:async()=>({found:true,json:JSON.stringify(conn)})});assert.equal((await api.restoreConnection()).primaryToken,'synthetic-key');});
test('missing saved profile stays absent',async()=>{const {api}=moduleFor('android',{loadConnection:async()=>({found:false})});assert.equal(await api.restoreConnection(),null);});
test('malformed saved profile is rejected',async()=>{for(const json of ['{broken','{}',JSON.stringify({...conn,allowFallback:true})]){const {api}=moduleFor('android',{loadConnection:async()=>({found:true,json})});await assert.rejects(api.restoreConnection());}});
test('explicit save contains only connection fields',async()=>{let data;const {api}=moduleFor('android',{saveConnection:async x=>{data=JSON.parse(x.json);return {saved:true};}});await api.rememberConnection({...conn,birth:'must-not-store'});assert.equal(data.birth,undefined);assert.equal(data.primaryToken,conn.primaryToken);});
test('explicit forget invokes native deletion',async()=>{let called=false;const {api}=moduleFor('android',{clearConnection:async()=>{called=true;return {cleared:true};}});await api.forgetConnection();assert.equal(called,true);});
test('native JSON export respects save and cancellation',async()=>{for(const flag of [true,false]){const {api}=moduleFor('android',{exportJson:async x=>{assert.equal(x.filename,'inputs.json');return {saved:flag};}});assert.equal(await api.exportJsonFile('{}','inputs.json'),flag?'saved':'cancelled');}});
test('web JSON export is an explicit local download',async()=>{const m=moduleFor('web');assert.equal(await m.api.exportJsonFile('{}','x.json'),'saved');assert.deepEqual(m.saved(),{text:'{}',name:'x.json'});});
