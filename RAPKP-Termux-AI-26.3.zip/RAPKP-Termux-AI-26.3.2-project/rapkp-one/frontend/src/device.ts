import { Capacitor, registerPlugin } from '@capacitor/core';
import { Share } from '@capacitor/share';
import { isNative, validateEndpoint, type BaseConnection, type Connection } from './api';
import { saveText } from './utils';

interface DevicePlugin {
  openTermux(): Promise<{opened:boolean}>;
  loadConnection(): Promise<{ found: boolean; json?: string }>;
  saveConnection(options: { json: string }): Promise<{ saved: boolean }>;
  clearConnection(): Promise<{ cleared: boolean }>;
  exportJson(options: { filename: string; text: string }): Promise<{ saved: boolean; cancelled?: boolean }>;
}
const native = registerPlugin<DevicePlugin>('RapkpDevice');
export const hasDeviceFeatures = () => Capacitor.getPlatform() === 'android' && Capacitor.isPluginAvailable('RapkpDevice');

export function checkedConnection(value: unknown): Connection {
  if (!value || typeof value !== 'object') throw new Error('Saved connection is invalid. Re-enter it.');
  const c = value as Record<string, unknown>;
  for (const key of ['primary','primaryToken','fallback','fallbackToken']) if (typeof c[key] !== 'string' || (c[key] as string).length > 4096) throw new Error('Saved connection is invalid. Re-enter it.');
  if (typeof c.allowFallback !== 'boolean') throw new Error('Saved connection is invalid. Re-enter it.');
  const primary=validateEndpoint(c.primary as string), fallback=validateEndpoint(c.fallback as string);
  if (!primary || (c.allowFallback && !fallback) || (fallback && fallback===primary)) throw new Error('Saved endpoints need review. Re-enter them.');
  const result:Connection={ primary, primaryToken:c.primaryToken as string, fallback, fallbackToken:c.fallbackToken as string, allowFallback:c.allowFallback };
  if(c.mode==='cloud'||c.mode==='termux'||c.mode==='web')result.mode=c.mode;
  if(c.profiles&&typeof c.profiles==='object'){
    const raw=c.profiles as Record<string,unknown>;
    const profile=(v:unknown):BaseConnection=>{
      if(!v||typeof v!=='object')throw new Error('Saved connection profiles need review.');
      const p=v as Record<string,unknown>;
      for(const k of ['primary','primaryToken','fallback','fallbackToken'])if(typeof p[k]!=='string'||(p[k] as string).length>4096)throw new Error('Saved connection profiles need review.');
      if(typeof p.allowFallback!=='boolean')throw new Error('Saved connection profiles need review.');
      return {primary:p.primary as string,primaryToken:p.primaryToken as string,fallback:p.fallback as string,fallbackToken:p.fallbackToken as string,allowFallback:p.allowFallback};
    };
    result.profiles={cloud:profile(raw.cloud),termux:profile(raw.termux)};
  }
  return result;
}
export async function restoreConnection(): Promise<Connection | null> {
  if (!hasDeviceFeatures()) return null;
  const r=await native.loadConnection();
  if (!r.found) return null;
  if (typeof r.json!=='string') throw new Error('Saved connection could not be read.');
  return checkedConnection(JSON.parse(r.json));
}
export async function rememberConnection(c: Connection): Promise<void> {
  if (!hasDeviceFeatures()) throw new Error('Encrypted connection storage requires this Android build.');
  await native.saveConnection({json:JSON.stringify(checkedConnection(c))});
}
export async function forgetConnection(): Promise<void> {
  if (hasDeviceFeatures()) await native.clearConnection();
}
export async function exportJsonFile(text: string, filename: string): Promise<'saved' | 'shared' | 'cancelled'> {
  if (hasDeviceFeatures()) { const r=await native.exportJson({text,filename}); return r.saved?'saved':'cancelled'; }
  if (isNative()) { try { await Share.share({title:filename,text}); return 'shared'; } catch { return 'cancelled'; } }
  saveText(text,filename);return 'saved';
}

export async function openTermuxApp():Promise<void>{if(!hasDeviceFeatures())throw new Error('Open the Termux app on your Android phone.');await native.openTermux();}
