import math

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from rapkp.kp import (
    HORARY_SEGMENTS,
    ORDER,
    SIGN_LORDS,
    SUB_SEGMENTS,
    SUBSUB_SEGMENTS,
    YEARS,
    horary_segment,
    house_of,
    lords,
)


def test_period_weights_and_segment_counts():
    assert sum(YEARS.values()) == 120
    assert len(ORDER) == 9
    assert len(SUB_SEGMENTS) == 243
    assert len(SUBSUB_SEGMENTS) == 2187
    assert len(HORARY_SEGMENTS) == 249


@pytest.mark.parametrize("i", range(249))
def test_every_horary_interval_is_contiguous_and_correct(i):
    seg = horary_segment(i + 1)
    assert seg["number"] == i + 1
    assert seg["start_degrees"] < seg["end_degrees"]
    assert seg["start_degrees"] == (HORARY_SEGMENTS[i - 1]["end_degrees"] if i else 0)
    mid = (seg["start_degrees"] + seg["end_degrees"]) / 2
    result = lords(mid)
    assert result["star_lord"] == seg["star_lord"]
    assert result["sub_lord"] == seg["sub_lord"]
    assert result["sign"] == seg["sign"]
    assert seg["status"] == "table_only"


def test_horary_last_boundary():
    assert horary_segment(249)["end_degrees"] == 360
    assert horary_segment(1)["sub_lord"] == "Ketu"


@pytest.mark.parametrize("invalid", [0, 250, -1, True, 1.5])
def test_horary_rejects_bad_number(invalid):
    with pytest.raises(ValueError):
        horary_segment(invalid)


@pytest.mark.parametrize("segment", SUB_SEGMENTS)
def test_sub_start_is_inclusive_and_end_is_exclusive(segment):
    a, b, star, sub, _ = segment
    got = lords(float(a))
    assert got["star_lord"] == star
    assert got["sub_lord"] == sub
    assert lords(float((a + b) / 2))["sub_lord"] == sub


@pytest.mark.parametrize("segment", SUBSUB_SEGMENTS[::17])
def test_subsub_boundaries(segment):
    a, b, star, sub, deep, _ = segment
    got = lords(float((a + b) / 2))
    assert (got["star_lord"], got["sub_lord"], got["sub_sub_lord"]) == (star, sub, deep)


def test_zero_and_wrap():
    assert lords(0)["star_lord"] == "Ketu"
    assert lords(360) == lords(0)
    assert lords(-1) == lords(359)
    assert lords(0)["sign_lord"] == SIGN_LORDS[0]


@pytest.mark.parametrize("value", [math.inf, -math.inf, math.nan])
def test_nonfinite_rejected(value):
    with pytest.raises(ValueError):
        lords(value)


@given(st.floats(min_value=0, max_value=359.999999, allow_nan=False, allow_infinity=False))
@settings(max_examples=150, deadline=None)
def test_arbitrary_lords_are_valid(lon):
    x = lords(lon)
    assert x["star_lord"] in ORDER and x["sub_lord"] in ORDER and x["sub_sub_lord"] in ORDER
    assert 0 <= x["nakshatra_index"] < 27
    assert 0 <= x["nakshatra_fraction_elapsed"] < 1
    assert 1 <= x["pada"] <= 4
    assert x["sub_boundary_distance_arcsec"] >= 0


def test_house_boundaries_wrap():
    cusps = [(350 + 30 * i) % 360 for i in range(12)]
    assert house_of(0, cusps) == 1
    assert house_of(349.9, cusps) == 12
    for i, c in enumerate(cusps):
        assert house_of(c, cusps) == i + 1


@pytest.mark.parametrize(
    "cusps", [[0] * 12, [0] * 11, [float("nan")] * 12, list(reversed([i * 30 for i in range(12)]))]
)
def test_bad_cusp_cycles_rejected(cusps):
    with pytest.raises(ValueError):
        house_of(12, cusps)
