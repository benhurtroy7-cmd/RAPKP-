import hashlib
import hmac
import json
import threading

import httpx
import pytest
from rapkp.errors import CalculationError
from rapkp.termux_runtime.server import Server, State, atomic_json


def test_pairing_challenge_and_response_do_not_disclose_secret(tmp_path):
    token = "c" * 64
    atomic_json(tmp_path / "config.json", {"token": token, "ephemeris": {"provider": "swisseph"}, "ai": {}})
    state = State(tmp_path)
    server = Server(("127.0.0.1", 0), state)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        with httpx.Client(base_url=f"http://127.0.0.1:{server.server_port}") as c:
            nonce = "a" * 32
            r = c.get("/health/challenge", params={"nonce": nonce})
            assert r.status_code == 200
            assert (
                r.json()["proof"]
                == hmac.new(token.encode(), ("rapkp-server-v1\n" + nonce).encode(), hashlib.sha256).hexdigest()
            )
            assert token not in r.text
            assert c.get("/health/challenge?nonce=invalid").status_code == 400
            assert c.get("/api/v1/status", headers={"Authorization": "Bearer wrong"}).status_code == 401
    finally:
        server.shutdown()
        server.server_close()
        state.close()
        t.join(timeout=3)


def test_config_update_never_returns_model_key(tmp_path):
    token = "d" * 64
    atomic_json(tmp_path / "config.json", {"token": token, "ephemeris": {"provider": "swisseph"}, "ai": {}})
    state = State(tmp_path)
    try:
        result = state.settings(
            {
                "ai": {
                    "provider": "openai",
                    "model": "gpt-6-astra",
                    "api_key": "private-only-key",
                    "consent": True,
                    "language": "English",
                }
            }
        )
        assert result["ai"]["configured"] and "private-only-key" not in json.dumps(result)
        assert (tmp_path / "config.json").stat().st_mode & 0o777 == 0o600
    finally:
        state.close()


@pytest.mark.parametrize(
    "payload",
    [
        {"unexpected": True},
        {"ai": {"extra": True}},
        {"ai": {"provider": "unknown"}},
        {"ai": {"model": "bad/model"}},
        {"ai": {"api_key": 123}},
        {"ai": {"language": "not-supported"}},
        {"ai": {"consent": "yes"}},
        {"ephemeris": {"provider": "swisseph", "path": 123}},
        {"ephemeris": {"provider": "unknown"}},
    ],
)
def test_reject_invalid_settings_without_changing_stored_values(tmp_path, payload):
    atomic_json(tmp_path / "config.json", {"token": "x" * 64, "ephemeris": {"provider": "swisseph"}, "ai": {}})
    s = State(tmp_path)
    try:
        before = (tmp_path / "config.json").read_bytes()
        with pytest.raises(CalculationError):
            s.settings(payload)
        assert (tmp_path / "config.json").read_bytes() == before
    finally:
        s.close()
