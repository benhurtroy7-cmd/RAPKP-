#!/usr/bin/env bash
set -e
SDK=/home/user/.cache/sdk
BT=$SDK/bt/android-14
AJ=$SDK/plat/android-34-ext10/android.jar
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
rm -rf build; mkdir -p build/obj

echo "== 1/6 aapt2 compile resources"
$BT/aapt2 compile --dir res -o build/res.zip

echo "== 2/6 aapt2 link"
$BT/aapt2 link build/res.zip -I "$AJ" \
  --manifest AndroidManifest.xml \
  --java build/gen -A assets \
  --min-sdk-version 24 --target-sdk-version 34 \
  -o build/app-unaligned.apk

echo "== 3/6 javac"
javac --release 8 -encoding UTF-8 -nowarn -classpath "$AJ" \
  -d build/obj java/in/rapkp/v26/MainActivity.java 2>&1 | grep -v "^warning" || true

echo "== 4/6 d8 (dex)"
$BT/d8 --lib "$AJ" --output build/ build/obj/in/rapkp/v26/*.class

echo "== 5/6 package + zipalign"
cd build && zip -q -j app-unaligned.apk classes.dex && cd ..
$BT/zipalign -f 4 build/app-unaligned.apk build/app-aligned.apk

echo "== 6/6 sign"
if [ ! -f rapkp.keystore ]; then
  /usr/lib/jvm/jdk-11/bin/keytool -genkeypair -alias rapkp -keyalg RSA -keysize 2048 -validity 11000 \
    -keystore rapkp.keystore -storepass rapkp26 -keypass rapkp26 \
    -dname "CN=RAPKP v26, OU=MIT openephem, O=RAPKP, L=Chennai, ST=TN, C=IN" >/dev/null
fi
/usr/lib/jvm/jdk-11/bin/java -jar $BT/lib/apksigner.jar sign --ks rapkp.keystore --ks-pass pass:rapkp26 \
  --key-pass pass:rapkp26 --ks-key-alias rapkp --out ../RAPKP-v26.apk build/app-aligned.apk
/usr/lib/jvm/jdk-11/bin/java -jar $BT/lib/apksigner.jar verify ../RAPKP-v26.apk
ls -lh ../RAPKP-v26.apk
