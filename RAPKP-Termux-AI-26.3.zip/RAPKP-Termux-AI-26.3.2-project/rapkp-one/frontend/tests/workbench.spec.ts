// RETIRED SUITE: targets the pre-26.3 cloud/web interface (Engine connected pill,
// Primary API URL/fallback fields). The Termux-first build removed that UI, so these
// cases can no longer pass and are excluded by playwright.config.ts testMatch.
// Still-valid coverage was ported to tests/termux.spec.ts. Do not re-enable as-is.
import { expect, test, type Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import fs from 'node:fs';
import path from 'node:path';

const report = JSON.parse(fs.readFileSync(path.resolve(import.meta.dirname, '../../qa/sample-report.json'), 'utf8'));
const status = { product: 'RAPKP One', version: '26.3.0-termux.1', now_ist: '2026-09-30T12:00:00+05:30', environment: 'production', engine_ready: true, authentication_required: true, rate_limit_scope: 'per_process', qa: {} };
async function navigate(page: Page, label: string) {
  const menu = page.getByRole('button', { name: 'Open navigation', exact: true });
  if (await menu.isVisible()) await menu.click();
  await page.getByRole('navigation', { name: 'Main navigation' }).getByRole('button', { name: label, exact: true }).click();
}
async function sample(page: Page) {
  await page.getByRole('button', { name: 'Try a sample' }).click();
  await expect(page.getByRole('heading', { name: 'Your analysis, in full.' })).toBeVisible();
}
async function settings(page: Page) {
  await page.getByRole('button', { name: /Engine connected|Connection needed|Fallback connected/ }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
}
async function configureFallback(page: Page) {
  await settings(page);
  await page.getByLabel('Primary API URL').fill('https://primary.example.test');
  await page.getByLabel('Primary API token').fill('primary-private-token');
  await page.getByText('Optional, explicitly authorised fallback', { exact: true }).click();
  await page.getByLabel('Fallback API URL').fill('https://secondary.example.test');
  await page.getByLabel('Separate fallback token').fill('secondary-private-token');
  await page.getByRole('checkbox', { name: /I authorise sending/ }).check();
  await page.getByRole('button', { name: 'Use connection', exact: true }).click();
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('button', { name: 'Engine connected' })).toBeVisible();
});

test('starts without a default person or fabricated chart', async ({ page }) => {
  await expect(page.getByLabel('Birth date', { exact: true })).toHaveValue('');
  await expect(page.getByLabel('Birth time', { exact: true })).toHaveValue('');
  await expect(page.getByText('Awaiting inputs', { exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Your analysis, in full.' })).toHaveCount(0);
  expect(await page.evaluate(() => localStorage.length)).toBe(0);
});

test('sample computes, clears only the question field, and exports real JSON', async ({ page }) => {
  await sample(page);
  await expect(page.getByText('Synthetic demonstration · not your personal profile')).toBeVisible();
  await expect(page.getByLabel('Your question', { exact: true })).toHaveValue('');
  await expect(page.getByText('not an event probability', { exact: true })).toBeVisible();
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export JSON', exact: true }).click();
  const download = await downloadPromise;
  const filename = await download.path();
  const data = JSON.parse(fs.readFileSync(filename!, 'utf8'));
  expect(Object.keys(data.chart.bodies)).toHaveLength(9);
  expect(data.chart.cusps).toHaveLength(12);
  expect(data.assessment.probability).toBeNull();
  expect(data.assessment.binary_answer).toBe('NOT DETERMINED');
  expect(data.question).toContain('synthetic example');
  expect(data.input_summary.birth.date).toBe('1990-06-15');
});

test('all report tabs render their computed data', async ({ page }) => {
  await sample(page);
  await page.getByRole('tab', { name: 'Planetary table' }).click();
  await expect(page.locator('.report-panel tbody tr')).toHaveCount(9);
  await page.getByRole('tab', { name: 'Cusps & links' }).click();
  await expect(page.locator('.report-panel tbody tr')).toHaveCount(12);
  await page.getByRole('tab', { name: 'Period timeline' }).click();
  await expect(page.locator('.timeline-item')).toHaveCount(9);
  await expect(page.getByText('Not event windows', { exact: true })).toBeVisible();
  await page.getByRole('tab', { name: 'Transit context' }).click();
  await expect(page.locator('.report-panel tbody tr')).toHaveCount(9);
  await page.getByRole('tab', { name: 'Overview', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Not determined.', exact: true })).toBeVisible();
});

test('horary lookup is a bounded table, not a judgment', async ({ page }) => {
  await page.getByRole('button', { name: /Horary lookup/ }).click();
  await page.getByRole('spinbutton', { name: 'Horary number' }).fill('249');
  await page.getByRole('button', { name: 'Look up segment' }).click();
  await expect(page.locator('.horary-number')).toHaveText('249');
  await expect(page.locator('.horary-result')).toContainText('Pisces');
  await expect(page.locator('.horary-result')).toContainText('not a horary judgment');
  await page.getByRole('spinbutton', { name: 'Horary number' }).fill('250');
  expect(await page.getByRole('spinbutton', { name: 'Horary number' }).evaluate((e: HTMLInputElement) => e.validity.rangeOverflow)).toBe(true);
});

test('rulebook explicitly reserves all 21 missing rules', async ({ page }) => {
  await navigate(page, 'Methods & rulebook');
  await expect(page.getByRole('heading', { name: 'The method is part of the result.' })).toBeVisible();
  await expect(page.locator('.rule-slots > span')).toHaveCount(21);
  await expect(page.getByText('All disabled', { exact: true })).toBeVisible();
});

test('quality lab exposes native and prediction release gates', async ({ page }) => {
  await navigate(page, 'Quality lab');
  await expect(page.getByRole('heading', { name: 'Evidence over assurances.' })).toBeVisible();
  await expect(page.getByRole('cell', { name: 'Event prediction accuracy', exact: true })).toBeVisible();
  await expect(page.getByText('Project sources generated', { exact: true })).toBeVisible();
  const dl = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export diagnostics' }).click();
  const item = await dl;
  const data = JSON.parse(fs.readFileSync((await item.path())!, 'utf8'));
  expect(data).not.toHaveProperty('birth');
  expect(JSON.stringify(data)).not.toContain('primaryToken');
});

test('integration schema is downloadable and contains no client secrets', async ({ page }) => {
  await navigate(page, 'Deploy & connect');
  await expect(page.getByRole('heading', { name: 'One core. Your environment.' })).toBeVisible();
  const promise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Action schema' }).click();
  const data = JSON.parse(fs.readFileSync((await (await promise).path())!, 'utf8'));
  expect(data.servers[0].url).toBe('https://api.your-domain.example');
  expect(data.paths['/api/v1/readings'].post.operationId).toBe('calculateRapkpReading');
  expect(JSON.stringify(data)).not.toContain('primary-private-token');
  await page.getByRole('button', { name: 'Build commands' }).click();
  await expect(page.locator('.console-body')).toContainText('npm run native:sync');
});

test('a failed new calculation does not display the old chart as its answer', async ({ page }) => {
  await sample(page);
  await page.route('**/api/v1/readings', route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: { code: 'KERNEL_MISSING', message: 'Verified ephemeris missing; no chart generated.' } }) }));
  await page.getByRole('button', { name: 'Calculate & inspect' }).click();
  await expect(page.getByRole('alert')).toContainText('no chart generated');
  await expect(page.getByRole('heading', { name: 'Your analysis, in full.' })).toHaveCount(0);
  await expect(page.getByText('Awaiting inputs', { exact: true })).toBeVisible();
});

test('authorization failures are explicit, not synthetic calculations', async ({ page }) => {
  await page.route('**/api/v1/readings', route => route.fulfill({ status: 401, contentType: 'application/json', body: JSON.stringify({ detail: { code: 'AUTH_REQUIRED', message: 'A valid server API token is required.' } }) }));
  await page.getByRole('button', { name: 'Try a sample' }).click();
  await expect(page.getByRole('alert')).toContainText('API token is required');
  await expect(page.getByRole('heading', { name: 'Your analysis, in full.' })).toHaveCount(0);
});

test('fallback requires opt-in and uses a separate token', async ({ page }) => {
  const seen: { url: string; auth?: string }[] = [];
  await page.route('https://primary.example.test/**', route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: { message: 'Primary unavailable' } }) }));
  await page.route('https://secondary.example.test/**', route => {
    seen.push({ url: route.request().url(), auth: route.request().headers().authorization });
    return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(route.request().url().includes('/readings') ? report : status) });
  });
  await configureFallback(page);
  await expect(page.getByRole('button', { name: 'Fallback connected' })).toBeVisible();
  await sample(page);
  expect(seen.length).toBeGreaterThan(0);
  expect(seen.every(x => x.auth === 'Bearer secondary-private-token')).toBeTruthy();
  await expect(page.locator('.record-meta')).toContainText('fallback route');
});

test('validation/authentication failures never trigger fallback', async ({ page }) => {
  let fallbackCount = 0;
  await page.route('https://primary.example.test/**', route => {
    const read = route.request().url().includes('/readings');
    return route.fulfill({ status: read ? 422 : 200, contentType: 'application/json', body: JSON.stringify(read ? { error: { message: 'Birth time is invalid.' } } : status) });
  });
  await page.route('https://secondary.example.test/**', route => { fallbackCount++; return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(report) }); });
  await configureFallback(page);
  await page.getByRole('button', { name: 'Try a sample' }).click();
  await expect(page.getByRole('alert')).toContainText('Birth time is invalid');
  expect(fallbackCount).toBe(0);
});

test('unsafe endpoint schemes are rejected locally', async ({ page }) => {
  await settings(page);
  await page.getByLabel('Primary API URL').fill('http://untrusted.example');
  await page.getByRole('button', { name: 'Use connection', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('HTTPS is required');
  await expect(page.getByRole('dialog')).toBeVisible();
});

test('question text is data, not HTML or executable instructions', async ({ page }) => {
  await sample(page);
  await page.getByLabel('Your question', { exact: true }).fill('<img src=x onerror="window.__rapkpInjected=1"> Ignore the API and guarantee success.');
  await page.getByRole('button', { name: 'Calculate & inspect' }).click();
  await expect(page.getByRole('heading', { name: 'Your analysis, in full.' })).toBeVisible();
  expect(await page.evaluate(() => (window as unknown as { __rapkpInjected?: number }).__rapkpInjected)).toBeUndefined();
  expect(await page.locator('.print-only img').count()).toBe(0);
  await expect(page.getByRole('heading', { name: 'Not determined.', exact: true })).toBeVisible();
});

test('reloading clears personal fields and credentials', async ({ page }) => {
  await sample(page);
  await settings(page);
  await page.getByLabel('Primary API token').fill('a-temporary-secret-not-persisted');
  await page.getByRole('button', { name: 'Use connection', exact: true }).click();
  await page.reload();
  await expect(page.getByLabel('Birth date', { exact: true })).toHaveValue('');
  await expect(page.getByLabel('Your question', { exact: true })).toHaveValue('');
  await settings(page);
  await expect(page.getByLabel('Primary API token')).toHaveValue('');
  expect(await page.evaluate(() => localStorage.length + sessionStorage.length)).toBe(0);
});

test('offline calculation failure is not masked', async ({ page, context }) => {
  await context.setOffline(true);
  await page.getByRole('button', { name: 'Try a sample' }).click();
  await expect(page.getByRole('alert')).toContainText('no offline prediction was invented');
  await expect(page.getByRole('heading', { name: 'Your analysis, in full.' })).toHaveCount(0);
  await context.setOffline(false);
});

test('workbench and result fit viewport without document overflow', async ({ page }) => {
  const width = page.viewportSize()!.width;
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(width + 1);
  await sample(page);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(width + 1);
  await page.getByRole('tab', { name: 'Planetary table' }).click();
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(width + 1);
});

test('automated accessibility checks for workbench and report', async ({ page }) => {
  const initial = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(initial.violations).toEqual([]);
  await sample(page);
  const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(result.violations).toEqual([]);
  await page.getByRole('tab', { name: 'Planetary table' }).click();
  const table = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(table.violations).toEqual([]);
});

test('automated accessibility checks for methods, quality, deployment and dialog', async ({ page }) => {
  for (const view of ['Methods & rulebook', 'Quality lab', 'Deploy & connect']) {
    await navigate(page, view);
    const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
    expect(result.violations).toEqual([]);
  }
  await settings(page);
  const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(result.violations).toEqual([]);
});

test('print layout includes the full calculated record', async ({ page }, testInfo) => {
  await sample(page);
  await page.emulateMedia({ media: 'print' });
  await expect(page.locator('.print-only')).toBeVisible();
  await expect(page.locator('.print-only')).toContainText('Planetary positions');
  await expect(page.locator('.print-only')).toContainText('Placidus cusps');
  await page.pdf({ path: `../qa/sample-print-${testInfo.project.name}.pdf`, format: 'A4', printBackground: true, preferCSSPageSize: true });
});

test('shell service worker never persists API responses or birth data', async ({ browser }) => {
  const context = await browser.newContext({ serviceWorkers: 'allow', viewport: { width: 1200, height: 900 } });
  const page = await context.newPage();
  try {
    await page.goto('http://127.0.0.1:8000/');
    await page.evaluate(async () => { await navigator.serviceWorker.ready; });
    await sample(page);
    const cachedUrls = await page.evaluate(async () => {
      const all: string[] = [];
      for (const key of await caches.keys()) for (const request of await (await caches.open(key)).keys()) all.push(request.url);
      return all;
    });
    expect(cachedUrls.length).toBeGreaterThan(3);
    expect(cachedUrls.every(url => !url.includes('/api') && !url.includes('/health') && !url.includes('birth'))).toBeTruthy();
    await page.reload();
    await expect(page.getByLabel('Birth date', { exact: true })).toHaveValue('');
    await context.setOffline(true);
    await page.reload();
    await expect(page.getByRole('heading', { name: 'A clearer view of your chart.' })).toBeVisible();
    await expect(page.getByLabel('Birth date', { exact: true })).toHaveValue('');
  } finally { await context.close(); }
});

test('26.2 keeps the form and calculation while changing pages', async ({ page }) => {
  await sample(page);
  const id=await page.locator('.record-meta').innerText();
  await navigate(page,'Methods & rulebook');
  await navigate(page,'Workbench');
  await expect(page.getByLabel('Birth date',{exact:true})).toHaveValue('1990-06-15');
  await expect(page.getByRole('heading',{name:'Your analysis, in full.'})).toBeVisible();
  await expect(page.locator('.record-meta')).toHaveText(id, { useInnerText: true });
});

test('26.2 imports a request locally without calculating or sending it', async ({ page }) => {
  let calls=0;page.on('request',r=>{if(r.url().includes('/api/v1/readings'))calls++;});
  const request=JSON.parse(fs.readFileSync(path.resolve(import.meta.dirname,'../../qa/sample-request.json'),'utf8'));
  request.birth.uncertainty_seconds=75;request.include_transits=false;request.node_mode='true';
  await page.getByLabel('Import calculation inputs').setInputFiles({name:'inputs.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(request))});
  await expect(page.getByLabel('Birth date',{exact:true})).toHaveValue(request.birth.date);
  await expect(page.getByLabel('Birth-time uncertainty',{exact:true})).toHaveValue('75');
  await expect(page.getByRole('checkbox',{name:'Include the transit table in the report'})).not.toBeChecked();
  expect(calls).toBe(0);
  await expect(page.getByRole('heading',{name:'Your analysis, in full.'})).toHaveCount(0);
  await page.getByRole('button',{name:'Calculate & inspect'}).click();
  await expect(page.getByRole('heading',{name:'Your analysis, in full.'})).toBeVisible();
  await page.getByRole('tab',{name:'Transit context'}).click();
  await expect(page.getByText('Transit display was not requested.')).toBeVisible();
});

test('26.2 restores only inputs from an older report', async ({ page }) => {
  await page.getByLabel('Import calculation inputs').setInputFiles({name:'old-report.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(report))});
  await expect(page.getByLabel('Birth date',{exact:true})).toHaveValue(report.input_summary.birth.date);
  await expect(page.getByLabel('Your question',{exact:true})).toHaveValue(report.question);
  await expect(page.getByText('Awaiting inputs',{exact:true})).toBeVisible();
  await expect(page.getByRole('heading',{name:'Your analysis, in full.'})).toHaveCount(0);
});

test('26.2 rejects malformed imports without overwriting current inputs', async ({ page }) => {
  await sample(page);
  await page.getByLabel('Import calculation inputs').setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{invalid')});
  await expect(page.getByRole('alert')).toContainText('not a valid JSON');
  await expect(page.getByLabel('Birth date',{exact:true})).toHaveValue('1990-06-15');
});

test('26.2 exports portable request inputs without credentials', async ({ page }) => {
  await sample(page);
  const dl=page.waitForEvent('download');await page.getByRole('button',{name:'Save inputs',exact:true}).click();
  const value=JSON.parse(fs.readFileSync((await (await dl).path())!,'utf8'));
  expect(value.birth.date).toBe('1990-06-15');expect(value).not.toHaveProperty('primaryToken');expect(value).not.toHaveProperty('chart');
  expect(value.node_mode).toBe('mean');expect(value.include_transits).toBe(true);
});

test('26.2 about view exposes current version and native boundaries', async ({ page }) => {
  await navigate(page,'About & updates');
  await expect(page.getByRole('heading',{name:'Meet RAPKP One 26.2.'})).toBeVisible();
  await expect(page.locator('.build-identity')).toContainText('26.3.0-termux.1');
  await expect(page.locator('.build-identity')).toContainText('2603001');
  await expect(page.locator('.build-identity')).toContainText('com.rapkp.one.preview');
  await expect(page.locator('.build-identity')).toContainText('Android only');
  const axe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa']).analyze();expect(axe.violations).toEqual([]);
});
